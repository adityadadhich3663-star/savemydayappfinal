# 🚨 SaveMyDay — Tactical Productivity Companion
> **AI-Powered Emergency Sprint System, Real-Time Voice Interventions, and Deadline Rescue Engine**

SaveMyDay is a high-octane, tactical productivity app designed specifically to rescue developers, creators, and students from the verge of missed deadlines. By combining military-grade sprint structures, AI-powered subtask planning, and real-time behavioral interventions (such as phone calls from an AI voice agent named **Karl**), SaveMyDay ensures you break procrastination loops and cross the finish line.

---

## 🎨 Core Design Philosophy & Aesthetic
SaveMyDay utilizes a highly polished, immersive **Cosmic Slate Theme** with clean margins, sharp focus framing, and spacious grids. It is crafted for maximum visual focus during high-pressure situations:
* **The Crimson & Blue Palette:** Deep dark canvas backgrounds (`#0B0B0F` to `#111118`) paired with neon alert crimson (for Panic countdowns) and electric blue (for focus states) to evoke a modern, tactical command-center atmosphere.
* **Micro-Animations:** Interactive components powered by `motion` from `motion/react` create elegant sliding panel animations, pulse indicators, and countdown feedback.
* **Typographical Framing:** Clean, legible "Inter" body typography paired with "Space Grotesk" display headings and "JetBrains Mono" statistics elements.

---

## 🚀 Key Feature Breakdown

### 1. 🚨 Extreme "Panic Mode" (Emergency Sprints)
When a critical deadline is minutes away and you are paralyzed by procrastination, activating **Panic Mode** initiates a high-pressure crisis coordination sequence:
* **Tactical Sprint Timer:** An immersive, full-screen visual countdown with real-time progress dials tracking your exact minutes to failure.
* **Crisis Coordination:** Blocks out all standard navigation noise and focuses your screen solely on the immediate, sub-hour tactical tasks.
* **Live Emergency Karl Call:** Direct button to trigger an immediate dial to your mobile device from **Karl**, your AI companion, to speak strict but encouraging instructions to get you working.

### 2. ⚡ Karl Voice Assistant Integration (Bland.ai)
Our crowning behavioral intercept feature is an AI voice assistant powered by **Bland.ai**. 
* **Custom AI Reminders:** Karl doesn't just send static push notifications; he dials your actual mobile phone, talks to you, asks why you're stuck, and verbally coaxes you back to focus.
* **Staggered Voice Preset Selection:** Select between multiple hyper-realistic vocal models directly from your profile settings:
  * `Karl v2` (Deep, professional, authoritative male voice)
  * `Nat` (Energetic, high-tempo female motivator)
  * `Sarah` (Calm, systematic assistant)
  * `Josh` (Calm, reassuring male voice)
* **Custom Instructions & Tasks:** The underlying Bland payload is customizable, directing Karl to use emergency reminders tailored to your custom sprint task.

### 3. 📞 "Bring Your Own Twilio" (Custom Voice Trunks)
For advanced users, developers, or teams looking to deploy SaveMyDay at scale without hitting public rate limits, we offer a seamless custom-trunk integration:
* **Custom SID & Token Bindings:** Input your `Twilio Account SID` and `Auth Token` in the settings drawer.
* **Automated Dashboard Registration:** Our integrated backend safely triggers Bland.ai's dynamic import endpoint (`/api/bland/import-twilio`) to instantly link your own Twilio numbers.
* **Seamless Outbound Route Switching:** Once imported, SaveMyDay routes Karl's voice calls directly through your personal Twilio phone number.

### 4. 🧠 Insights & "Deadline Autopsies"
SaveMyDay doesn't just help you survive deadlines; it trains you to predict and avoid future near-misses:
* **Deadline Autopsies:** When a task slips, the system guides you through a clinical post-mortem analysis to diagnose what went wrong (e.g., *Underestimation of Complexity, Procrastination Triggers, External Interruptions*).
* **Pattern Detection:** Evaluates your history to label behavior profiles (e.g., *"The Eleventh-Hour Sprinter"*, *"Scope-Creep Vulnerable"*).
* **Cascade Impact Simulator:** Uses advanced AI to simulate the downstream schedule impacts of missing a milestone (e.g., showing how delaying a mockup by 2 days cascades into a 1-week launch delay).

### 5. 📝 AI-Powered Task Planner & Subtask Decomposer
Break massive, overwhelming milestones into approachable chunks instantly:
* **Automated Decomposition:** Powered by the Gemini API, clicking "Decompose" on any complex planner item generates standard, manageable subtasks.
* **Effort & Energy Weighting:** Subtasks are weighted by estimated effort and categorized by sprint discipline to help you budget mental energy.
* **Micro-Scheduling Workspace:** Drag, order, and adjust tasks inside your active tactical workspace.

### 6. 🛡️ Habit Tracker (Defensive Routines)
Consistency is your best armor. Track routines specifically designed to safeguard deadlines:
* **Panic Sinks & Streaks:** Maintain daily chains of focus blocks, distraction-free mornings, and timely plan updates.
* **Visual Streaks & Alerts:** Dynamic ring visualizers and calendar heatmaps highlight streaks, alerting you when a defensive routine is in danger of being broken.

---

## 🛠️ Backend System & Architecture
SaveMyDay is built as a highly performant **Express + Vite Full-Stack Application**:
* **API Ingress Routing (`server.ts`):** Handles secure API proxying to keep all proprietary secret keys hidden from public client-side inspectors.
* **Credential Protection:** Lazy-evaluates custom `BLAND_API_KEY`, `TWILIO_ACCOUNT_SID`, and `TWILIO_AUTH_TOKEN` environment secrets, automatically sanitizing trailing symbols, quotes, or accidental formatting inputs.
* **Vite Dev Server Integration:** Runs both the fast frontend bundling engine and the Express routing engine inside a single-port container deployment.

---

## ⚙️ Initial Configuration Guide

To enable live voice alerts and custom Twilio imports in your local development or production workspace:

1. **Get a Bland.ai API Key:** Sign up at [Bland.ai](https://bland.ai) to claim your developer keys.
2. **Add Secrets:** In your AI Studio project's **Settings / Secrets** panel (or `.env` file), declare the following keys:
   ```env
   BLAND_API_KEY=your_bland_api_key_here
   TWILIO_ACCOUNT_SID=your_twilio_sid_here
   TWILIO_AUTH_TOKEN=your_twilio_auth_token_here
   ```
3. **Register your Number:** In the **Settings** tab of SaveMyDay, save your mobile phone number.
4. **Trigger a Test Call:** Click **Trigger Live Test Call** and prepare to pick up your phone!
