/**
 * High-fidelity notification sound synthesizer using native Web Audio API.
 * This ensures audio works seamlessly in sandboxed iframe environments
 * without external audio file dependencies.
 */
export const playNotificationSound = (soundName: string) => {
  if (!soundName || soundName === 'none') return;
  
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    const ctx = new AudioContextClass();
    const now = ctx.currentTime;
    
    if (soundName === 'beep') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, now); // A5 note
      
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.15);
    } 
    else if (soundName === 'chime') {
      // Dual-tone clean synth harmony
      const notes = [523.25, 659.25, 783.99]; // C5, E5, G5 triad
      
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        const noteStart = now + idx * 0.08;
        
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, noteStart);
        
        gain.gain.setValueAtTime(0.08, noteStart);
        gain.gain.exponentialRampToValueAtTime(0.001, noteStart + 0.35);
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(noteStart);
        osc.stop(noteStart + 0.35);
      });
    } 
    else if (soundName === 'bell') {
      // FM-synthesized ringing bell with multi-partials
      const partials = [587.33, 880, 1174.66, 1760]; // D5, A5, D6, A6 harmonics
      
      partials.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        
        osc.type = idx === 0 ? 'sine' : 'triangle';
        osc.frequency.setValueAtTime(freq, now);
        
        const volume = 0.05 / (idx + 1);
        gain.gain.setValueAtTime(volume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.8 / (idx + 1));
        
        osc.connect(gain);
        gain.connect(ctx.destination);
        
        osc.start(now);
        osc.stop(now + 0.8 / (idx + 1));
      });
    } 
    else if (soundName === 'alert') {
      // High-stakes futuristic warning sweep
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(330, now);
      osc.frequency.exponentialRampToValueAtTime(990, now + 0.4);
      
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
      
      osc.connect(gain);
      gain.connect(ctx.destination);
      
      osc.start(now);
      osc.stop(now + 0.4);
    }
  } catch (err) {
    console.warn('Web Audio playback failed. Standard audio notification was silenced.', err);
  }
};

let ringtoneInterval: any = null;
let ringtoneContext: any = null;

export const playSimulatedRingtone = () => {
  if (ringtoneInterval) return;
  
  try {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;
    
    ringtoneContext = new AudioContextClass();

    const playTone = () => {
      if (!ringtoneContext || ringtoneContext.state === 'closed') return;
      const now = ringtoneContext.currentTime;
      
      // Traditional telephone ring tone (dual frequencies: 440Hz + 480Hz vibrating together)
      const osc1 = ringtoneContext.createOscillator();
      const osc2 = ringtoneContext.createOscillator();
      const gainNode = ringtoneContext.createGain();
      
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(440, now);
      
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(480, now);
      
      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(0.08, now + 0.1);
      gainNode.gain.linearRampToValueAtTime(0.08, now + 1.2);
      gainNode.gain.exponentialRampToValueAtTime(0.001, now + 1.5);
      
      osc1.connect(gainNode);
      osc2.connect(gainNode);
      gainNode.connect(ringtoneContext.destination);
      
      osc1.start(now);
      osc2.start(now);
      osc1.stop(now + 1.5);
      osc2.stop(now + 1.5);
    };

    // Ring once immediately
    playTone();

    // Ring every 3 seconds
    ringtoneInterval = setInterval(playTone, 3000);
  } catch (err) {
    console.warn('Ringtone playback failed:', err);
  }
};

export const stopSimulatedRingtone = () => {
  if (ringtoneInterval) {
    clearInterval(ringtoneInterval);
    ringtoneInterval = null;
  }
  if (ringtoneContext) {
    try {
      ringtoneContext.close();
    } catch (e) {}
    ringtoneContext = null;
  }
};
