import { pgTable, text, integer, timestamp, boolean, jsonb } from 'drizzle-orm/pg-core';

export const users = pgTable('users', {
  id: text('id').primaryKey(), // Using Firebase Auth UID directly
  email: text('email').notNull(),
  name: text('name').default(''),
  peakEnergyTime: text('peak_energy_time').default('morning'),
  onboardingComplete: boolean('onboarding_complete').default(false),
  panicSaveCount: integer('panic_save_count').default(0),
  joinedAt: text('joined_at').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
});

export const tasks = pgTable('tasks', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  title: text('title').notNull(),
  description: text('description').default(''),
  deadline: text('deadline').notNull(), // ISO 8601 string
  effort: text('effort').notNull(), // 'quick' | 'medium' | 'deep'
  category: text('category').notNull(), // 'work' | 'study' | 'personal' | 'health' | 'finance'
  priority: text('priority').notNull(), // 'critical' | 'important' | 'flexible' | 'park'
  status: text('status').notNull(), // 'todo' | 'in-progress' | 'done' | 'missed'
  subtasks: jsonb('subtasks').default('[]'), // Stores array of subtasks [{ id, title, done }]
  notes: text('notes').default(''),
  scheduledFor: text('scheduled_for'), // ISO string or null
  createdAt: text('created_at').notNull(),
  completedAt: text('completed_at'),
});

export const habits = pgTable('habits', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  name: text('name').notNull(),
  minimumViable: text('minimum_viable').notNull(),
  why: text('why').notNull(),
  category: text('category').notNull(),
  frequency: jsonb('frequency').notNull(), // 'daily' | 'weekdays' | array of day numbers
  completions: jsonb('completions').default('[]'), // array of completion date strings [YYYY-MM-DD]
  createdAt: text('created_at').notNull(),
});

export const autopsies = pgTable('autopsies', {
  id: text('id').primaryKey(),
  userId: text('user_id').references(() => users.id, { onDelete: 'cascade' }).notNull(),
  taskId: text('task_id').notNull(),
  taskTitle: text('task_title').notNull(),
  missedAt: text('missed_at').notNull(),
  patternLabel: text('pattern_label').notNull(),
  aiAnalysis: text('ai_analysis').notNull(),
  countermeasure: text('countermeasure').notNull(),
});
