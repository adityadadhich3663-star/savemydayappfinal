import React from 'react';
import { LMLSProvider, useLMLS } from './context/LMLSContext';
import AppShell from './components/layout/AppShell';
import Dashboard from './components/pages/Dashboard';
import PanicMode from './components/pages/PanicMode';
import Planner from './components/pages/Planner';
import HabitTracker from './components/pages/HabitTracker';
import Insights from './components/pages/Insights';
import Settings from './components/pages/Settings';

function MainAppRouter() {
  const { activePage } = useLMLS();

  // Simple and highly robust page router inside standard Vite container
  const renderPage = () => {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard />;
      case 'panic':
        return <PanicMode />;
      case 'planner':
        return <Planner />;
      case 'habits':
        return <HabitTracker />;
      case 'insights':
        return <Insights />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return <AppShell>{renderPage()}</AppShell>;
}

export default function App() {
  return (
    <LMLSProvider>
      <MainAppRouter />
    </LMLSProvider>
  );
}
