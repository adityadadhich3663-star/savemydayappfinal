import React, { useState, useEffect } from 'react';

interface CountdownTimerProps {
  deadline: string;
  status: 'todo' | 'in-progress' | 'done' | 'missed';
  compact?: boolean;
}

export default function CountdownTimer({ deadline, status, compact = false }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState<string>('');
  const [isUrgent, setIsUrgent] = useState<boolean>(false);
  const [isOverdue, setIsOverdue] = useState<boolean>(false);

  useEffect(() => {
    const updateTimer = () => {
      if (status === 'done') {
        setTimeLeft('Completed');
        setIsUrgent(false);
        setIsOverdue(false);
        return;
      }

      const now = new Date();
      const target = new Date(deadline);
      const diffMs = target.getTime() - now.getTime();

      if (diffMs <= 0) {
        setIsOverdue(true);
        setIsUrgent(false);
        const elapsedHours = Math.abs(diffMs) / (1000 * 60 * 60);
        if (elapsedHours > 24) {
          setTimeLeft(`Overdue ${Math.floor(elapsedHours / 24)}d`);
        } else {
          setTimeLeft('Overdue');
        }
        return;
      }

      setIsOverdue(false);

      const diffSecs = Math.floor(diffMs / 1000);
      const days = Math.floor(diffSecs / (24 * 3600));
      const hours = Math.floor((diffSecs % (24 * 3600)) / 3600);
      const mins = Math.floor((diffSecs % 3600) / 60);
      const secs = diffSecs % 60;

      // Urgent if less than 4 hours
      setIsUrgent(diffSecs < 4 * 3600);

      const pad = (num: number) => String(num).padStart(2, '0');

      if (compact) {
        if (days > 0) {
          setTimeLeft(`${days}d ${pad(hours)}h`);
        } else {
          setTimeLeft(`${pad(hours)}:${pad(mins)}:${pad(secs)}`);
        }
      } else {
        if (days > 0) {
          setTimeLeft(`${days}d ${pad(hours)}h ${pad(mins)}m ${pad(secs)}s`);
        } else {
          setTimeLeft(`${pad(hours)}:${pad(mins)}:${pad(secs)}`);
        }
      }
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);
    return () => clearInterval(interval);
  }, [deadline, status, compact]);

  if (status === 'done') {
    return (
      <span className="text-xs font-semibold px-2 py-1 bg-accent-green/10 text-accent-green rounded border border-accent-green/20">
        COMPLETED ✓
      </span>
    );
  }

  if (isOverdue) {
    return (
      <span className="text-xs font-mono font-bold px-2 py-1 bg-accent-red/10 text-accent-red rounded border border-accent-red/30 animate-pulse">
        ⚠️ {timeLeft}
      </span>
    );
  }

  return (
    <span 
      className={`font-mono font-bold tracking-wider px-2 py-1 rounded text-xs sm:text-sm ${
        isUrgent 
          ? 'bg-accent-red/20 text-accent-red border border-accent-red shadow-[0_0_12px_rgba(255,59,92,0.3)] animate-pulse' 
          : 'bg-[#1A1A26] border border-[#2A2A3E] text-white'
      }`}
    >
      ⏳ {timeLeft}
    </span>
  );
}
