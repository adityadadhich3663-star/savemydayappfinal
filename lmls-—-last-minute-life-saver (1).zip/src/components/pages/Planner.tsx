import React, { useState } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { CalendarRange, Sparkles, Plus, ChevronLeft, ChevronRight, Filter, SortAsc, AlertCircle } from 'lucide-react';
import { Task } from '../../types';
import TaskDetailModal from '../planner/TaskDetailModal';

export default function Planner() {
  const { 
    tasks, 
    addTask, 
    optimizeSchedule, 
    toggleTaskStatus, 
    userProfile 
  } = useLMLS();

  const [filter, setFilter] = useState<'all' | 'today' | 'overdue' | 'unscheduled'>('all');
  const [sortBy, setSortBy] = useState<'deadline' | 'priority' | 'effort'>('deadline');
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);

  // New task form
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [deadline, setDeadline] = useState('');
  const [category, setCategory] = useState<'work' | 'study' | 'personal' | 'health' | 'finance'>('work');
  const [effort, setEffort] = useState<'quick' | 'medium' | 'deep'>('medium');
  const [notes, setNotes] = useState('');
  const [callReminderMode, setCallReminderMode] = useState<'none' | 'relative-15' | 'relative-30' | 'relative-60' | 'custom'>('none');
  const [callReminderTime, setCallReminderTime] = useState('');

  const [isOptimizing, setIsOptimizing] = useState(false);

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !deadline) return;

    let reminderTime: string | null = null;
    let minutesBefore: number | null = null;
    
    if (callReminderMode === 'relative-15') {
      minutesBefore = 15;
      reminderTime = new Date(new Date(deadline).getTime() - 15 * 60000).toISOString();
    } else if (callReminderMode === 'relative-30') {
      minutesBefore = 30;
      reminderTime = new Date(new Date(deadline).getTime() - 30 * 60000).toISOString();
    } else if (callReminderMode === 'relative-60') {
      minutesBefore = 60;
      reminderTime = new Date(new Date(deadline).getTime() - 60 * 60000).toISOString();
    } else if (callReminderMode === 'custom' && callReminderTime) {
      reminderTime = new Date(callReminderTime).toISOString();
    }

    addTask({
      title: title.trim(),
      description: desc.trim(),
      deadline: new Date(deadline).toISOString(),
      effort,
      category,
      notes,
      callReminderTime: reminderTime,
      callReminderMinutesBefore: minutesBefore,
      callReminderSent: false,
    });

    setTitle('');
    setDesc('');
    setDeadline('');
    setNotes('');
    setCallReminderMode('none');
    setCallReminderTime('');
    setShowAddModal(false);
  };

  const handleAiOptimize = async () => {
    setIsOptimizing(true);
    await optimizeSchedule();
    setIsOptimizing(false);
  };

  // Date and Week Calculations
  const getWeekDays = () => {
    const today = new Date();
    const first = today.getDate() - today.getDay() + 1; // First day of week is Monday
    const week = [];
    for (let i = 0; i < 7; i++) {
      const day = new Date(today.setDate(first + i));
      week.push(day);
    }
    return week;
  };

  const weekDays = getWeekDays();

  // Filter & Sort tasks for list panel
  const getFilteredTasks = () => {
    const now = new Date();
    let result = [...tasks];

    if (filter === 'today') {
      const todayStr = now.toISOString().split('T')[0];
      result = result.filter(t => new Date(t.deadline).toISOString().split('T')[0] === todayStr);
    } else if (filter === 'overdue') {
      result = result.filter(t => new Date(t.deadline) < now && t.status !== 'done');
    } else if (filter === 'unscheduled') {
      result = result.filter(t => !t.scheduledFor);
    }

    // Sort
    result.sort((a, b) => {
      if (sortBy === 'deadline') {
        return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
      } else if (sortBy === 'priority') {
        const priorityWeight = { critical: 4, important: 3, flexible: 2, park: 1 };
        return (priorityWeight[b.priority] || 2) - (priorityWeight[a.priority] || 2);
      } else if (sortBy === 'effort') {
        const effortWeight = { deep: 3, medium: 2, quick: 1 };
        return (effortWeight[b.effort] || 2) - (effortWeight[a.effort] || 2);
      }
      return 0;
    });

    return result;
  };

  const listTasks = getFilteredTasks();

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <CalendarRange className="text-accent-blue" size={16} />
            <span className="text-accent-blue font-mono font-black text-xs uppercase tracking-wider">Rescue Calendaring System</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-black text-white leading-tight">
            Planner & Scheduler 🗓️
          </h1>
          <p className="text-text-secondary text-sm font-sans mt-1">
            Reconcile deadlines, plan weeks, and let the AI resolve conflicts in one click.
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={handleAiOptimize}
            disabled={isOptimizing}
            className="px-4 py-2.5 bg-gradient-to-r from-accent-purple to-accent-blue hover:opacity-90 text-white font-semibold rounded-lg text-sm flex items-center space-x-2 transition cursor-pointer shadow-lg shadow-accent-purple/20"
          >
            <Sparkles size={16} className={isOptimizing ? 'animate-spin' : ''} />
            <span>{isOptimizing ? 'Optimizing Schedule...' : 'Let AI Optimize My Week'}</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="px-4 py-2.5 bg-[#1A1A26] border border-[#2A2A3E] hover:border-[#48485A] text-white font-semibold rounded-lg text-sm flex items-center space-x-2 transition cursor-pointer"
          >
            <Plus size={16} />
            <span>Add Task</span>
          </button>
        </div>
      </header>

      {/* Grid: Weekly Grid + Task List Shelf */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Weekly View Grid (Left 3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-[#2A2A3E]">
            <h3 className="font-display font-black text-sm text-white uppercase tracking-wider">Weekly Sprints</h3>
            <span className="text-xs font-mono text-text-muted">Peak energy optimal blocks highlighted</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-7 gap-3">
            {weekDays.map((day, i) => {
              const dayStr = day.toISOString().split('T')[0];
              const dayName = day.toLocaleDateString('en-US', { weekday: 'short' });
              const dayNum = day.getDate();
              
              // Find tasks scheduled/due for this day
              const dayTasks = tasks.filter(t => {
                const dateStr = new Date(t.scheduledFor || t.deadline).toISOString().split('T')[0];
                return dateStr === dayStr;
              });

              const isToday = new Date().toISOString().split('T')[0] === dayStr;

              return (
                <div 
                  key={i} 
                  className={`bg-[#111118] border rounded-xl p-3 min-h-[350px] flex flex-col justify-between transition ${
                    isToday ? 'border-accent-blue bg-accent-blue/5' : 'border-[#2A2A3E]'
                  }`}
                >
                  <div>
                    {/* Day Header */}
                    <div className="flex items-center justify-between pb-2 border-b border-[#1D1D2B] mb-2.5">
                      <span className={`text-xs font-display font-black tracking-wide ${isToday ? 'text-accent-blue' : 'text-text-secondary'}`}>
                        {dayName}
                      </span>
                      <span className={`text-xs font-mono font-bold ${isToday ? 'bg-accent-blue text-white px-1.5 py-0.5 rounded' : 'text-text-muted'}`}>
                        {dayNum}
                      </span>
                    </div>

                    {/* Day Tasks Blocks */}
                    <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
                      {dayTasks.map(task => {
                        const borderAccent = task.priority === 'critical' ? 'border-l-accent-red' : task.priority === 'important' ? 'border-l-accent-amber' : 'border-l-accent-blue';
                        return (
                          <div 
                            key={task.id}
                            onClick={() => setSelectedTask(task)}
                            className={`p-2 bg-[#1A1A26] border border-[#2D2D44] border-l-4 ${borderAccent} rounded text-[11px] cursor-pointer hover:border-text-secondary transition space-y-1`}
                          >
                            <div className="font-bold text-white leading-snug line-clamp-2">{task.title}</div>
                            <div className="flex items-center justify-between text-[9px] text-text-secondary">
                              <span className="capitalize">{task.effort}</span>
                              <span className={task.status === 'done' ? 'text-accent-green' : 'text-accent-blue'}>
                                {task.status === 'done' ? 'Done' : 'Pending'}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                      {dayTasks.length === 0 && (
                        <div className="text-center py-12 text-[10px] text-text-muted italic">
                          No Sprints
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Task Shelf List Sidebar (Right 1 col) */}
        <div className="space-y-4">
          <div className="pb-2 border-b border-[#2A2A3E]">
            <h3 className="font-display font-black text-sm text-white uppercase tracking-wider">Pending Target Shelf</h3>
          </div>

          {/* Filtering row */}
          <div className="flex justify-between items-center bg-[#111118] border border-[#2A2A3E] rounded p-2 text-xs space-x-1">
            <button
              onClick={() => setFilter('all')}
              className={`flex-1 py-1 rounded font-bold cursor-pointer transition ${filter === 'all' ? 'bg-[#1A1A26] text-white' : 'text-text-secondary hover:text-white'}`}
            >
              All
            </button>
            <button
              onClick={() => setFilter('today')}
              className={`flex-1 py-1 rounded font-bold cursor-pointer transition ${filter === 'today' ? 'bg-[#1A1A26] text-white' : 'text-text-secondary hover:text-white'}`}
            >
              Today
            </button>
            <button
              onClick={() => setFilter('overdue')}
              className={`flex-1 py-1 rounded font-bold cursor-pointer transition ${filter === 'overdue' ? 'bg-[#1A1A26] text-white' : 'text-text-secondary hover:text-white'}`}
            >
              Overdue
            </button>
          </div>

          {/* Sorter row */}
          <div className="flex items-center justify-between text-[10px] font-mono text-text-muted px-1">
            <span>Sort By:</span>
            <div className="flex space-x-2">
              <button onClick={() => setSortBy('deadline')} className={`hover:text-white ${sortBy === 'deadline' ? 'text-accent-blue underline' : ''}`}>Deadline</button>
              <button onClick={() => setSortBy('priority')} className={`hover:text-white ${sortBy === 'priority' ? 'text-accent-blue underline' : ''}`}>Priority</button>
            </div>
          </div>

          {/* Tasks Shelf List */}
          <div className="space-y-2.5 max-h-[420px] overflow-y-auto pr-1">
            {listTasks.map(task => {
              const borderLeft = task.priority === 'critical' ? 'border-l-accent-red' : task.priority === 'important' ? 'border-l-accent-amber' : 'border-l-accent-blue';
              return (
                <div 
                  key={task.id}
                  onClick={() => setSelectedTask(task)}
                  className={`p-3 bg-[#111118] border border-[#2A2A3E] border-l-4 ${borderLeft} rounded-lg cursor-pointer hover:border-[#48485A] transition flex justify-between items-center`}
                >
                  <div className="space-y-1 truncate max-w-[170px]">
                    <div className="font-bold text-sm text-white truncate">{task.title}</div>
                    <div className="text-[10px] text-text-secondary truncate">
                      {new Date(task.deadline).toLocaleDateString([], { month: 'short', day: 'numeric' })} | Effort: <strong className="capitalize">{task.effort}</strong>
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={task.status === 'done'}
                    onChange={(e) => {
                      e.stopPropagation();
                      toggleTaskStatus(task.id);
                    }}
                    className="rounded border-[#2A2A3E] bg-[#1A1A26] text-accent-blue focus:ring-0 cursor-pointer"
                  />
                </div>
              );
            })}
            {listTasks.length === 0 && (
              <div className="text-center py-12 text-text-muted text-xs italic">
                No tasks match filter criteria.
              </div>
            )}
          </div>
        </div>

      </div>

      {/* Add Task Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#111118] border border-[#2A2A3E] rounded-xl p-6 space-y-4 shadow-2xl">
            <h3 className="font-display font-black text-lg text-white">RESCUE NEW TARGET DEADLINE</h3>
            <form onSubmit={handleCreateTask} className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Task Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Assemble Slides for Pitch Deck"
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Description</label>
                <textarea
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  placeholder="Short brief of deliverables and milestones..."
                  rows={2}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue resize-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Exact Deadline</label>
                  <input
                    type="datetime-local"
                    value={deadline}
                    onChange={(e) => setDeadline(e.target.value)}
                    className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Category</label>
                  <select
                    value={category}
                    onChange={(e: any) => setCategory(e.target.value)}
                    className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none"
                  >
                    <option value="work">Work</option>
                    <option value="study">Study</option>
                    <option value="personal">Personal</option>
                    <option value="health">Health</option>
                    <option value="finance">Finance</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Effort required</label>
                  <select
                    value={effort}
                    onChange={(e: any) => setEffort(e.target.value)}
                    className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none"
                  >
                    <option value="quick">Quick (5-15 mins)</option>
                    <option value="medium">Medium (30-60 mins)</option>
                    <option value="deep">Deep (2+ hours)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Strategic Notes</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Relevant links, requirements..."
                  rows={2}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">📞 Voice Call Reminder (Bland.ai)</label>
                <select
                  value={callReminderMode}
                  onChange={(e: any) => setCallReminderMode(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none mb-2"
                >
                  <option value="none">No Phone Call Reminder</option>
                  <option value="relative-15">15 minutes before deadline</option>
                  <option value="relative-30">30 minutes before deadline</option>
                  <option value="relative-60">1 hour before deadline</option>
                  <option value="custom">Custom Date & Time</option>
                </select>

                {callReminderMode === 'custom' && (
                  <input
                    type="datetime-local"
                    value={callReminderTime}
                    onChange={(e) => setCallReminderTime(e.target.value)}
                    className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none focus:border-accent-blue"
                    required={callReminderMode === 'custom'}
                  />
                )}
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-accent-blue hover:bg-accent-blue/85 text-white font-semibold rounded text-sm transition cursor-pointer"
                >
                  Create Target
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#1A1A26] border border-[#2A2A3E] hover:bg-[#2A2A3E] text-text-secondary hover:text-white rounded text-sm transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal 
          task={selectedTask} 
          onClose={() => setSelectedTask(null)} 
        />
      )}

    </div>
  );
}
