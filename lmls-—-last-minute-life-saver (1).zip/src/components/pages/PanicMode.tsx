import React, { useState, useEffect, useRef } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { Flame, Play, ShieldAlert, Sparkles, CheckCircle2, AlertTriangle, ArrowRight, EyeOff, CheckSquare, RefreshCw, Clock, LogOut } from 'lucide-react';
import confetti from 'canvas-confetti';

interface Sprint {
  id: string;
  duration: number; // minutes
  text: string;
}

export default function PanicMode() {
  const { 
    tasks, 
    toggleTaskStatus, 
    isPanicMode, 
    setIsPanicMode, 
    panicTaskId, 
    setPanicTaskId,
    isFocusLock,
    setIsFocusLock,
    sendChatMessage,
    setIsChatOpen,
    userProfile,
    updateTask,
    triggerVirtualCall
  } = useLMLS();

  const [selectedTaskId, setSelectedTaskId] = useState<string>('');
  const [customTaskTitle, setCustomTaskTitle] = useState<string>('');
  const [selectedMinutes, setSelectedMinutes] = useState<number>(25);
  const [sprintPlan, setSprintPlan] = useState<Sprint[]>([]);
  const [isPlanGenerating, setIsPlanGenerating] = useState(false);
  const [statedProgress, setStatedProgress] = useState('0'); // 0% / 25% / 50% / 75%
  const [customEndTime, setCustomEndTime] = useState<string>('');
  const [activePanicEndTime, setActivePanicEndTime] = useState<string | null>(null);

  // Bland AI voice call states
  const [blandCallState, setBlandCallState] = useState<'idle' | 'calling' | 'success' | 'error'>('idle');
  const [blandCallError, setBlandCallError] = useState('');
  
  // Timer States
  const [activeSprintIndex, setActiveSprintIndex] = useState<number>(0);
  const [timerActive, setTimerActive] = useState<boolean>(false);
  const [secondsLeft, setSecondsLeft] = useState<number>(0);
  const timerRef = useRef<any>(null);

  // Sync state selectedTaskId with panicTaskId
  useEffect(() => {
    if (panicTaskId) {
      if (panicTaskId !== 'custom-panic-task') {
        setSelectedTaskId(panicTaskId);
        setCustomTaskTitle('');
      }
    } else if (tasks.length > 0) {
      const incomplete = tasks.filter(t => t.status !== 'done');
      if (incomplete.length > 0) {
        setSelectedTaskId(incomplete[0].id);
      }
    }
  }, [panicTaskId, tasks]);

  const targetTask = tasks.find(t => t.id === selectedTaskId);

  // Set default customEndTime to task deadline when selectedTask changes
  useEffect(() => {
    if (targetTask) {
      const dateObj = new Date(targetTask.deadline);
      const tzOffset = dateObj.getTimezoneOffset() * 60000;
      const localISO = new Date(dateObj.getTime() - tzOffset).toISOString().slice(0, 16);
      setCustomEndTime(localISO);
    }
  }, [selectedTaskId, targetTask]);

  // Giant Countdown Clock Calculations
  const [countdownString, setCountdownString] = useState('00:00:00');
  useEffect(() => {
    const clockInterval = setInterval(() => {
      const targetDateString = activePanicEndTime || (targetTask ? targetTask.deadline : null);
      if (!targetTask && !customTaskTitle) {
        setCountdownString('00:00:00');
        return;
      }
      const now = new Date();
      const target = targetDateString ? new Date(targetDateString) : new Date(Date.now() + selectedMinutes * 60000);
      const diffMs = target.getTime() - now.getTime();

      if (diffMs <= 0) {
        setCountdownString('OVERDUE');
        return;
      }

      const diffSecs = Math.floor(diffMs / 1000);
      const hours = Math.floor(diffSecs / 3600);
      const mins = Math.floor((diffSecs % 3600) / 60);
      const secs = diffSecs % 60;

      const pad = (num: number) => String(num).padStart(2, '0');
      setCountdownString(`${pad(hours)}:${pad(mins)}:${pad(secs)}`);

      // Automatically check for synchronized scheduled Bland.ai voice reminders
      if (targetTask && targetTask.callReminderTime && !targetTask.callReminderSent && targetTask.status !== 'done' && targetTask.status !== 'missed') {
        const reminderTime = new Date(targetTask.callReminderTime);
        if (now.getTime() >= reminderTime.getTime()) {
          console.log(`[PanicMode Countdown Timer] Synchronized reminder reached! Triggering voice call for "${targetTask.title}"`);
          
          // Reschedule the task to call again in 5 minutes unless completed/turned done
          const nextReminderTime = new Date(now.getTime() + 5 * 60000).toISOString();
          updateTask(targetTask.id, {
            callReminderTime: nextReminderTime,
            callReminderSent: false
          });

          // Compute precise remaining duration relative to the absolute deadline
          let timeRemainingText = "";
          const diffMins = Math.max(0, Math.round((new Date(targetTask.deadline).getTime() - now.getTime()) / 60000));
          if (diffMins <= 16 && diffMins >= 14) {
            timeRemainingText = "exactly 15 minutes left";
          } else if (diffMins <= 31 && diffMins >= 29) {
            timeRemainingText = "exactly 30 minutes left";
          } else if (diffMins <= 62 && diffMins >= 58) {
            timeRemainingText = "exactly 1 hour left";
          } else if (diffMins < 60) {
            timeRemainingText = `${diffMins} minutes left`;
          } else {
            const hrs = Math.floor(diffMins / 60);
            const remMins = diffMins % 60;
            if (remMins === 0) {
              timeRemainingText = `exactly ${hrs} hour${hrs > 1 ? 's' : ''} left`;
            } else {
              timeRemainingText = `exactly ${hrs} hour${hrs > 1 ? 's' : ''} and ${remMins} minute${remMins > 1 ? 's' : ''} left`;
            }
          }

          const systemInstructionPrompt = `You are Karl from SaveMyDay. Deliver this urgent focus reminder to ${userProfile?.name || 'Saver'}: "Reminder: It is time to work on your task, '${targetTask.title}'. You have ${timeRemainingText} remaining to meet your deadline! Stay focused, stay motivated, drop all excuses, start the timer, and let's get to work right now! If you do not start the timer and work, I will call you again in 5 minutes." After delivering this message, say "Goodbye!" and hang up the call immediately. DO NOT say anything else. DO NOT ask any questions or wait for a response. End the call now.`;

          fetch('/api/bland/call', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({
              phone_number: userProfile?.phoneNumber || "+15674025498",
              voice: userProfile?.voiceSelection || 'a24c43d3-f448-4fea-a498-a9287f7cabf3',
              task: systemInstructionPrompt
            })
          }).then(res => res.json())
            .then(data => {
              console.log("[PanicMode Timer Bland Call Result]", data);
              if (data.is_simulated_fallback) {
                triggerVirtualCall(systemInstructionPrompt);
              }
            })
            .catch(err => {
              console.error("Error triggering call inside PanicMode timer, falling back to simulated:", err);
              triggerVirtualCall(systemInstructionPrompt);
            });
        }
      }
    }, 1000);

    return () => clearInterval(clockInterval);
  }, [targetTask, activePanicEndTime, customTaskTitle, selectedMinutes, updateTask, userProfile]);

  // Handle manual panic trigger
  const handlePanicActivation = () => {
    if (!selectedTaskId && !customTaskTitle.trim()) {
      alert("Please select a task or enter a custom task title to start!");
      return;
    }
    
    setPanicTaskId(selectedTaskId || 'custom-panic-task');
    setIsPanicMode(true);
    
    if (customEndTime) {
      setActivePanicEndTime(new Date(customEndTime).toISOString());
    } else {
      const computedEnd = new Date(Date.now() + selectedMinutes * 60000);
      setActivePanicEndTime(computedEnd.toISOString());
    }
    
    // Set timer count directly to the time selected by the user
    setSecondsLeft(selectedMinutes * 60);
    
    generateSprints();
  };

  // Trigger Bland.ai AI Voice Call Emergency Rescue
  const triggerBlandCall = async () => {
    const phone = userProfile?.phoneNumber || "+15674025498";

    setBlandCallState('calling');
    setBlandCallError('');

    const activeSprint = sprintPlan[activeSprintIndex];
    const taskName = customTaskTitle.trim() || (targetTask ? targetTask.title : "Emergency Sprint");
    const sprintInfoText = activeSprint 
      ? `Their current active focus sprint segment is: "${activeSprint.text}" (duration ${activeSprint.duration} minutes).`
      : "";

    const systemInstructionPrompt = `You are Karl from SaveMyDay. Deliver this urgent focus alert to ${userProfile?.name || 'Saver'}: "Emergency Alert! Let's rescue the task '${taskName}' right now. Start your focus sprint timer, drop all distractions, and begin!" After delivering this message, say "Goodbye!" and hang up the call immediately. DO NOT say anything else. DO NOT ask any questions or wait for a response. End the call now.`;

    try {
      const res = await fetch('/api/bland/call', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          phone_number: phone,
          voice: userProfile?.voiceSelection || 'a24c43d3-f448-4fea-a498-a9287f7cabf3',
          task: systemInstructionPrompt
        })
      });

      const data = await res.json();
      if (res.ok && data.success) {
        setBlandCallState('success');
      } else if (data.is_simulated_fallback) {
        setBlandCallState('success');
        triggerVirtualCall(systemInstructionPrompt);
      } else {
        setBlandCallState('error');
        let errorMsg = data.error || "Failed to trigger emergency call.";
        if (errorMsg.includes("International rate limit exceeded") || errorMsg.includes("rate limit") || errorMsg.includes("limit")) {
          errorMsg = `${errorMsg} (Bland.ai Free Tier Limit: Outbound calls to international numbers require a custom API key. Please add your own BLAND_API_KEY in platform secrets / settings to call non-US numbers.)`;
        }
        setBlandCallError(errorMsg);
      }
    } catch (err: any) {
      setBlandCallState('error');
      setBlandCallError(err.message || "Network error placing emergency call.");
    }

    setTimeout(() => {
      setBlandCallState('idle');
    }, 5000);
  };

  // Generate sprint plan by calling Gemini proxy
  const generateSprints = async () => {
    if (!targetTask && !customTaskTitle.trim()) return;
    setIsPlanGenerating(true);
    
    // Calculate total minutes available from now until the active panic end time (or customEndTime or deadline)
    const targetTimeStr = activePanicEndTime || (customEndTime ? new Date(customEndTime).toISOString() : (targetTask ? targetTask.deadline : new Date(Date.now() + selectedMinutes * 60000).toISOString()));
    const targetTime = new Date(targetTimeStr);
    const now = new Date();
    const diffMs = targetTime.getTime() - now.getTime();
    const totalMinutesAvailable = Math.max(5, Math.floor(diffMs / 60000));
    
    const taskTitle = customTaskTitle.trim() || (targetTask ? targetTask.title : "Emergency Sprint");
    const taskDesc = targetTask ? (targetTask.description || '') : '';
    
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [
            { 
              role: 'user', 
              content: `Generate an emergency sprint plan for the task "${taskTitle}" (${taskDesc}) that must end by ${targetTime.toLocaleTimeString()}. Stated completion level is ${statedProgress}%. We have exactly ${totalMinutesAvailable} minutes available. Please generate EXACTLY 3 successive sprints whose durations sum to exactly ${totalMinutesAvailable} minutes. Return it in the [SPRINT_PLAN: ...] block.` 
            }
          ],
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const text = data.text;
        let parsed: any = null;
        const marker = "[SPRINT_PLAN:";
        const markerIndex = text.toUpperCase().indexOf(marker);
        if (markerIndex !== -1) {
          const jsonStart = text.indexOf("{", markerIndex);
          if (jsonStart !== -1) {
            let braceCount = 0;
            let jsonEnd = -1;
            for (let i = jsonStart; i < text.length; i++) {
              const char = text[i];
              if (char === "{") braceCount++;
              else if (char === "}") {
                braceCount--;
                if (braceCount === 0) {
                  jsonEnd = i + 1;
                  break;
                }
              }
            }
            if (jsonEnd !== -1) {
              const jsonStr = text.substring(jsonStart, jsonEnd);
              try {
                parsed = JSON.parse(jsonStr);
              } catch (e) {
                console.error("Failed to parse sprint plan JSON", e);
              }
            }
          }
        }

        if (parsed && parsed.sprints) {
          setSprintPlan(parsed.sprints);
          setActiveSprintIndex(0);
          // Count down from the user's selected total duration
          setSecondsLeft(selectedMinutes * 60);
        } else {
          // Fallback sprints dynamically sized based on totalMinutesAvailable
          const s1 = Math.max(1, Math.floor(totalMinutesAvailable * 0.3));
          const s2 = Math.max(1, Math.floor(totalMinutesAvailable * 0.5));
          const s3 = Math.max(1, totalMinutesAvailable - s1 - s2);
          
          setSprintPlan([
            { id: 's1', duration: s1, text: `Review requirements & outline core structure` },
            { id: 's2', duration: s2, text: `Main execution & drafting of core features/sections` },
            { id: 's3', duration: s3, text: `Review, proofread/test & finalize submission` }
          ]);
          setActiveSprintIndex(0);
          setSecondsLeft(selectedMinutes * 60);
        }
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsPlanGenerating(false);
    }
  };

  // Sprint Timer logic
  useEffect(() => {
    if (timerActive && secondsLeft > 0) {
      timerRef.current = setInterval(() => {
        setSecondsLeft(prev => prev - 1);
      }, 1000);
    } else if (secondsLeft === 0 && timerActive) {
      setTimerActive(false);
      clearInterval(timerRef.current);
      // Play alarm / pulse
      confetti({ particleCount: 80, spread: 50, colors: ['#FF3B5C'] });
      alert(`⏱️ Sprint Complete! Review progress and unlock the next segment.`);
    }

    return () => clearInterval(timerRef.current);
  }, [timerActive, secondsLeft]);

  const handleStartSprint = (index: number) => {
    if (index !== activeSprintIndex) return; // Locked
    setTimerActive(!timerActive);
  };

  const handleCompleteSprint = (index: number) => {
    if (index !== activeSprintIndex) return;
    setTimerActive(false);
    clearInterval(timerRef.current);

    if (activeSprintIndex < sprintPlan.length - 1) {
      const nextIdx = activeSprintIndex + 1;
      setActiveSprintIndex(nextIdx);
      // Let the timer continue counting down, or set to the next segment's ratio if they prefer.
      // But keeping the user's selected duration countdown is extremely clean.
      confetti({ particleCount: 60, colors: ['#30D158'] });
    } else {
      // Completed all sprints!
      alert("🏆 Incredible! You completed all emergency rescue sprints! Ready to finish the task?");
      confetti({ particleCount: 150, spread: 80 });
    }
  };

  const handleMarkTaskCompleted = () => {
    if (targetTask) {
      toggleTaskStatus(targetTask.id);
    } else {
      alert(`🎉 Congratulations! You have successfully completed: "${customTaskTitle || "Emergency Sprint"}"!`);
    }
    setIsPanicMode(false);
    setPanicTaskId(null);
  };

  // Convert seconds to format
  const getTimerString = () => {
    const m = Math.floor(secondsLeft / 60);
    const s = secondsLeft % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const activeSprint = sprintPlan[activeSprintIndex];

  return (
    <div className={`space-y-6 max-w-7xl mx-auto pb-12 relative transition-all duration-500 ${isPanicMode ? 'bg-gradient-to-b from-[#180509] to-[#0A0A0F] -m-4 md:-m-8 p-4 md:p-8 min-h-[100vh]' : ''}`}>
      
      {/* 1. Focus Lock Dimming Overlay */}
      {isPanicMode && isFocusLock && (
        <div id="focus-lock-overlay" className="fixed inset-0 bg-[#07070B] z-40 flex flex-col items-center justify-center p-6 space-y-6 text-center animate-fade-in">
          <div className="space-y-1">
            <span className="text-accent-red font-mono text-xs uppercase tracking-widest font-black animate-pulse">🔒 FOCUS LOCK MODE ENFORCED</span>
            <h2 className="text-3xl font-display font-black text-white pl-2">
              {customTaskTitle || targetTask?.title || "Emergency Sprint"}
            </h2>
          </div>

          {/* Large timer inside overlay */}
          <div className="p-8 bg-[#111118]/80 border border-accent-red/20 rounded-full w-64 h-64 flex flex-col items-center justify-center shadow-[0_0_50px_rgba(255,59,92,0.15)] animate-pulse">
            <span className="text-[10px] font-mono text-text-secondary uppercase">Sprint Remaining</span>
            <span className="text-5xl font-mono font-black text-accent-red">{getTimerString()}</span>
            <span className="text-[11px] text-text-primary px-3 text-center mt-2 font-semibold italic truncate max-w-[200px]">
              {activeSprint?.text || "Rescue session in progress"}
            </span>
          </div>

          <div className="flex space-x-3">
            <button
              onClick={() => setTimerActive(!timerActive)}
              className="px-6 py-2.5 bg-accent-red hover:bg-accent-red/80 text-white font-semibold rounded text-sm transition cursor-pointer"
            >
              {timerActive ? 'Pause Sprint' : 'Resume Sprint'}
            </button>
            <button
              onClick={() => handleCompleteSprint(activeSprintIndex)}
              className="px-6 py-2.5 bg-accent-green hover:bg-accent-green/80 text-white font-semibold rounded text-sm transition cursor-pointer"
            >
              Done with Segment
            </button>
            <button
              onClick={() => setIsFocusLock(false)}
              className="px-4 py-2.5 bg-[#1A1A26] text-text-secondary hover:text-white rounded text-sm border border-[#2A2A3E] transition cursor-pointer"
            >
              Break Focus Lock
            </button>
            <button
              onClick={() => {
                setIsFocusLock(false);
                setIsPanicMode(false);
                setPanicTaskId(null);
              }}
              className="px-4 py-2.5 bg-accent-red/25 text-accent-red hover:bg-accent-red hover:text-white rounded text-sm border border-accent-red/35 transition cursor-pointer font-bold"
            >
              Exit Panic Mode
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 bg-accent-red rounded-full animate-ping" />
            <span className="text-accent-red font-mono font-black text-xs uppercase tracking-wider">Tactical Firefight Console</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-black text-white leading-tight">
            PANIC MODE 🚨
          </h1>
          <p className="text-text-secondary text-sm font-sans mt-1">
            Zero fluff. Just strategic planning to rescue you before the timer hits zero.
          </p>
        </div>

        {isPanicMode && (
          <button
            onClick={() => {
              setIsPanicMode(false);
              setPanicTaskId(null);
            }}
            className="px-5 py-2.5 bg-accent-red hover:bg-accent-red/90 text-white rounded-lg text-sm transition cursor-pointer font-bold shadow-md shadow-accent-red/10 flex items-center space-x-1.5"
          >
            <LogOut size={16} />
            <span>Exit Panic Mode</span>
          </button>
        )}
      </header>

      {/* Case 1: Panic Mode is NOT Active (Trigger Entry screen) */}
      {!isPanicMode ? (
        <section className="bg-[#111118] border border-accent-red/25 rounded-2xl p-6 md:p-8 space-y-6 max-w-2xl mx-auto shadow-[0_0_50px_rgba(255,59,92,0.05)] relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 text-accent-red/5 pointer-events-none">
            <Flame size={120} />
          </div>

          <div className="flex items-start space-x-4">
            <div className="p-3 bg-accent-red/15 text-accent-red border border-accent-red/30 rounded-xl">
              <ShieldAlert size={32} className="animate-pulse" />
            </div>
            <div className="space-y-1">
              <h2 className="text-xl font-display font-black text-white">EMERGENCY RESCUE DECK</h2>
              <p className="text-text-secondary text-sm leading-relaxed">
                Choose the task in crisis or enter a custom title. SaveMyDay AI will build a personalized sprint outline to help you finish in time.
              </p>
            </div>
          </div>

          <div className="space-y-4 pt-2">
            {/* Task Selection & Custom Title Options */}
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1.5 uppercase">Select Task in Crisis</label>
                <select
                  value={selectedTaskId}
                  onChange={(e) => {
                    setSelectedTaskId(e.target.value);
                    if (e.target.value) {
                      setCustomTaskTitle('');
                    }
                  }}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-accent-red focus:ring-1 focus:ring-accent-red"
                >
                  <option value="">-- Choose a high-stakes task --</option>
                  {tasks.filter(t => t.status !== 'done').map(t => (
                    <option key={t.id} value={t.id}>
                      ⏳ {t.title} (Due: {new Date(t.deadline).toLocaleTimeString()})
                    </option>
                  ))}
                </select>
              </div>

              <div className="relative flex py-1 items-center">
                <div className="flex-grow border-t border-[#2A2A3E]/70"></div>
                <span className="flex-shrink mx-4 text-text-muted text-[10px] font-mono uppercase tracking-wider">OR ENTER CUSTOM TASK</span>
                <div className="flex-grow border-t border-[#2A2A3E]/70"></div>
              </div>

              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1.5 uppercase">Enter Custom Task Title</label>
                <input
                  type="text"
                  value={customTaskTitle}
                  onChange={(e) => {
                    setCustomTaskTitle(e.target.value);
                    if (e.target.value) {
                      setSelectedTaskId('');
                    }
                  }}
                  placeholder="e.g., Complete math assignment or submit prep slides"
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-4 py-3 text-white text-sm focus:outline-none focus:border-accent-red focus:ring-1 focus:ring-accent-red"
                />
              </div>
            </div>

            {/* Current progress indicator */}
            <div>
              <label className="block text-xs font-mono text-text-secondary mb-1.5 uppercase">Stated Progress Percentage</label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { value: '0', label: '0% (Just starting)' },
                  { value: '25', label: '25% (Draft outline)' },
                  { value: '50', label: '50% (Halfway)' },
                  { value: '75', label: '75% (Almost done)' },
                ].map(opt => (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setStatedProgress(opt.value)}
                    className={`py-2 border rounded text-xs transition cursor-pointer ${
                      statedProgress === opt.value
                        ? 'border-accent-red bg-accent-red/10 text-white font-bold'
                        : 'border-[#2A2A3E] bg-[#1A1A26] text-text-secondary hover:text-white'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Direct Timer Duration Selector */}
            <div className="space-y-2">
              <label className="block text-xs font-mono text-text-secondary uppercase">Select Timer Duration (Minutes)</label>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="number"
                  min="1"
                  max="300"
                  value={selectedMinutes}
                  onChange={(e) => {
                    const val = Math.max(1, parseInt(e.target.value) || 25);
                    setSelectedMinutes(val);
                    // Update targetEndTime for sprint rescue
                    const targetDate = new Date(Date.now() + val * 60000);
                    const tzOffset = targetDate.getTimezoneOffset() * 60000;
                    const localISO = new Date(targetDate.getTime() - tzOffset).toISOString().slice(0, 16);
                    setCustomEndTime(localISO);
                  }}
                  className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-accent-red w-full sm:w-32 font-bold"
                />
                <div className="flex flex-wrap gap-1.5 items-center">
                  {[5, 10, 15, 25, 45, 60].map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => {
                        setSelectedMinutes(m);
                        const targetDate = new Date(Date.now() + m * 60000);
                        const tzOffset = targetDate.getTimezoneOffset() * 60000;
                        const localISO = new Date(targetDate.getTime() - tzOffset).toISOString().slice(0, 16);
                        setCustomEndTime(localISO);
                      }}
                      className={`px-3 py-2 text-xs rounded border transition cursor-pointer ${
                        selectedMinutes === m
                          ? 'bg-accent-red/20 border-accent-red text-white font-bold'
                          : 'bg-[#1A1A26] border-[#2A2A3E] text-text-secondary hover:text-white hover:border-[#48485A]'
                      }`}
                    >
                      {m} Min
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Target End Time customizable section (optional overrides) */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-mono text-text-secondary uppercase">Or Customize Target End Time Override</label>
                {targetTask && (
                  <button
                    type="button"
                    onClick={() => {
                      const dateObj = new Date(targetTask.deadline);
                      const tzOffset = dateObj.getTimezoneOffset() * 60000;
                      const localISO = new Date(dateObj.getTime() - tzOffset).toISOString().slice(0, 16);
                      setCustomEndTime(localISO);
                      
                      const diffMs = dateObj.getTime() - Date.now();
                      const computedMins = Math.max(1, Math.floor(diffMs / 60000));
                      setSelectedMinutes(computedMins);
                    }}
                    className="text-[10px] font-mono text-accent-red hover:underline cursor-pointer"
                  >
                    Reset to Due Date
                  </button>
                )}
              </div>
              <input
                type="datetime-local"
                value={customEndTime}
                onChange={(e) => {
                  setCustomEndTime(e.target.value);
                  if (e.target.value) {
                    const diffMs = new Date(e.target.value).getTime() - Date.now();
                    setSelectedMinutes(Math.max(1, Math.floor(diffMs / 60000)));
                  }
                }}
                className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-4 py-2.5 text-white text-sm focus:outline-none focus:border-accent-red focus:ring-1 focus:ring-accent-red"
              />
            </div>

            <button
              onClick={handlePanicActivation}
              className="w-full py-3.5 bg-accent-red hover:bg-accent-red/90 text-white font-bold rounded-lg flex items-center justify-center space-x-2 transition cursor-pointer shadow-lg shadow-accent-red/15 mt-2"
            >
              <Flame size={18} className="animate-pulse" />
              <span>ACTIVATE EMERGENCY SPRINT 🚨</span>
            </button>
          </div>
        </section>
      ) : (
        /* Case 2: Panic Mode is ACTIVE (Dramatized layout) */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Console: Left 2 columns */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Giant countdown board */}
            <div className="bg-[#111118]/80 border border-accent-red/30 rounded-2xl p-6 text-center space-y-3 relative overflow-hidden shadow-[0_0_50px_rgba(255,59,92,0.1)]">
              <span className="text-xs font-mono font-black text-accent-red uppercase tracking-widest animate-pulse">🚨 SYSTEM TIME TO CRITICAL CRISIS COLLAPSE</span>
              <h2 className="text-white font-black text-2xl line-clamp-1">{customTaskTitle || targetTask?.title || "Emergency Sprint"}</h2>
              
              {/* Monospace clock face */}
              <div className="py-4">
                <span className="text-6xl md:text-8xl font-mono font-black tracking-tighter text-accent-red font-semibold select-none filter drop-shadow-[0_0_12px_rgba(255,59,92,0.4)] animate-pulse">
                  {countdownString}
                </span>
              </div>

              <div className="flex items-center justify-center space-x-2 text-xs text-text-secondary font-sans">
                <AlertTriangle size={14} className="text-accent-amber" />
                <span>Urgency mode is active. Let's finish the sub-segments one by one.</span>
              </div>
            </div>

            {/* AI Sprint Planner & timeline */}
            <div className="bg-[#111118] border border-[#2A2A3E] rounded-2xl p-6 space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-[#2A2A3E]">
                <h3 className="font-display font-black text-sm text-white uppercase tracking-wider flex items-center space-x-2">
                  <Sparkles size={16} className="text-accent-purple" />
                  <span>AI Tactical Rescue Timeline</span>
                </h3>
                <button
                  onClick={generateSprints}
                  disabled={isPlanGenerating}
                  className="text-xs font-mono text-text-secondary hover:text-white flex items-center space-x-1"
                >
                  <RefreshCw size={12} className={isPlanGenerating ? 'animate-spin' : ''} />
                  <span>Regenerate Plan</span>
                </button>
              </div>

              {isPlanGenerating ? (
                <div className="py-12 text-center space-y-3">
                  <div className="w-8 h-8 border-4 border-accent-purple border-t-transparent rounded-full animate-spin mx-auto" />
                  <p className="text-sm font-mono text-text-secondary">Gemini is writing the fire plan...</p>
                </div>
              ) : (
                <div className="relative pl-6 space-y-6 before:absolute before:top-1.5 before:left-2 before:bottom-1.5 before:w-0.5 before:bg-[#2A2A3E]">
                  {sprintPlan.map((sprint, index) => {
                    const isActive = index === activeSprintIndex;
                    const isCompleted = index < activeSprintIndex;
                    
                    return (
                      <div key={sprint.id} className="relative group">
                        {/* Node timeline circle */}
                        <div className={`absolute -left-[22px] w-3 h-3 rounded-full border-2 top-1.5 ${
                          isActive 
                            ? 'bg-accent-red border-accent-red animate-ping' 
                            : isCompleted 
                              ? 'bg-accent-green border-accent-green' 
                              : 'bg-[#111118] border-[#2A2A3E]'
                        }`} />
                        {/* Static duplicate for animation center */}
                        {isActive && <div className="absolute -left-[22px] w-3 h-3 rounded-full border-2 top-1.5 bg-accent-red border-accent-red z-10" />}

                        <div className={`p-4 rounded-xl border transition flex flex-col md:flex-row md:items-center md:justify-between gap-4 ${
                          isActive 
                            ? 'bg-[#1A1A26] border-accent-red shadow-lg' 
                            : 'bg-[#111118] border-[#2D2D44] opacity-50'
                        }`}>
                          <div className="space-y-1">
                            <span className="text-[10px] font-mono text-text-secondary uppercase">
                              Sprint {index + 1} — {sprint.duration} Mins {isCompleted && '✓'}
                            </span>
                            <h4 className={`text-sm font-bold ${isActive ? 'text-white' : 'text-text-secondary'}`}>
                              {sprint.text}
                            </h4>
                          </div>

                          <div className="flex items-center space-x-2 flex-shrink-0">
                            {isActive && (
                              <>
                                <button
                                  onClick={() => handleStartSprint(index)}
                                  className="px-3 py-1.5 bg-accent-red hover:bg-accent-red/80 text-white font-bold rounded text-xs transition cursor-pointer"
                                >
                                  {timerActive ? 'Pause' : 'Start Timer'}
                                </button>
                                <button
                                  onClick={() => handleCompleteSprint(index)}
                                  className="px-3 py-1.5 bg-accent-green hover:bg-accent-green/80 text-white font-bold rounded text-xs transition cursor-pointer"
                                >
                                  Segment Done
                                </button>
                              </>
                            )}
                            {!isActive && !isCompleted && (
                              <span className="text-xs text-text-muted font-mono">🔒 Locked until previous done</span>
                            )}
                            {isCompleted && (
                              <span className="text-xs text-accent-green font-mono">✓ Competed</span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>

          {/* Right Panel: Active timer & Focus controls */}
          <div className="space-y-6">
            
            {/* Big ticking timer */}
            <div className="bg-[#111118] border border-[#2A2A3E] rounded-2xl p-6 text-center space-y-4">
              <h3 className="font-display font-black text-xs uppercase tracking-wider text-text-secondary">ACTIVE SPRINT TIMER</h3>
              
              <div className="w-48 h-48 rounded-full border-4 border-accent-red/20 mx-auto flex flex-col items-center justify-center relative bg-[#1A1A26]/40">
                {/* Visual Ring progress overlay (simulated) */}
                <div className="absolute inset-0 rounded-full border-4 border-accent-red animate-pulse pointer-events-none opacity-10" />
                
                <span className="text-4xl font-mono font-black text-white">{getTimerString()}</span>
                <span className="text-[10px] font-mono text-text-secondary mt-1 uppercase">Sprint {activeSprintIndex + 1} of 3</span>
              </div>

              <div className="flex flex-col gap-2 pt-2">
                <div className="flex justify-center space-x-2">
                  <button
                    onClick={() => setTimerActive(!timerActive)}
                    disabled={sprintPlan.length === 0}
                    className="px-4 py-2 bg-[#1A1A26] border border-[#2A2A3E] hover:text-white rounded text-xs font-mono font-bold transition cursor-pointer disabled:opacity-50 flex-grow"
                  >
                    {timerActive ? 'Pause' : 'Start'}
                  </button>
                  <button
                    onClick={() => {
                      setTimerActive(false);
                      if (activeSprint) setSecondsLeft(activeSprint.duration * 60);
                    }}
                    disabled={sprintPlan.length === 0}
                    className="px-4 py-2 bg-[#1A1A26] border border-[#2A2A3E] hover:text-white rounded text-xs font-mono font-bold transition cursor-pointer disabled:opacity-50 flex-grow"
                  >
                    Reset
                  </button>
                </div>
                <button
                  onClick={() => {
                    setIsPanicMode(false);
                    setPanicTaskId(null);
                  }}
                  className="w-full py-2 bg-accent-red hover:bg-accent-red/90 text-white rounded text-xs font-mono font-bold transition cursor-pointer flex items-center justify-center space-x-1"
                >
                  <LogOut size={12} />
                  <span>Exit Panic Mode</span>
                </button>
              </div>
            </div>

            {/* 🚨 BLAND AI EMERGENCY VOICE CALL CARD */}
            <div className="bg-[#111118] border border-accent-blue/30 rounded-2xl p-5 space-y-3 relative overflow-hidden">
              <div className="flex items-center space-x-2">
                <span className="text-sm">📞</span>
                <h4 className="font-display font-black text-xs uppercase tracking-wider text-white">SaveMyDay Voice Rescue (Bland.ai)</h4>
              </div>
              <p className="text-[11px] text-text-secondary leading-normal">
                Stuck and procrastinating? Force yourself to act. Have Karl call your phone right now to read your active segment instructions and verbally motivate you!
              </p>

              {userProfile?.phoneNumber ? (
                <div className="space-y-2">
                  <button
                    onClick={triggerBlandCall}
                    disabled={blandCallState === 'calling'}
                    className={`w-full py-2 rounded font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer border ${
                      blandCallState === 'calling'
                        ? 'bg-accent-blue/10 border-accent-blue/50 text-accent-blue cursor-wait'
                        : blandCallState === 'success'
                        ? 'bg-accent-green/10 border-accent-green/50 text-accent-green'
                        : blandCallState === 'error'
                        ? 'bg-accent-red/10 border-accent-red/50 text-accent-red'
                        : 'bg-accent-blue hover:bg-accent-blue/80 border-transparent text-white shadow-md shadow-accent-blue/10'
                    }`}
                  >
                    {blandCallState === 'calling' ? (
                      <span>Placing Call to {userProfile.phoneNumber}...</span>
                    ) : blandCallState === 'success' ? (
                      <span>✅ Success! Check your phone!</span>
                    ) : blandCallState === 'error' ? (
                      <span>❌ Failed to trigger call.</span>
                    ) : (
                      <span>🚨 Karl: Call My Phone Now</span>
                    )}
                  </button>
                  {blandCallError && (
                    <p className="text-[9px] text-accent-red font-mono bg-accent-red/5 p-1 rounded border border-accent-red/10">
                      Error: {blandCallError}
                    </p>
                  )}
                </div>
              ) : (
                <div className="p-2.5 bg-accent-amber/5 border border-accent-amber/20 rounded-lg text-center">
                  <p className="text-[10px] text-accent-amber font-mono leading-normal">
                    ⚠️ Phone number not configured. Save your mobile number in Settings first to enable Voice Rescue.
                  </p>
                </div>
              )}
            </div>

            {/* Focus Lock Module */}
            <div className="bg-[#111118] border border-[#2A2A3E] rounded-2xl p-6 space-y-4">
              <div className="flex items-start space-x-3">
                <EyeOff className="text-accent-purple flex-shrink-0 mt-0.5" size={18} />
                <div className="space-y-1">
                  <h4 className="font-display font-bold text-sm text-white">Focus Lock Mode</h4>
                  <p className="text-text-secondary text-xs leading-relaxed">
                    Toggle this to overlay a clean full-screen countdown panel and dim all outer clutter. Can only be escaped with the exit control.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsFocusLock(true)}
                disabled={sprintPlan.length === 0}
                className="w-full py-2.5 bg-accent-purple hover:bg-accent-purple/85 text-white font-semibold rounded-lg text-xs transition cursor-pointer disabled:opacity-50"
              >
                🔒 ACTIVATE FOCUS LOCK
              </button>
            </div>

            {/* Panic Finish Card */}
            <div className="bg-[#111118] border border-accent-green/20 rounded-2xl p-6 text-center space-y-4">
              <CheckSquare className="text-accent-green mx-auto" size={32} />
              <div className="space-y-1">
                <h4 className="font-display font-black text-sm text-white">MISSION COMPLETED?</h4>
                <p className="text-text-secondary text-xs leading-relaxed">
                  Have you successfully rescued this task from missing its deadline? Log a Panic Save!
                </p>
              </div>
              <button
                onClick={handleMarkTaskCompleted}
                className="w-full py-2.5 bg-accent-green hover:bg-accent-green/85 text-white font-bold rounded-lg text-xs transition cursor-pointer"
              >
                ✓ LOG PANIC SAVE 🔴
              </button>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
