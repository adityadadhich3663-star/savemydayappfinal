import React, { useState, useEffect } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { UserProfile, WidgetPref } from '../../types';
import { 
  User, Shield, Eye, EyeOff, MoveUp, MoveDown, GripVertical, 
  Check, Sun, Moon, Calendar, LogOut, Trash2, AlertTriangle, Save 
} from 'lucide-react';
import { playNotificationSound } from '../../utils/sound';

export default function Settings() {
  const {
    userProfile,
    saveProfile,
    widgets,
    saveWidgets,
    resetWidgets,
    toggleWidgetVisibility,
    moveWidget,
    firebaseUser,
    loginWithGoogle,
    signOut,
    triggerVirtualCall
  } = useLMLS();

  // Local state for profile form
  const [profileName, setProfileName] = useState(userProfile?.name || 'Saver');
  const [peakEnergy, setPeakEnergy] = useState<'morning' | 'afternoon' | 'night'>(userProfile?.peakEnergyTime || 'morning');
  const [phoneNumber, setPhoneNumber] = useState(userProfile?.phoneNumber || '+15674025498');
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // New Custom UX States
  const [notificationSound, setNotificationSound] = useState(() => {
    return localStorage.getItem('lmls_notification_sound') || 'chime';
  });
  const [customGreeting, setCustomGreeting] = useState(() => {
    return localStorage.getItem('lmls_custom_greeting') || '';
  });

  // Bland.ai calling state
  const [voiceSelection, setVoiceSelection] = useState(userProfile?.voiceSelection || 'a24c43d3-f448-4fea-a498-a9287f7cabf3');
  const [callTestingState, setCallTestingState] = useState<'idle' | 'calling' | 'success' | 'error'>('idle');
  const [callErrorMsg, setCallErrorMsg] = useState('');

  // Twilio number import states with default credentials from user
  const [twilioSid, setTwilioSid] = useState('AC42309a5e1f46e42c3d5a3e709ca85229');
  const [twilioToken, setTwilioToken] = useState('840634f8d5bfb212d9a4c667650a8782');
  const [twilioPhoneNumber, setTwilioPhoneNumber] = useState('');
  const [importState, setImportState] = useState<'idle' | 'importing' | 'success' | 'error'>('idle');
  const [importMessage, setImportMessage] = useState('');

  // Local state for layout reordering
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

  // Appearance state (Light vs Dark mode)
  const [isLightMode, setIsLightMode] = useState(() => {
    return document.body.classList.contains('light-mode');
  });

  // Privacy states
  const [isTelemetryEnabled, setIsTelemetryEnabled] = useState(() => {
    return localStorage.getItem('lmls_telemetry') !== 'false';
  });

  useEffect(() => {
    if (userProfile) {
      setProfileName(userProfile.name);
      setPeakEnergy(userProfile.peakEnergyTime);
      setPhoneNumber(userProfile.phoneNumber || '+15674025498');
      setVoiceSelection(userProfile.voiceSelection || 'a24c43d3-f448-4fea-a498-a9287f7cabf3');
    }
  }, [userProfile]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveStatus('saving');
    
    const updatedProfile: UserProfile = {
      name: profileName,
      peakEnergyTime: peakEnergy,
      onboardingComplete: true,
      panicSaveCount: userProfile?.panicSaveCount || 0,
      joinedAt: userProfile?.joinedAt || new Date().toISOString(),
      phoneNumber: phoneNumber,
      voiceSelection: voiceSelection
    };

    localStorage.setItem('lmls_notification_sound', notificationSound);
    localStorage.setItem('lmls_custom_greeting', customGreeting);

    await saveProfile(updatedProfile);
    setSaveStatus('saved');
    setTimeout(() => setSaveStatus('idle'), 2000);
  };

  const triggerTestCall = async () => {
    if (!phoneNumber.trim()) {
      alert("Please enter a valid phone number first (e.g. +1234567890).");
      return;
    }

    setCallTestingState('calling');
    setCallErrorMsg('');

    try {
      const response = await fetch('/api/bland/call', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          phone_number: phoneNumber,
          voice: voiceSelection,
          task: `You are Karl from SaveMyDay. Deliver this test message to ${profileName || 'Saver'}: "Success! Your voice integration is fully configured and ready to rescue your deadlines!" After delivering this, say "Goodbye!" and hang up the call immediately. DO NOT say anything else. DO NOT ask any questions or wait for a response. End the call now.`
        })
      });

      const data = await response.json();
      if (response.ok && data.success) {
        setCallTestingState('success');
      } else if (data.is_simulated_fallback) {
        setCallTestingState('success');
        triggerVirtualCall(
          `You are Karl from SaveMyDay. Deliver this test message to ${profileName || 'Saver'}: "Success! Your voice integration is fully configured and ready to rescue your deadlines!" After delivering this, say "Goodbye!" and hang up the call immediately. DO NOT say anything else. DO NOT ask any questions or wait for a response. End the call now.`
        );
      } else {
        setCallTestingState('error');
        let errorMsg = data.error || "Call failed to trigger.";
        if (errorMsg.includes("International rate limit exceeded") || errorMsg.includes("rate limit") || errorMsg.includes("limit")) {
          errorMsg = `${errorMsg} (Bland.ai Free Tier Limit: Outbound calls to international numbers require a custom API key. Please add your own BLAND_API_KEY in platform secrets / settings to call non-US numbers.)`;
        }
        setCallErrorMsg(errorMsg);
      }
    } catch (err: any) {
      setCallTestingState('error');
      setCallErrorMsg(err.message || "Network error triggering call.");
    }

    setTimeout(() => {
      setCallTestingState('idle');
    }, 5000);
  };

  const handleImportTwilio = async () => {
    if (!twilioPhoneNumber) {
      setImportState('error');
      setImportMessage('Please specify the Twilio Phone Number you wish to import (e.g., +1234567890).');
      return;
    }

    setImportState('importing');
    setImportMessage('');

    try {
      const response = await fetch('/api/bland/import-twilio', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          twilio_sid: twilioSid || undefined,
          twilio_token: twilioToken || undefined,
          phone_number: twilioPhoneNumber
        })
      });

      const data = await response.json();

      if (response.ok && data.success) {
        setImportState('success');
        setImportMessage(data.message || 'Twilio number successfully imported into your Bland.ai account!');
      } else {
        setImportState('error');
        setImportMessage(data.error || 'Failed to import Twilio number. Please check your credentials and try again.');
      }
    } catch (err: any) {
      setImportState('error');
      setImportMessage(err.message || 'Network error importing Twilio number.');
    }
  };

  const toggleAppearance = (lightMode: boolean) => {
    setIsLightMode(lightMode);
    if (lightMode) {
      document.body.classList.add('light-mode');
      localStorage.setItem('lmls_theme', 'light');
    } else {
      document.body.classList.remove('light-mode');
      localStorage.setItem('lmls_theme', 'dark');
    }
  };

  const handleToggleTelemetry = () => {
    const nextVal = !isTelemetryEnabled;
    setIsTelemetryEnabled(nextVal);
    localStorage.setItem('lmls_telemetry', String(nextVal));
  };

  const handleClearLocalState = () => {
    if (window.confirm("Are you sure you want to purge all local sandbox cache, including saved tasks, local habits, and chat transcripts? This action is permanent!")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  // Drag and drop handlers for layout widgets
  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
  };

  const handleDrop = (index: number) => {
    if (draggedIndex === null) return;
    const updated = [...widgets];
    const [draggedItem] = updated.splice(draggedIndex, 1);
    updated.splice(index, 0, draggedItem);
    saveWidgets(updated);
    setDraggedIndex(null);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12 animate-fade-in" id="settings-view">
      <header>
        <h1 className="text-3xl md:text-4xl font-display font-black text-white leading-tight">
          System <span className="text-accent-blue">Settings</span>
        </h1>
        <p className="text-text-secondary text-sm font-mono mt-1">
          Configure profile details, layout controls, theme overrides, and security modules.
        </p>
      </header>

      {/* 1. PROFILE SECTION AT THE TOP */}
      <section className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-6 space-y-6" id="settings-profile-section">
        <div className="flex items-center space-x-3 pb-4 border-b border-[#2A2A3E]">
          <div className="p-2 bg-accent-blue/10 text-accent-blue rounded-lg">
            <User size={20} />
          </div>
          <div>
            <h2 className="font-display font-black text-sm text-white uppercase tracking-wider">User Profile Identity</h2>
            <p className="text-text-secondary text-xs mt-0.5">Customize your nickname and energy rhythm parameters.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Avatar display card */}
          <div className="bg-[#161622] border border-[#2A2A3E] p-4 rounded-xl flex flex-col items-center justify-center text-center space-y-3">
            {firebaseUser?.photoURL ? (
              <img 
                src={firebaseUser.photoURL} 
                alt="Avatar" 
                className="w-16 h-16 rounded-full border-2 border-accent-blue" 
                referrerPolicy="no-referrer" 
              />
            ) : (
              <div className="w-16 h-16 rounded-full bg-accent-blue/20 border-2 border-accent-blue text-accent-blue flex items-center justify-center text-2xl font-bold font-mono">
                {profileName.charAt(0).toUpperCase()}
              </div>
            )}
            <div>
              <div className="text-sm font-bold text-white">{profileName}</div>
              <div className="text-xs text-text-secondary font-mono mt-0.5">
                {firebaseUser ? 'Cloud Account' : 'Sandbox Account'}
              </div>
            </div>
            
            {firebaseUser ? (
              <div className="flex flex-col items-center space-y-2 w-full">
                <div className="text-[11px] text-accent-green font-semibold bg-accent-green/5 border border-accent-green/20 px-2.5 py-1 rounded-full flex items-center space-x-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent-green animate-pulse" />
                  <span>Google Connected</span>
                </div>
                <button
                  type="button"
                  onClick={signOut}
                  className="w-full py-1.5 px-3 bg-accent-red/10 hover:bg-accent-red/20 text-accent-red border border-accent-red/20 hover:border-accent-red/40 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition cursor-pointer"
                >
                  <LogOut size={13} />
                  <span>Log Out</span>
                </button>
              </div>
            ) : (
              <div className="flex flex-col items-center space-y-2 w-full">
                <div className="text-[11px] text-text-secondary bg-[#1A1A26] border border-[#2A2A3E] px-2.5 py-1 rounded-full">
                  Local Storage Mode
                </div>
                <button
                  type="button"
                  onClick={loginWithGoogle}
                  className="w-full py-1.5 px-3 bg-accent-blue/10 hover:bg-accent-blue/20 text-accent-blue border border-accent-blue/20 hover:border-accent-blue/40 rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition cursor-pointer"
                >
                  <Calendar size={13} />
                  <span>Log In / Sync</span>
                </button>
              </div>
            )}
          </div>

          {/* Profile Form */}
          <form onSubmit={handleSaveProfile} className="md:col-span-2 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Display Nickname</label>
                <input
                  type="text"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Peak Mental Performance</label>
                <select
                  value={peakEnergy}
                  onChange={(e: any) => setPeakEnergy(e.target.value)}
                  className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue"
                >
                  <option value="morning">🌅 Morning Peak (06:00 - 12:00)</option>
                  <option value="afternoon">☀️ Afternoon Peak (12:00 - 18:00)</option>
                  <option value="night">🌌 Night Peak (18:00 - 02:00)</option>
                </select>
              </div>

              {/* Phone Number Field */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Mobile Phone Number (E.164 Format e.g., +15551234567)</label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="e.g., +15551234567"
                  className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue placeholder-text-muted"
                />
                <p className="text-[11px] text-text-muted font-mono">Required for receiving live crisis call notifications from Sarah.</p>
              </div>

              {/* Custom Greeting Message */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Custom Dashboard Greeting Message (Leave blank for default)</label>
                <input
                  type="text"
                  value={customGreeting}
                  onChange={(e) => setCustomGreeting(e.target.value)}
                  placeholder="e.g., Let's destroy these deadlines!, Welcome back, Master"
                  className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue placeholder-text-muted"
                />
              </div>

              {/* Preferred Notification Sound */}
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Preferred Notification Sound</label>
                <div className="flex space-x-2">
                  <select
                    value={notificationSound}
                    onChange={(e) => setNotificationSound(e.target.value)}
                    className="flex-1 bg-[#161622] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue"
                  >
                    <option value="chime">🎵 Elegant Chime (Triad Harmonic)</option>
                    <option value="beep">🔔 Crisp Beep (A5 Sine wave)</option>
                    <option value="bell">🛎️ FM Resonant Bell</option>
                    <option value="alert">🚨 Sci-Fi Alert Sweep</option>
                    <option value="none">🔇 Silent (Visual Notification Only)</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => playNotificationSound(notificationSound)}
                    className="px-4 py-2 bg-[#1f1f2e] hover:bg-[#2F2F44] text-white border border-[#3A3A54] rounded-lg text-xs font-semibold flex items-center justify-center space-x-1.5 transition cursor-pointer"
                  >
                    <span>🔊 Test Audio</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div>
                {firebaseUser ? (
                  <button
                    type="button"
                    onClick={signOut}
                    className="text-xs text-text-secondary hover:text-accent-red flex items-center space-x-1.5 transition cursor-pointer"
                  >
                    <LogOut size={13} />
                    <span>Disconnect Google Account</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={loginWithGoogle}
                    className="text-xs text-accent-blue hover:underline flex items-center space-x-1.5 transition cursor-pointer"
                  >
                    <Calendar size={13} />
                    <span>Sync with Google Workspace</span>
                  </button>
                )}
              </div>

              <button
                type="submit"
                disabled={saveStatus === 'saving'}
                className="px-4 py-2 bg-accent-blue hover:bg-accent-blue/80 disabled:opacity-50 text-white font-semibold rounded-lg text-xs flex items-center space-x-2 transition cursor-pointer"
                id="save-profile-btn"
              >
                {saveStatus === 'saving' ? (
                  <span>Saving...</span>
                ) : saveStatus === 'saved' ? (
                  <>
                    <Check size={14} />
                    <span>Saved!</span>
                  </>
                ) : (
                  <>
                    <Save size={14} />
                    <span>Save Identity</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* BLAND.AI VOICE ASSISTANT SETUP SECTION */}
      <section className="bg-[#111118] border border-accent-blue/30 rounded-xl p-6 space-y-4" id="settings-bland-section">
        <div className="flex items-center space-x-3 pb-4 border-b border-[#2A2A3E]">
          <div className="p-2 bg-accent-blue/10 text-accent-blue rounded-lg">
            <span className="text-lg">📞</span>
          </div>
          <div>
            <h2 className="font-display font-black text-sm text-white uppercase tracking-wider">Karl Voice Assistant Integration (Bland.ai)</h2>
            <p className="text-text-secondary text-xs mt-0.5">Integrate hyper-realistic AI voice agents to call your phone during deadline emergencies.</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="p-4 bg-[#161622]/50 border border-[#2A2A3E] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-sm font-bold text-white flex items-center space-x-2">
                <span>Outbound Reminders</span>
                {phoneNumber ? (
                  <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-accent-green/10 text-accent-green border border-accent-green/20 rounded-full">
                    Active Reminders Target: {phoneNumber}
                  </span>
                ) : (
                  <span className="px-2 py-0.5 text-[10px] font-mono font-bold bg-accent-amber/10 text-accent-amber border border-accent-amber/20 rounded-full">
                    No Target Configured
                  </span>
                )}
              </div>
              <p className="text-xs text-text-secondary leading-normal max-w-xl">
                Bland.ai allows our systems to place high-performance voice calls. In high-stress "Panic Mode" sprints, Karl from SaveMyDay will dial your number directly and speak to you with encouraging guidelines, keeping you focused.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#161622]/30 p-4 rounded-xl border border-[#2A2A3E]/60">
            <div className="space-y-1.5">
              <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Select Voice Model (Bland.ai Preset)</label>
              <select
                value={voiceSelection}
                onChange={(e) => setVoiceSelection(e.target.value)}
                className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue"
              >
                <option value="a24c43d3-f448-4fea-a498-a9287f7cabf3">Karl v2 (Deep Professional Male - Recommended)</option>
                <option value="nat">Energetic Female (Nat)</option>
                <option value="sarah">Hyper-Realistic Assistant (Sarah)</option>
                <option value="josh">Calm Professional Male (Josh)</option>
                <option value="default">System Default Voice</option>
              </select>
            </div>

            <div className="flex flex-col justify-end">
              <button
                type="button"
                onClick={triggerTestCall}
                disabled={callTestingState === 'calling' || !phoneNumber}
                className={`w-full py-2 px-4 rounded-lg font-bold text-xs flex items-center justify-center space-x-2 transition cursor-pointer border ${
                  !phoneNumber 
                    ? 'bg-[#1A1A26] border-[#2A2A3E] text-text-muted cursor-not-allowed'
                    : callTestingState === 'calling'
                    ? 'bg-accent-blue/10 border-accent-blue/50 text-accent-blue cursor-wait'
                    : callTestingState === 'success'
                    ? 'bg-accent-green/10 border-accent-green/50 text-accent-green'
                    : callTestingState === 'error'
                    ? 'bg-accent-red/10 border-accent-red/50 text-accent-red'
                    : 'bg-accent-blue hover:bg-accent-blue/80 border-transparent text-white shadow-lg shadow-accent-blue/10'
                }`}
              >
                {callTestingState === 'calling' ? (
                  <>
                    <span className="w-1.5 h-1.5 rounded-full bg-accent-blue animate-ping mr-1" />
                    <span>Placing Call...</span>
                  </>
                ) : callTestingState === 'success' ? (
                  <>
                    <span>✅ Success! Check your phone.</span>
                  </>
                ) : callTestingState === 'error' ? (
                  <>
                    <span>❌ Failed. Try again.</span>
                  </>
                ) : (
                  <>
                    <span>📞 Trigger Live Test Call</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {callErrorMsg && (
            <div className="p-3 bg-accent-red/10 border border-accent-red/20 text-accent-red text-xs rounded-lg font-mono space-y-1.5">
              <div><strong>Bland.ai Error Details:</strong> {callErrorMsg}</div>
              {callErrorMsg.includes("AUTH_FAILURE") && (
                <p className="text-[10px] text-text-secondary leading-normal mt-1">
                  💡 <strong>How to Fix:</strong> Go to your AI Studio project's <strong>Settings / Secrets panel</strong>, add a secret named <code>BLAND_API_KEY</code>, and input your active Bland.ai developer API key. Then restart the application.
                </p>
              )}
            </div>
          )}

          <div className="text-[11px] text-text-muted font-mono bg-[#161622]/20 border border-[#2A2A3E]/30 p-3 rounded-lg space-y-1">
            <span className="text-white font-bold block mb-1">🔑 Bland.ai Integration Credentials:</span>
            <p className="leading-normal">
              By default, SaveMyDay attempts to place crisis calls using our integrated developer system credentials. 
              To configure your own dedicated voice trunk or avoid rate limits, simply add your custom key to the <code>BLAND_API_KEY</code> environment secret.
            </p>
          </div>

          {/* TWILIO OWN NUMBER IMPORT BLOCK */}
          <div className="mt-4 border-t border-[#2A2A3E] pt-4 space-y-3">
            <h3 className="text-xs font-display font-black text-white uppercase tracking-wider">
              📞 Bring Your Own Twilio Number (Optional)
            </h3>
            <p className="text-[11px] text-text-secondary leading-normal">
              Want Bland.ai to dial reminders from your own custom Twilio phone number? Enter your credentials below to register your Twilio number directly onto your Bland.ai dashboard.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Twilio Account SID</label>
                <input
                  type="text"
                  placeholder="AC..."
                  value={twilioSid}
                  onChange={(e) => setTwilioSid(e.target.value)}
                  className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-accent-blue font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Twilio Auth Token</label>
                <input
                  type="password"
                  placeholder="Auth Token"
                  value={twilioToken}
                  onChange={(e) => setTwilioToken(e.target.value)}
                  className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-accent-blue font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[10px] font-mono tracking-wider uppercase text-text-secondary">Twilio Phone Number to Import</label>
                <input
                  type="text"
                  placeholder="e.g. +18885551234"
                  value={twilioPhoneNumber}
                  onChange={(e) => setTwilioPhoneNumber(e.target.value)}
                  className="w-full bg-[#161622] border border-[#2A2A3E] rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-accent-blue font-mono"
                />
              </div>

              <div className="flex items-end">
                <button
                  type="button"
                  onClick={handleImportTwilio}
                  disabled={importState === 'importing'}
                  className={`w-full font-sans font-bold text-xs uppercase tracking-wider py-2 px-4 rounded-lg transition-all flex items-center justify-center space-x-2 ${
                    importState === 'importing'
                      ? 'bg-accent-blue/40 text-white cursor-not-allowed'
                      : 'bg-accent-blue text-white hover:bg-accent-blue/80 cursor-pointer shadow-[0_0_15px_rgba(10,132,255,0.1)]'
                  }`}
                >
                  {importState === 'importing' ? (
                    <span>Importing...</span>
                  ) : (
                    <span>Import to Bland.ai</span>
                  )}
                </button>
              </div>
            </div>

            {importMessage && (
              <div className={`p-2.5 text-[11px] rounded-lg font-mono leading-normal ${
                importState === 'success'
                  ? 'bg-accent-green/10 border border-accent-green/20 text-accent-green'
                  : 'bg-accent-red/10 border border-accent-red/20 text-accent-red'
              }`}>
                {importMessage}
              </div>
            )}
          </div>

          {!phoneNumber && (
            <p className="text-[11px] text-accent-amber font-mono bg-accent-amber/5 border border-accent-amber/20 p-2.5 rounded-lg">
              ⚠️ Note: Save your profile above with a valid mobile phone number first to unlock Bland.ai test calling features.
            </p>
          )}
        </div>
      </section>

      {/* 2. APPEARANCE SETTINGS */}
      <section className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-6 space-y-4" id="settings-appearance-section">
        <div className="flex items-center space-x-3 pb-4 border-b border-[#2A2A3E]">
          <div className="p-2 bg-accent-purple/10 text-accent-purple rounded-lg">
            <Sun size={20} />
          </div>
          <div>
            <h2 className="font-display font-black text-sm text-white uppercase tracking-wider">Appearance and Skin Override</h2>
            <p className="text-text-secondary text-xs mt-0.5">Toggle between ambient midnight dark or high-contrast crisp white palettes.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Dark Mode Choice Card */}
          <button
            onClick={() => toggleAppearance(false)}
            className={`p-4 rounded-xl border text-left flex items-start space-x-4 transition cursor-pointer ${
              !isLightMode 
                ? 'bg-accent-blue/5 border-accent-blue shadow-[0_0_15px_rgba(10,132,255,0.07)]' 
                : 'bg-[#161622]/50 border-[#2A2A3E] hover:border-[#48485A]'
            }`}
          >
            <div className={`p-3 rounded-lg ${!isLightMode ? 'bg-accent-blue/20 text-accent-blue' : 'bg-[#1A1A26] text-text-muted'}`}>
              <Moon size={20} />
            </div>
            <div className="space-y-1">
              <div className="text-sm font-bold text-white flex items-center space-x-2">
                <span>Cosmic Midnight</span>
                {!isLightMode && <span className="w-1.5 h-1.5 rounded-full bg-accent-blue" />}
              </div>
              <p className="text-xs text-text-secondary leading-normal">
                Subtle cyber-indigo background designed for low-light rescue cycles and intense focus intervals.
              </p>
            </div>
          </button>

          {/* Light Mode Choice Card */}
          <button
            onClick={() => toggleAppearance(true)}
            className={`p-4 rounded-xl border text-left flex items-start space-x-4 transition cursor-pointer ${
              isLightMode 
                ? 'bg-accent-blue/5 border-accent-blue shadow-[0_0_15px_rgba(10,132,255,0.07)]' 
                : 'bg-[#161622]/50 border-[#2A2A3E] hover:border-[#48485A]'
            }`}
          >
            <div className={`p-3 rounded-lg ${isLightMode ? 'bg-accent-blue/20 text-accent-blue' : 'bg-[#1A1A26] text-text-muted'}`}>
              <Sun size={20} />
            </div>
            <div className="space-y-1">
              <div className="text-sm font-bold text-white flex items-center space-x-2">
                <span>Pristine White</span>
                {isLightMode && <span className="w-1.5 h-1.5 rounded-full bg-accent-blue" />}
              </div>
              <p className="text-xs text-text-secondary leading-normal">
                True-white clean paper canvas crafted with gorgeous, crisp high-contrast layers for ultimate daytime clarity.
              </p>
            </div>
          </button>
        </div>
      </section>

      {/* 3. WIDGET LAYOUT CUSTOMIZATION (RELOCATED CORE FEATURE) */}
      <section className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-6 space-y-4" id="settings-layout-section">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#2A2A3E] gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-accent-amber/10 text-accent-amber rounded-lg">
              <GripVertical size={20} />
            </div>
            <div>
              <h2 className="font-display font-black text-sm text-white uppercase tracking-wider">Dashboard Widget Layout</h2>
              <p className="text-text-secondary text-xs mt-0.5">Drag and drop cards or click arrows to reorder dashboard widgets.</p>
            </div>
          </div>

          <button
            onClick={resetWidgets}
            className="px-3 py-1.5 text-xs bg-[#1A1A26] border border-[#2A2A3E] hover:border-[#48485A] text-text-primary hover:text-white rounded-lg transition cursor-pointer"
          >
            Reset to Default
          </button>
        </div>

        <div className="space-y-2.5">
          {widgets.map((widget, idx) => (
            <div
              key={widget.id}
              draggable
              onDragStart={() => handleDragStart(idx)}
              onDragOver={(e) => handleDragOver(e, idx)}
              onDrop={() => handleDrop(idx)}
              className={`flex items-center justify-between p-3.5 bg-[#161622] border rounded-lg transition ${
                draggedIndex === idx ? 'border-accent-blue/50 opacity-50' : 'border-[#2A2A3E] hover:border-[#48485A]'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className="cursor-grab active:cursor-grabbing text-text-secondary hover:text-white p-1">
                  <GripVertical size={16} />
                </div>
                <span className="text-sm font-semibold text-white">{widget.name}</span>
              </div>

              <div className="flex items-center space-x-2">
                <button
                  type="button"
                  onClick={() => moveWidget(idx, 'up')}
                  disabled={idx === 0}
                  className="p-1.5 rounded bg-[#1A1A26] border border-[#2A2A3E] text-text-secondary hover:text-white disabled:opacity-35 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Up"
                >
                  <MoveUp size={12} />
                </button>
                <button
                  type="button"
                  onClick={() => moveWidget(idx, 'down')}
                  disabled={idx === widgets.length - 1}
                  className="p-1.5 rounded bg-[#1A1A26] border border-[#2A2A3E] text-text-secondary hover:text-white disabled:opacity-35 disabled:cursor-not-allowed transition cursor-pointer"
                  title="Move Down"
                >
                  <MoveDown size={12} />
                </button>
                <button
                  type="button"
                  onClick={() => toggleWidgetVisibility(widget.id)}
                  className={`p-1.5 rounded transition cursor-pointer ${
                    widget.visible
                      ? 'bg-accent-blue/10 text-accent-blue border border-accent-blue/30 hover:bg-accent-blue/20'
                      : 'bg-[#1A1A26] text-text-secondary border border-[#2A2A3E] hover:border-[#48485A] hover:text-white'
                  }`}
                  title={widget.visible ? "Hide Widget" : "Show Widget"}
                >
                  {widget.visible ? <Eye size={14} /> : <EyeOff size={14} />}
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. PRIVACY & DATA ADMINISTRATION */}
      <section className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-6 space-y-4" id="settings-privacy-section">
        <div className="flex items-center space-x-3 pb-4 border-b border-[#2A2A3E]">
          <div className="p-2 bg-accent-red/10 text-accent-red rounded-lg">
            <Shield size={20} />
          </div>
          <div>
            <h2 className="font-display font-black text-sm text-white uppercase tracking-wider">Privacy & Diagnostics Control</h2>
            <p className="text-text-secondary text-xs mt-0.5">Manage data security preferences and sandbox database structures.</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex items-start justify-between p-4 bg-[#161622] rounded-xl border border-[#2A2A3E]">
            <div className="space-y-1 pr-4">
              <div className="text-sm font-bold text-white">Diagnostics & Telemetry Dispatch</div>
              <p className="text-xs text-text-secondary leading-normal max-w-xl">
                Allow anonymous, non-identifying telemetry reports to help evaluate rescue patterns, deadline cascades, and model response times. No personal text or credentials are ever transmitted.
              </p>
            </div>
            <button
              onClick={handleToggleTelemetry}
              className={`w-11 h-6 rounded-full transition relative flex-shrink-0 ${isTelemetryEnabled ? 'bg-accent-blue' : 'bg-text-muted'}`}
            >
              <span className={`w-4 h-4 rounded-full bg-white absolute top-1 transition ${isTelemetryEnabled ? 'left-6' : 'left-1'}`} />
            </button>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border border-accent-red/20 bg-accent-red/5 rounded-xl gap-4">
            <div className="flex items-start space-x-3">
              <div className="p-1.5 text-accent-red bg-accent-red/10 rounded mt-0.5">
                <AlertTriangle size={16} />
              </div>
              <div className="space-y-0.5">
                <h4 className="text-sm font-bold text-white">Purge System Cache & Database</h4>
                <p className="text-xs text-text-secondary leading-normal max-w-md">
                  Wipes all pending and completed deadlines, historical calendars, diagnostic autopsy reports, and active AI conversation logs from your device.
                </p>
              </div>
            </div>

            <button
              onClick={handleClearLocalState}
              className="px-4 py-2 bg-accent-red hover:bg-accent-red/80 text-white text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition cursor-pointer whitespace-nowrap"
            >
              <Trash2 size={13} />
              <span>Purge Sandbox Cache</span>
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
