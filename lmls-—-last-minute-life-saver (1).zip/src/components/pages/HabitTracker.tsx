import React, { useState } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { Habit } from '../../types';
import { CheckSquare, Flame, Award, Trash2, Plus, Sparkles, AlertTriangle, ShieldCheck } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function HabitTracker() {
  const { 
    habits, 
    addHabit, 
    toggleHabitToday, 
    deleteHabit, 
    getQuickStats,
    setIsChatOpen,
    sendChatMessage 
  } = useLMLS();

  const [showAddModal, setShowAddModal] = useState(false);
  const [habitName, setHabitName] = useState('');
  const [minViable, setMinViable] = useState('');
  const [why, setWhy] = useState('');
  const [category, setCategory] = useState('Learning');

  const stats = getQuickStats();

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!habitName.trim()) return;

    addHabit({
      name: habitName.trim(),
      minimumViable: minViable.trim() || 'Do it for 2 minutes',
      why: why.trim() || 'To maintain progress',
      category,
      frequency: 'daily',
    });

    setHabitName('');
    setMinViable('');
    setWhy('');
    setShowAddModal(false);
  };

  // Check if a habit chain is broken (0 completions in 3+ days)
  const isChainBroken = (habit: Habit) => {
    if (habit.completions.length === 0) return true;
    const now = new Date();
    const completionsSorted = [...habit.completions]
      .map(d => new Date(d))
      .sort((a, b) => b.getTime() - a.getTime());
    
    const lastCompleted = completionsSorted[0];
    const diffDays = (now.getTime() - lastCompleted.getTime()) / (1000 * 60 * 60 * 24);
    return diffDays >= 3;
  };

  const handleRestartChain = (habit: Habit) => {
    setIsChatOpen(true);
    sendChatMessage(`My habit chain for "${habit.name}" is broken! Send me a micro-commitment prompt to restart the chain today.`);
  };

  // Generate date array for last 4 weeks (28 days) to render heatmap
  const getHeatmapDays = () => {
    const days = [];
    const today = new Date();
    for (let i = 27; i >= 0; i--) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      days.push(d.toISOString().split('T')[0]);
    }
    return days;
  };

  const heatmapDays = getHeatmapDays();

  // Weekly summary Recharts calculation (habits completed per day this week)
  const getWeeklyCompletionsData = () => {
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const now = new Date();
    
    // Create list of last 7 calendar days
    const last7Days = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(now.getDate() - i);
      last7Days.push(d);
    }

    return last7Days.map(day => {
      const dateStr = day.toISOString().split('T')[0];
      const count = habits.filter(h => h.completions.includes(dateStr)).length;
      return {
        name: daysOfWeek[day.getDay()],
        Completed: count,
      };
    });
  };

  const chartData = getWeeklyCompletionsData();

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <CheckSquare className="text-accent-green" size={16} />
            <span className="text-accent-green font-mono font-black text-xs uppercase tracking-wider">Atomic Consistency Engine</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-black text-white leading-tight">
            Habit Loop Tracker 🔗
          </h1>
          <p className="text-text-secondary text-sm font-sans mt-1">
            Build bulletproof habits through micro-commitments. Break chains, get prompt saves.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-accent-green hover:bg-accent-green/85 text-[#0A0A0F] font-bold rounded-lg text-sm flex items-center space-x-2 transition cursor-pointer shadow-lg shadow-accent-green/10"
        >
          <Plus size={16} />
          <span>New Atomic Habit</span>
        </button>
      </header>

      {/* Habits Grid Shelf */}
      <section className="space-y-6">
        {habits.length === 0 ? (
          <div className="bg-[#111118] border border-dashed border-[#2A2A3E] rounded-xl p-12 text-center text-text-secondary text-sm">
            No habits registered. Create an atomic habit to start streaking!
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {habits.map(habit => {
              const broken = isChainBroken(habit);
              const completionsCount = habit.completions.length;
              const todayStr = new Date().toISOString().split('T')[0];
              const isDoneToday = habit.completions.includes(todayStr);

              return (
                <div key={habit.id} className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-5 space-y-4 flex flex-col justify-between hover:border-[#3D3D54] transition relative overflow-hidden">
                  
                  {/* Status broken banner badge */}
                  {broken && completionsCount > 0 && (
                    <div className="absolute top-0 right-0 bg-accent-red/10 border-b border-l border-accent-red/30 px-2.5 py-0.5 rounded-bl text-[9px] font-mono font-black text-accent-red tracking-wider flex items-center space-x-1 animate-pulse">
                      <AlertTriangle size={10} />
                      <span>CHAIN BROKEN</span>
                    </div>
                  )}

                  <div className="space-y-2">
                    {/* Header line */}
                    <div className="flex items-start justify-between">
                      <div className="space-y-0.5">
                        <span className="text-[10px] font-mono tracking-wider text-text-secondary uppercase">{habit.category}</span>
                        <h3 className="font-display font-black text-white text-lg leading-snug">{habit.name}</h3>
                      </div>
                      
                      <button
                        onClick={() => toggleHabitToday(habit.id)}
                        className={`p-1.5 rounded-lg border transition cursor-pointer ${
                          isDoneToday 
                            ? 'bg-accent-green/20 border-accent-green text-accent-green' 
                            : 'bg-[#1A1A26] border-[#2A2A3E] text-text-secondary hover:text-white'
                        }`}
                        title="Mark completed for today"
                      >
                        <ShieldCheck size={20} />
                      </button>
                    </div>

                    {/* Minimum viable helper */}
                    <div className="p-2.5 bg-[#1A1A26] border border-[#2A2A3E] rounded text-xs space-y-1">
                      <div className="text-[9px] font-mono text-text-muted uppercase font-bold">🎯 Minimum Viable Version (If lazy)</div>
                      <p className="text-text-secondary">"{habit.minimumViable}"</p>
                    </div>
                  </div>

                  {/* 28-day GitHub contribution heatmap */}
                  <div className="space-y-1.5">
                    <span className="text-[10px] font-mono text-text-muted uppercase">Last 28 Days Completions</span>
                    <div className="flex flex-wrap gap-1.5 p-2 bg-[#1A1A26]/40 border border-[#2A2A3E]/30 rounded">
                      {heatmapDays.map(dayStr => {
                        const isDone = habit.completions.includes(dayStr);
                        const isHeatmapToday = dayStr === todayStr;
                        return (
                          <div
                            key={dayStr}
                            className={`w-3.5 h-3.5 rounded-sm transition ${
                              isDone 
                                ? 'bg-accent-green shadow-[0_0_8px_rgba(48,209,88,0.4)]' 
                                : isHeatmapToday 
                                  ? 'border border-accent-blue bg-accent-blue/10 animate-pulse'
                                  : 'bg-[#1A1A26]'
                            }`}
                            title={`Date: ${dayStr} | Completed: ${isDone ? 'YES' : 'NO'}`}
                          />
                        );
                      })}
                    </div>
                  </div>

                  {/* Footer actions */}
                  <div className="pt-2.5 border-t border-[#1D1D2B] flex items-center justify-between text-xs text-text-secondary">
                    <div className="flex space-x-4">
                      <span>Total: <strong className="text-white">{completionsCount}</strong></span>
                      {broken && completionsCount > 0 ? (
                        <button
                          onClick={() => handleRestartChain(habit)}
                          className="text-accent-red font-bold hover:underline flex items-center space-x-1 cursor-pointer"
                        >
                          <Sparkles size={11} />
                          <span>Restart Chain</span>
                        </button>
                      ) : (
                        <span className="text-accent-green font-semibold">Active 🔥</span>
                      )}
                    </div>

                    <button
                      onClick={() => {
                        if (confirm(`Remove habit "${habit.name}"?`)) {
                          deleteHabit(habit.id);
                        }
                      }}
                      className="text-text-muted hover:text-accent-red transition cursor-pointer"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Charts & metrics row */}
      {habits.length > 0 && (
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-4">
          
          {/* Consistency Streak Card */}
          <div className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-5 flex flex-col justify-between space-y-4">
            <div className="flex items-start space-x-3">
              <Flame size={24} className="text-accent-purple animate-pulse" />
              <div className="space-y-0.5">
                <h4 className="text-sm font-bold text-white">Streak Dynamics</h4>
                <p className="text-text-secondary text-xs">Maintain habits daily to stack your energy score.</p>
              </div>
            </div>

            <div className="py-2 text-center">
              <span className="block text-4xl font-black text-accent-purple tracking-tight">{stats.currentStreak} Days</span>
              <span className="text-[10px] font-mono text-text-muted uppercase">Highest Recorded Active Streak</span>
            </div>

            <div className="text-[11px] text-text-secondary text-center leading-relaxed font-sans">
              "Skipping a day is a mistake. Skipping two is the start of a new bad habit." Keep it alive using minimum viable rescues.
            </div>
          </div>

          {/* Recharts Bar Chart (Weekly summary) */}
          <div className="lg:col-span-2 bg-[#111118] border border-[#2A2A3E] rounded-xl p-5 space-y-3">
            <h4 className="text-xs font-mono font-bold tracking-widest uppercase text-text-secondary">Weekly Completion Volume</h4>
            <div className="h-44 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                  <XAxis dataKey="name" stroke="#48485A" fontSize={11} tickLine={false} />
                  <YAxis stroke="#48485A" fontSize={11} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#111118', borderColor: '#2A2A3E', borderRadius: '6px' }}
                    labelStyle={{ color: '#8E8EA0', fontWeight: 'bold' }}
                    itemStyle={{ color: '#30D158' }}
                  />
                  <Bar dataKey="Completed" fill="#30D158" radius={[4, 4, 0, 0]} barSize={24} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

        </section>
      )}

      {/* Add Habit Flow Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#111118] border border-[#2A2A3E] rounded-xl p-6 space-y-4 shadow-2xl">
            <h3 className="font-display font-black text-lg text-white">NEW ATOMIC HABIT</h3>
            <form onSubmit={handleCreateHabit} className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Habit Title</label>
                <input
                  type="text"
                  value={habitName}
                  onChange={(e) => setHabitName(e.target.value)}
                  placeholder="e.g. Write 500 Words daily"
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-green focus:ring-1 focus:ring-accent-green"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Minimum Viable Version</label>
                <input
                  type="text"
                  value={minViable}
                  onChange={(e) => setMinViable(e.target.value)}
                  placeholder="e.g. Write just 1 sentence (No matter how bad)"
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-green focus:ring-1 focus:ring-accent-green"
                />
                <span className="text-[10px] text-text-muted mt-1 block">Specify a 2-minute version for low motivation days.</span>
              </div>

              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Why does this matter?</label>
                <input
                  type="text"
                  value={why}
                  onChange={(e) => setWhy(e.target.value)}
                  placeholder="e.g. To launch my indie hacking app before summer"
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1 uppercase">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-green"
                >
                  <option value="Learning">Learning</option>
                  <option value="Health">Health</option>
                  <option value="Relationships">Relationships</option>
                  <option value="Finance">Finance</option>
                  <option value="Career">Career</option>
                </select>
              </div>

              <div className="pt-2 flex space-x-2">
                <button
                  type="submit"
                  className="flex-1 py-2 bg-accent-green hover:bg-accent-green/85 text-[#0A0A0F] font-black rounded text-sm transition cursor-pointer"
                >
                  Build Habit Loop
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-[#1A1A26] border border-[#2A2A3E] hover:bg-[#2A2A3E] text-text-secondary hover:text-white rounded text-sm transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
