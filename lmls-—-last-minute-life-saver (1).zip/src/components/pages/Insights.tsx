import React, { useState } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { BarChart3, AlertCircle, HelpCircle, Activity, Sparkles, AlertTriangle, ArrowRight, CornerDownRight } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function Insights() {
  const { 
    tasks, 
    autopsies, 
    runDeadlineAutopsy: generateAutopsy, 
    getQuickStats, 
    userProfile,
    generateCascadeImpact
  } = useLMLS();

  const [cascadeImpactData, setCascadeImpactData] = useState<{ primaryFailure: string; impactChain: string[] } | null>(null);
  const [isCascadeLoading, setIsCascadeLoading] = useState(false);

  const fetchCascadeImpact = async (taskId: string) => {
    setIsCascadeLoading(true);
    try {
      const chain = await generateCascadeImpact(taskId);
      const target = tasks.find(t => t.id === taskId);
      setCascadeImpactData({
        primaryFailure: target ? target.title : 'Selected Task',
        impactChain: chain
      });
    } catch (err) {
      console.error('Failed to analyze cascade', err);
    } finally {
      setIsCascadeLoading(false);
    }
  };

  const [activeAutopsyTaskId, setActiveAutopsyTaskId] = useState<string>('');
  const [isAutopsyLoading, setIsAutopsyLoading] = useState(false);
  const [selectedCascadeTask, setSelectedCascadeTask] = useState<string>('');

  const stats = getQuickStats();

  // 1. Calculate Circular Productivity / On-time Score
  // Formula: (completed_on_time / total_tasks) * 100 - (panicSaves * 5)
  const calculateScore = () => {
    const total = tasks.length;
    if (total === 0) return 100;

    const completedOnTime = tasks.filter(t => t.status === 'done').length; // simplify as completed
    const baseScore = Math.round((completedOnTime / total) * 100);
    const penalties = (userProfile?.panicSaveCount || 0) * 5;
    
    return Math.max(10, baseScore - penalties);
  };

  const score = calculateScore();

  // Find missed/overdue tasks for autopsy
  const now = new Date();
  const missedTasks = tasks.filter(t => {
    const isOverdue = new Date(t.deadline) < now;
    return isOverdue && t.status !== 'done';
  });

  const handleRunAutopsy = async (taskId: string) => {
    setIsAutopsyLoading(true);
    await generateAutopsy(taskId);
    setIsAutopsyLoading(false);
  };

  const handleAnalyzeCascade = async (taskId: string) => {
    if (!taskId) return;
    await fetchCascadeImpact(taskId);
  };

  // 2. Generate line chart completions history
  const getLineChartData = () => {
    // Generate dummy historical completions for display (or map actual completions over last 5 days)
    return [
      { day: 'Mon', completed: 2, missed: 0, score: 75 },
      { day: 'Tue', completed: 4, missed: 1, score: 80 },
      { day: 'Wed', completed: 3, missed: 0, score: 85 },
      { day: 'Thu', completed: 5, missed: 2, score: 70 },
      { day: 'Fri', completed: 6, missed: 0, score: score },
    ];
  };

  const lineData = getLineChartData();

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <BarChart3 className="text-accent-blue" size={16} />
            <span className="text-accent-blue font-mono font-black text-xs uppercase tracking-wider">Tactical Analytics Core</span>
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-black text-white leading-tight">
            SaveMyDay Insights Hub 📊
          </h1>
          <p className="text-text-secondary text-sm font-sans mt-1">
            Examine breakdowns, calculate reliability metrics, and diagram cascade failures.
          </p>
        </div>
      </header>

      {/* Score gauge and history chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Productivity Circle Gauge Card */}
        <div className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-5 flex flex-col justify-between items-center text-center space-y-4">
          <div className="w-full flex items-center justify-between pb-2 border-b border-[#2A2A3E]">
            <span className="text-xs font-mono font-bold tracking-widest text-text-secondary uppercase">Productivity Score</span>
            <span className="text-[10px] bg-accent-blue/15 text-accent-blue px-1.5 rounded font-mono font-bold">SMD V1</span>
          </div>

          <div className="relative w-40 h-40 flex items-center justify-center">
            {/* Circular progress track (simulated) */}
            <div className="absolute inset-0 rounded-full border-8 border-[#1A1A26]" />
            <div className="absolute inset-0 rounded-full border-8 border-accent-blue border-t-transparent border-r-transparent animate-pulse opacity-20" />
            
            <div className="flex flex-col items-center">
              <span className="text-4xl font-black text-white tracking-tighter">{score}%</span>
              <span className="text-[10px] font-mono text-text-muted uppercase mt-0.5">Reliability</span>
            </div>
          </div>

          <div className="space-y-1 text-center">
            <span className="text-xs font-bold text-white">Score Adjustments:</span>
            <p className="text-text-secondary text-xs max-w-xs leading-relaxed">
              Calculated on tasks met on time, with a <strong className="text-accent-red">-5% friction penalty</strong> for each manual Panic Mode sprint triggered.
            </p>
          </div>
        </div>

        {/* Recharts completions line chart */}
        <div className="lg:col-span-2 bg-[#111118] border border-[#2A2A3E] rounded-xl p-5 space-y-3 flex flex-col justify-between">
          <h4 className="text-xs font-mono font-bold tracking-widest uppercase text-text-secondary">Task Achievement Index</h4>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={lineData} margin={{ top: 5, right: 5, left: -25, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1D1D2B" />
                <XAxis dataKey="day" stroke="#48485A" fontSize={11} tickLine={false} />
                <YAxis stroke="#48485A" fontSize={11} tickLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#111118', borderColor: '#2A2A3E', borderRadius: '6px' }}
                  labelStyle={{ color: '#8E8EA0', fontWeight: 'bold' }}
                />
                <Line type="monotone" dataKey="score" stroke="#0A84FF" strokeWidth={3} activeDot={{ r: 6 }} />
                <Line type="monotone" dataKey="completed" stroke="#30D158" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Deadline Autopsy Panel & Cascade Impact Analyzer */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Deadline Autopsy Panel */}
        <section className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-5 space-y-4">
          <div className="pb-2 border-b border-[#2A2A3E] flex items-center justify-between">
            <h4 className="font-display font-black text-sm text-white uppercase tracking-wider flex items-center space-x-2">
              <AlertCircle size={16} className="text-accent-amber" />
              <span>AI Deadline Autopsy Diagnostics</span>
            </h4>
            <span className="text-[10px] font-mono text-text-secondary">{missedTasks.length} Overdue</span>
          </div>

          {missedTasks.length === 0 ? (
            <div className="text-center py-12 text-xs text-text-muted italic">
              Amazing! No missed deadlines requiring autopsies. Your scheduling is flawless!
            </div>
          ) : (
            <div className="space-y-4">
              {/* Selector */}
              <div className="flex space-x-2">
                <select
                  value={activeAutopsyTaskId}
                  onChange={(e) => setActiveAutopsyTaskId(e.target.value)}
                  className="flex-1 bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-xs text-white focus:outline-none"
                >
                  <option value="">-- Choose overdue task to run Autopsy --</option>
                  {missedTasks.map(t => (
                    <option key={t.id} value={t.id}>
                      ❗ {t.title} (Overdue: {new Date(t.deadline).toLocaleDateString()})
                    </option>
                  ))}
                </select>

                <button
                  onClick={() => handleRunAutopsy(activeAutopsyTaskId)}
                  disabled={!activeAutopsyTaskId || isAutopsyLoading}
                  className="px-3 bg-accent-purple hover:bg-accent-purple/85 text-white font-bold rounded text-xs flex items-center space-x-1.5 transition cursor-pointer disabled:opacity-50"
                >
                  <Sparkles size={11} className={isAutopsyLoading ? 'animate-spin' : ''} />
                  <span>{isAutopsyLoading ? 'Diagnosing...' : 'Autopsy'}</span>
                </button>
              </div>

              {/* Render Autopsy Report if exists */}
              {autopsies.map(rep => {
                if (rep.taskId !== activeAutopsyTaskId) return null;
                return (
                  <div key={rep.id} className="p-4 bg-[#1A1A26] border border-accent-purple/20 rounded-lg space-y-3 animate-fade-in text-xs leading-relaxed">
                    <div className="flex items-center justify-between pb-1 border-b border-[#2A2A3E]">
                      <span className="font-mono text-[9px] font-bold text-accent-purple uppercase">Report ID: {rep.id.slice(0, 8)}</span>
                      <span className="bg-accent-red/10 border border-accent-red/30 text-accent-red px-1.5 py-0.5 rounded text-[9px] font-mono font-bold">
                        Pattern: {rep.patternLabel}
                      </span>
                    </div>

                    <div className="space-y-2">
                      <div>
                        <strong className="text-white block mb-0.5">🔍 Diagnostic Analysis</strong>
                        <p className="text-text-secondary">{rep.aiAnalysis}</p>
                      </div>
                      <div>
                        <strong className="text-accent-green block mb-0.5">✓ Preventative Action Plan</strong>
                        <p className="text-text-primary">{rep.countermeasure}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Cascade Impact Analyzer */}
        <section className="bg-[#111118] border border-[#2A2A3E] rounded-xl p-5 space-y-4">
          <div className="pb-2 border-b border-[#2A2A3E] flex items-center justify-between">
            <h4 className="font-display font-black text-sm text-white uppercase tracking-wider flex items-center space-x-2">
              <AlertTriangle size={16} className="text-accent-red" />
              <span>Downstream Cascade Impact Analyzer</span>
            </h4>
          </div>

          <div className="space-y-4">
            <div className="flex space-x-2">
              <select
                value={selectedCascadeTask}
                onChange={(e) => setSelectedCascadeTask(e.target.value)}
                className="flex-1 bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-xs text-white focus:outline-none"
              >
                <option value="">-- Choose target block to analyze --</option>
                {tasks.map(t => (
                  <option key={t.id} value={t.id}>
                    {t.title} ({t.status})
                  </option>
                ))}
              </select>

              <button
                onClick={() => handleAnalyzeCascade(selectedCascadeTask)}
                disabled={!selectedCascadeTask || isCascadeLoading}
                className="px-3 bg-accent-red hover:bg-accent-red/85 text-white font-bold rounded text-xs flex items-center space-x-1.5 transition cursor-pointer disabled:opacity-50"
              >
                <Sparkles size={11} className={isCascadeLoading ? 'animate-spin' : ''} />
                <span>{isCascadeLoading ? 'Calculating...' : 'Diagram Impact'}</span>
              </button>
            </div>

            {/* Cascade diagram result */}
            {cascadeImpactData && (
              <div className="p-4 bg-[#1A1A26] border border-accent-red/20 rounded-lg space-y-3 animate-fade-in text-xs leading-relaxed">
                <span className="font-mono text-[9px] font-bold text-accent-red uppercase block pb-1 border-b border-[#2A2A3E]">
                  🚨 CHRONIC FAILURE CHAIN DISCOVERED
                </span>

                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-white">Primary Failure:</span>
                    <span className="bg-accent-red/10 text-accent-red px-1.5 py-0.5 rounded text-[10px] font-mono">
                      "{cascadeImpactData.primaryFailure}"
                    </span>
                  </div>

                  <div className="space-y-2">
                    <strong className="text-white block">Chain Reaction Cascade:</strong>
                    {cascadeImpactData.impactChain && cascadeImpactData.impactChain.map((step: string, index: number) => (
                      <div key={index} className="flex items-start space-x-2 pl-3">
                        <CornerDownRight size={12} className="text-accent-red mt-0.5 flex-shrink-0" />
                        <span className="text-text-secondary">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            {!cascadeImpactData && !isCascadeLoading && (
              <div className="text-center py-12 text-xs text-text-muted italic">
                Select a task to trace the butterfly effect of delays on your overall roadmap.
              </div>
            )}
          </div>
        </section>

      </div>

    </div>
  );
}
