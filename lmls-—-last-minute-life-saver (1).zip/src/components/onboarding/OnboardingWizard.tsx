import React, { useState } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { Flame, ArrowRight, Sparkles, Smile, Sun, Sunset, Moon, ClipboardList } from 'lucide-react';
import Logo from '../layout/Logo';

export default function OnboardingWizard() {
  const { setOnboarding } = useLMLS();
  const [step, setStep] = useState(1);
  const [name, setName] = useState('');
  const [peakEnergy, setPeakEnergy] = useState<'morning' | 'afternoon' | 'night'>('morning');
  const [taskTitle, setTaskTitle] = useState('');
  const [taskDeadline, setTaskDeadline] = useState('');

  const handleNext = () => {
    if (step === 2 && !name.trim()) {
      alert("Please provide a name so I know what to call you!");
      return;
    }
    if (step === 4) {
      // Complete onboarding
      const tomorrow = new Date();
      tomorrow.setHours(tomorrow.getHours() + 2); // default to 2 hours from now if empty
      const finalDeadline = taskDeadline ? new Date(taskDeadline).toISOString() : tomorrow.toISOString();
      
      setOnboarding({
        name: name.trim(),
        peakEnergyTime: peakEnergy,
        onboardingComplete: true,
        panicSaveCount: 0,
        joinedAt: new Date().toISOString()
      }, {
        title: taskTitle.trim() || '🔥 Complete Hackathon Pitch preparation',
        deadline: finalDeadline
      });
      return;
    }
    setStep(step + 1);
  };

  return (
    <div id="onboarding-wizard" className="fixed inset-0 bg-[#0A0A0F] z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-[#111118] border border-[#2A2A3E] rounded-2xl p-6 md:p-8 space-y-6 relative overflow-hidden shadow-[0_0_80px_rgba(255,59,92,0.1)]">
        {/* Abstract Glowing Accent */}
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-accent-red/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-accent-blue/10 rounded-full blur-3xl pointer-events-none" />

        {/* Progress Bar */}
        <div className="flex justify-between items-center text-xs font-mono text-text-muted">
          <span>STEP {step} OF 4</span>
          <div className="flex space-x-1.5">
            {[1, 2, 3, 4].map(s => (
              <div 
                key={s} 
                className={`h-1.5 rounded-full transition-all duration-300 ${
                  s === step ? 'w-8 bg-accent-red' : s < step ? 'w-3 bg-accent-red/50' : 'w-3 bg-[#2A2A3E]'
                }`}
              />
            ))}
          </div>
        </div>

        {/* STEP 1: Welcome */}
        {step === 1 && (
          <div className="space-y-6 text-center py-4">
            <div className="flex justify-center">
              <Logo size={120} />
            </div>
            <div className="space-y-2">
              <h1 className="text-3xl font-display font-black text-white tracking-tight">Meet SaveMyDay</h1>
              <p className="text-text-secondary text-sm md:text-base max-w-sm mx-auto leading-relaxed">
                The companion that doesn't just remind you — it actively rescues you from missed deadlines.
              </p>
            </div>
            <button
              onClick={handleNext}
              className="w-full py-3.5 bg-accent-red hover:bg-accent-red/90 text-white font-semibold rounded-lg flex items-center justify-center space-x-2 transition cursor-pointer shadow-lg shadow-accent-red/20"
            >
              <span>Let's Go</span>
              <ArrowRight size={18} />
            </button>
          </div>
        )}

        {/* STEP 2: Name */}
        {step === 2 && (
          <div className="space-y-5">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-accent-blue/15 rounded-lg flex items-center justify-center border border-accent-blue/30 text-accent-blue">
                <Smile size={20} />
              </div>
              <h2 className="text-xl font-display font-bold text-white">What should I call you?</h2>
            </div>
            <p className="text-text-secondary text-sm">
              I need to know your name so I can customize notifications and address you during panic sprints.
            </p>
            <div>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name..."
                className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-accent-blue focus:ring-1 focus:ring-accent-blue text-base placeholder-text-muted"
                autoFocus
              />
            </div>
            <button
              onClick={handleNext}
              className="w-full py-3.5 bg-accent-blue hover:bg-accent-blue/90 text-white font-semibold rounded-lg flex items-center justify-center space-x-2 transition cursor-pointer"
            >
              <span>Continue</span>
              <ArrowRight size={18} />
            </button>
          </div>
        )}

        {/* STEP 3: Peak Energy Time */}
        {step === 3 && (
          <div className="space-y-5">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-accent-purple/15 rounded-lg flex items-center justify-center border border-accent-purple/30 text-accent-purple">
                <Sparkles size={20} />
              </div>
              <h2 className="text-xl font-display font-bold text-white">When do you do your best thinking?</h2>
            </div>
            <p className="text-text-secondary text-sm">
              This helps SaveMyDay optimize your scheduled tasks, slotting complex tasks into your high-energy windows.
            </p>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'morning', label: 'Morning', icon: Sun, desc: '🌅 6AM - 12PM' },
                { id: 'afternoon', label: 'Afternoon', icon: Sunset, desc: '☀️ 12PM - 6PM' },
                { id: 'night', label: 'Night', icon: Moon, desc: '🌙 6PM - 2AM' },
              ].map(opt => {
                const Icon = opt.icon;
                const isSel = peakEnergy === opt.id;
                return (
                  <button
                    key={opt.id}
                    onClick={() => setPeakEnergy(opt.id as any)}
                    className={`p-4 border rounded-xl flex flex-col items-center justify-center text-center space-y-2 transition cursor-pointer ${
                      isSel 
                        ? 'border-accent-purple bg-accent-purple/10 text-white' 
                        : 'border-[#2A2A3E] bg-[#1A1A26] text-text-secondary hover:border-[#48485A]'
                    }`}
                  >
                    <Icon size={24} className={isSel ? 'text-accent-purple' : 'text-text-secondary'} />
                    <span className="text-xs font-bold font-sans">{opt.label}</span>
                    <span className="text-[9px] font-mono opacity-80">{opt.desc}</span>
                  </button>
                );
              })}
            </div>
            <button
              onClick={handleNext}
              className="w-full py-3.5 bg-accent-purple hover:bg-accent-purple/90 text-white font-semibold rounded-lg flex items-center justify-center space-x-2 transition cursor-pointer"
            >
              <span>Almost There</span>
              <ArrowRight size={18} />
            </button>
          </div>
        )}

        {/* STEP 4: First high stakes task */}
        {step === 4 && (
          <div className="space-y-5">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-accent-red/15 rounded-lg flex items-center justify-center border border-accent-red/30 text-accent-red animate-pulse">
                <ClipboardList size={20} />
              </div>
              <h2 className="text-xl font-display font-bold text-white">Your first high-stakes deadline?</h2>
            </div>
            <p className="text-text-secondary text-sm">
              Log the exact task that is currently hanging over your head. I will track this, break it down, and rescue you.
            </p>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1.5 uppercase">Task Title</label>
                <input
                  type="text"
                  value={taskTitle}
                  onChange={(e) => setTaskTitle(e.target.value)}
                  placeholder="e.g., Finalize Pitch Deck for Hackathon"
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-accent-red focus:ring-1 focus:ring-accent-red text-sm placeholder-text-muted"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-text-secondary mb-1.5 uppercase">Exact Deadline</label>
                <input
                  type="datetime-local"
                  value={taskDeadline}
                  onChange={(e) => setTaskDeadline(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-3 py-2.5 text-white focus:outline-none focus:border-accent-red focus:ring-1 focus:ring-accent-red text-sm"
                />
              </div>
            </div>
            <button
              onClick={handleNext}
              className="w-full py-3.5 bg-accent-red hover:bg-accent-red/90 text-white font-semibold rounded-lg flex items-center justify-center space-x-2 transition cursor-pointer shadow-lg shadow-accent-red/15"
            >
              <span>Enter SaveMyDay</span>
              <ArrowRight size={18} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
