import React, { useState } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { Task, Subtask } from '../../types';
import { X, Plus, Trash2, Sparkles, HelpCircle } from 'lucide-react';

interface TaskDetailModalProps {
  task: Task;
  onClose: () => void;
}

export default function TaskDetailModal({ task, onClose }: TaskDetailModalProps) {
  const { 
    updateTask, 
    deleteTask, 
    toggleSubtask, 
    addSubtask, 
    deleteSubtask, 
    generateAiSubtasks 
  } = useLMLS();

  const [title, setTitle] = useState(task.title);
  const [description, setDescription] = useState(task.description);
  const [deadline, setDeadline] = useState(
    new Date(task.deadline).toISOString().slice(0, 16)
  );
  const [effort, setEffort] = useState(task.effort);
  const [category, setCategory] = useState(task.category);
  const [priority, setPriority] = useState(task.priority);
  const [notes, setNotes] = useState(task.notes || '');
  const [newSubtask, setNewSubtask] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);

  const [callReminderMode, setCallReminderMode] = useState<'none' | 'relative-15' | 'relative-30' | 'relative-60' | 'custom'>(
    task.callReminderMinutesBefore === 15 ? 'relative-15' :
    task.callReminderMinutesBefore === 30 ? 'relative-30' :
    task.callReminderMinutesBefore === 60 ? 'relative-60' :
    task.callReminderTime ? 'custom' : 'none'
  );
  const [callReminderTime, setCallReminderTime] = useState(
    task.callReminderTime ? new Date(task.callReminderTime).toISOString().slice(0, 16) : ''
  );

  const handleSave = () => {
    let reminderTime: string | null = null;
    let minutesBefore: number | null = null;
    
    if (callReminderMode === 'relative-15') {
      minutesBefore = 15;
      reminderTime = new Date(new Date(deadline).getTime() - 15 * 60000).toISOString();
    } else if (callReminderMode === 'relative-30') {
      minutesBefore = 30;
      reminderTime = new Date(new Date(deadline).getTime() - 30 * 60000).toISOString();
    } else if (callReminderMode === 'relative-60') {
      minutesBefore = 60;
      reminderTime = new Date(new Date(deadline).getTime() - 60 * 60000).toISOString();
    } else if (callReminderMode === 'custom' && callReminderTime) {
      reminderTime = new Date(callReminderTime).toISOString();
    }

    updateTask(task.id, {
      title,
      description,
      deadline: new Date(deadline).toISOString(),
      effort,
      category,
      priority,
      notes,
      callReminderTime: reminderTime,
      callReminderMinutesBefore: minutesBefore,
      callReminderSent: task.callReminderTime === reminderTime ? task.callReminderSent : false,
    });
    onClose();
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this task?')) {
      deleteTask(task.id);
      onClose();
    }
  };

  const handleAddSub = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubtask.trim()) return;
    addSubtask(task.id, newSubtask.trim());
    setNewSubtask('');
  };

  const handleAskAI = async () => {
    setIsAiLoading(true);
    await generateAiSubtasks(task.id);
    setIsAiLoading(false);
  };

  return (
    <div id="task-detail-modal" className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-2xl bg-[#111118] border border-[#2A2A3E] rounded-xl overflow-hidden shadow-2xl flex flex-col md:flex-row h-[90vh] md:h-[80vh]">
        
        {/* Left Side: Form Details */}
        <div className="flex-1 p-5 md:p-6 overflow-y-auto space-y-4 border-r border-[#2A2A3E]">
          <div className="flex items-center justify-between pb-2 border-b border-[#2A2A3E]">
            <h3 className="font-display font-black text-lg text-white">RESCUE TARGET DETAIL</h3>
            <button 
              onClick={onClose}
              className="p-1 rounded text-text-secondary hover:text-white hover:bg-[#1A1A26] transition"
            >
              <X size={18} />
            </button>
          </div>

          <div className="space-y-3">
            {/* Title */}
            <div>
              <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">Task Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue"
              />
            </div>

            {/* Description */}
            <div>
              <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">Description</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={2}
                className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue resize-none"
              />
            </div>

            {/* Grid fields */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">Deadline</label>
                <input
                  type="datetime-local"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">Category</label>
                <select
                  value={category}
                  onChange={(e: any) => setCategory(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none"
                >
                  <option value="work">Work</option>
                  <option value="study">Study</option>
                  <option value="personal">Personal</option>
                  <option value="health">Health</option>
                  <option value="finance">Finance</option>
                </select>
              </div>
            </div>

            {/* Effort & Priority */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">Effort required</label>
                <select
                  value={effort}
                  onChange={(e: any) => setEffort(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none"
                >
                  <option value="quick">Quick (5-15 mins)</option>
                  <option value="medium">Medium (30-60 mins)</option>
                  <option value="deep">Deep (2+ hours)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">Priority Level</label>
                <select
                  value={priority}
                  onChange={(e: any) => setPriority(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none"
                >
                  <option value="critical">Critical (DO NOW)</option>
                  <option value="important">Important (SCHEDULE)</option>
                  <option value="flexible">Flexible (QUICK DO)</option>
                  <option value="park">Park (LEISURE)</option>
                </select>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">Personal Notes</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Key considerations, bookmarks, or requirements..."
                rows={3}
                className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-2 text-sm text-white focus:outline-none focus:border-accent-blue resize-none"
              />
            </div>

            {/* Voice Call Reminder */}
            <div>
              <label className="block text-[10px] font-mono text-text-secondary mb-1 uppercase">📞 Voice Call Reminder (Bland.ai)</label>
              <select
                value={callReminderMode}
                onChange={(e: any) => setCallReminderMode(e.target.value)}
                className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none focus:border-accent-blue mb-2"
              >
                <option value="none">No Phone Call Reminder</option>
                <option value="relative-15">15 minutes before deadline</option>
                <option value="relative-30">30 minutes before deadline</option>
                <option value="relative-60">1 hour before deadline</option>
                <option value="custom">Custom Date & Time</option>
              </select>

              {callReminderMode === 'custom' && (
                <input
                  type="datetime-local"
                  value={callReminderTime}
                  onChange={(e) => setCallReminderTime(e.target.value)}
                  className="w-full bg-[#1A1A26] border border-[#2A2A3E] rounded px-3 py-1.5 text-sm text-white focus:outline-none focus:border-accent-blue"
                  required={callReminderMode === 'custom'}
                />
              )}
            </div>
          </div>

          <div className="pt-4 flex space-x-2">
            <button
              onClick={handleSave}
              className="flex-1 py-2 bg-accent-blue hover:bg-accent-blue/90 text-white font-semibold rounded text-sm transition cursor-pointer text-center"
            >
              Save Changes
            </button>
            <button
              onClick={handleDelete}
              className="py-2 px-3 bg-accent-red/10 border border-accent-red/35 text-accent-red hover:bg-accent-red hover:text-white rounded text-sm transition cursor-pointer"
              title="Delete task permanently"
            >
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        {/* Right Side: Sub-Tasks Block & AI Planner */}
        <div className="flex-1 p-5 md:p-6 bg-[#14141F] overflow-y-auto flex flex-col justify-between h-[50%] md:h-full">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-[#2A2A3E]">
              <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">Sub-Tasks Plan</h4>
              <button
                onClick={handleAskAI}
                disabled={isAiLoading}
                className="px-2.5 py-1 bg-accent-purple/15 hover:bg-accent-purple/30 border border-accent-purple/30 text-accent-purple rounded text-[10px] font-mono font-bold flex items-center space-x-1.5 transition cursor-pointer disabled:opacity-50"
              >
                <Sparkles size={10} className={isAiLoading ? 'animate-spin' : ''} />
                <span>{isAiLoading ? 'Decomposing...' : 'Ask AI for Subtasks'}</span>
              </button>
            </div>

            {/* Subtask list */}
            <div className="space-y-1.5 max-h-[180px] md:max-h-[260px] overflow-y-auto pr-1">
              {task.subtasks && task.subtasks.map(sub => (
                <div key={sub.id} className="flex items-center justify-between p-2 bg-[#1A1A26] border border-[#2A2A3E] rounded text-xs hover:border-[#3D3D54] transition">
                  <div className="flex items-center space-x-2 truncate">
                    <input
                      type="checkbox"
                      checked={sub.done}
                      onChange={() => toggleSubtask(task.id, sub.id)}
                      className="rounded border-[#2A2A3E] bg-[#111118] text-accent-blue focus:ring-0 cursor-pointer"
                    />
                    <span className={`truncate text-text-primary ${sub.done ? 'line-through text-text-muted font-normal' : 'font-semibold'}`}>
                      {sub.title}
                    </span>
                  </div>
                  <button
                    onClick={() => deleteSubtask(task.id, sub.id)}
                    className="text-text-muted hover:text-accent-red p-0.5 transition cursor-pointer"
                  >
                    <Trash2 size={12} />
                  </button>
                </div>
              ))}
              {(!task.subtasks || task.subtasks.length === 0) && (
                <div className="text-center py-8 text-text-muted text-xs italic">
                  No subtasks generated yet. Break this task into steps!
                </div>
              )}
            </div>
          </div>

          {/* Add Subtask Form */}
          <form onSubmit={handleAddSub} className="flex space-x-2 pt-4 border-t border-[#2A2A3E]">
            <input
              type="text"
              value={newSubtask}
              onChange={(e) => setNewSubtask(e.target.value)}
              placeholder="Add actionable subtask..."
              className="flex-1 bg-[#1A1A26] border border-[#2A2A3E] rounded px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-accent-blue"
            />
            <button
              type="submit"
              className="px-3 bg-accent-blue hover:bg-accent-blue/85 text-white rounded text-xs font-semibold cursor-pointer"
            >
              Add
            </button>
          </form>
        </div>

      </div>
    </div>
  );
}
