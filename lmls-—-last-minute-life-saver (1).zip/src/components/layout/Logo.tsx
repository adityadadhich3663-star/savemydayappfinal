import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  withText?: boolean;
  textSize?: string;
}

export default function Logo({ className = '', size = 32, withText = false, textSize = 'text-xl' }: LogoProps) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {/* SVG Icon matching user's logo */}
      <svg
        width={size}
        height={size}
        viewBox="0 0 512 512"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 drop-shadow-[0_4px_12px_rgba(0,0,0,0.15)]"
      >
        {/* Rounded square container */}
        <rect width="512" height="512" rx="100" fill="#071430" />
        
        {/* Speed lines on the left */}
        <g strokeLinecap="round" strokeWidth="24">
          <line x1="124" y1="180" x2="220" y2="180" stroke="#00F2FE" />
          <line x1="90" y1="225" x2="180" y2="225" stroke="#00C6FF" />
          <line x1="110" y1="270" x2="180" y2="270" stroke="#00A2FF" />
          <line x1="144" y1="315" x2="230" y2="315" stroke="#00D2C4" />
        </g>

        {/* Calendar Group */}
        <g filter="url(#drop-shadow)">
          {/* Calendar main blue card */}
          <rect x="186" y="140" width="216" height="200" rx="32" fill="#1C64F2" />
          
          {/* Calendar white top header */}
          <path d="M186 172C186 154.327 200.327 140 218 140H370C387.673 140 402 154.327 402 172V192H186V172Z" fill="#FFFFFF" />

          {/* Calendar binder rings (hooks) */}
          <rect x="238" y="100" width="16" height="60" rx="8" fill="#FFFFFF" />
          <rect x="334" y="100" width="16" height="60" rx="8" fill="#FFFFFF" />

          {/* White checkmark */}
          <path
            d="M240 260L286 306L368 200"
            stroke="#FFFFFF"
            strokeWidth="28"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>

        <defs>
          <filter id="drop-shadow" x="150" y="80" width="288" height="290" filterUnits="userSpaceOnUse">
            <feDropShadow dx="0" dy="8" stdDeviation="10" floodColor="#000000" floodOpacity="0.3" />
          </filter>
        </defs>
      </svg>

      {withText && (
        <span className={`font-display font-black tracking-tight ${textSize}`}>
          <span className="text-white">Save</span>
          <span className="text-[#00F2FE]">My</span>
          <span className="text-white">Day</span>
        </span>
      )}
    </div>
  );
}
