import React, { useState, useRef, useEffect } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { X, Send, Mic, MicOff, AlertCircle, RefreshCw, Calendar, Flame, Layers, Plus } from 'lucide-react';
import { ChatMessage } from '../../types';

export default function AIChatDrawer() {
  const { 
    isChatOpen, 
    setIsChatOpen, 
    chatHistory, 
    sendChatMessage, 
    clearChat, 
    addTask, 
    setIsPanicMode, 
    setPanicTaskId, 
    tasks 
  } = useLMLS();

  const [input, setInput] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Real-time Live Voice Chat States & Refs
  const [isLiveVoice, setIsLiveVoice] = useState(false);
  const [voiceStatus, setVoiceStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
  const wsRef = useRef<WebSocket | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextPlayTimeRef = useRef<number>(0);
  const micStreamRef = useRef<MediaStream | null>(null);
  const processorNodeRef = useRef<ScriptProcessorNode | null>(null);

  // Scroll to bottom on history change
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory, isGenerating]);

  // Clean up voice chat on close/unmount
  useEffect(() => {
    if (!isChatOpen) {
      stopLiveVoiceChat();
    }
    return () => {
      stopLiveVoiceChat();
    };
  }, [isChatOpen]);

  const stopLiveVoiceChat = () => {
    if (processorNodeRef.current) {
      processorNodeRef.current.disconnect();
      processorNodeRef.current = null;
    }
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(track => track.stop());
      micStreamRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (wsRef.current) {
      if (wsRef.current.readyState === WebSocket.CONNECTING || wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.close();
      }
      wsRef.current = null;
    }
    setIsLiveVoice(false);
    setVoiceStatus('disconnected');
  };

  const startLiveVoiceChat = async () => {
    try {
      setVoiceStatus('connecting');
      setIsLiveVoice(true);

      // 1. Establish WebSocket connection
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/api/live-ws`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      // 2. Setup audio context for playback & capture
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      audioContextRef.current = audioCtx;
      nextPlayTimeRef.current = audioCtx.currentTime;

      ws.onopen = async () => {
        console.log('🎙️ Real-time voice WebSocket open');
        setVoiceStatus('connected');

        try {
          // 3. Request mic permissions and capture stream
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          micStreamRef.current = stream;

          const source = audioCtx.createMediaStreamSource(stream);
          const processor = audioCtx.createScriptProcessor(2048, 1, 1);
          processorNodeRef.current = processor;

          source.connect(processor);
          processor.connect(audioCtx.destination);

          processor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            
            // Downsample to 16000Hz (Gemini Live expects 16kHz raw PCM)
            const inputSampleRate = e.inputBuffer.sampleRate;
            const targetSampleRate = 16000;
            const ratio = inputSampleRate / targetSampleRate;
            const targetLength = Math.round(inputData.length / ratio);
            const int16Array = new Int16Array(targetLength);

            for (let i = 0; i < targetLength; i++) {
              const srcIdx = Math.round(i * ratio);
              if (srcIdx < inputData.length) {
                const sample = Math.max(-1, Math.min(1, inputData[srcIdx]));
                int16Array[i] = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
              }
            }

            // Convert to base64
            const pcmBuffer = int16Array.buffer;
            const bytes = new Uint8Array(pcmBuffer);
            let binary = '';
            for (let i = 0; i < bytes.byteLength; i++) {
              binary += String.fromCharCode(bytes[i]);
            }
            const base64Audio = btoa(binary);

            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({ audio: base64Audio }));
            }
          };
        } catch (micErr) {
          console.error('Failed to get mic stream:', micErr);
          stopLiveVoiceChat();
          alert('Microphone permission denied or not found.');
        }
      };

      ws.onmessage = async (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.audio && audioContextRef.current) {
            playRawPCMChunk(data.audio);
          }
        } catch (msgErr) {
          console.error('Error handling WebSocket audio chunk:', msgErr);
        }
      };

      ws.onerror = (e) => {
        console.error('Live voice WebSocket error:', e);
        setVoiceStatus('error');
      };

      ws.onclose = () => {
        console.log('🎙️ Real-time voice WebSocket closed');
        stopLiveVoiceChat();
      };

    } catch (err) {
      console.error('Failed to initialize live voice chat:', err);
      stopLiveVoiceChat();
    }
  };

  const playRawPCMChunk = (base64Audio: string) => {
    const audioCtx = audioContextRef.current;
    if (!audioCtx) return;

    try {
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      const int16Array = new Int16Array(bytes.buffer);
      const float32Array = new Float32Array(int16Array.length);

      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768.0;
      }

      // Create Buffer for 16000Hz mono audio
      const audioBuffer = audioCtx.createBuffer(1, float32Array.length, 16000);
      audioBuffer.copyToChannel(float32Array, 0);

      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);

      const currentTime = audioCtx.currentTime;
      let startTime = nextPlayTimeRef.current;
      if (startTime < currentTime) {
        startTime = currentTime;
      }
      source.start(startTime);
      nextPlayTimeRef.current = startTime + audioBuffer.duration;
    } catch (playErr) {
      console.error('Failed to decode/play PCM audio chunk:', playErr);
    }
  };

  const toggleListening = () => {
    if (isLiveVoice) {
      stopLiveVoiceChat();
    } else {
      startLiveVoiceChat();
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isGenerating || isLiveVoice) return;

    const query = input.trim();
    setInput('');
    setIsGenerating(true);
    await sendChatMessage(query);
    setIsGenerating(false);
  };

  const handleChipClick = (prompt: string) => {
    if (!isLiveVoice) {
      setInput(prompt);
    }
  };

  // Render suggestion task card
  const [addedTasks, setAddedTasks] = useState<Record<string, boolean>>({});

  const handleAddTaskFromChat = (suggested: any, index: number) => {
    addTask({
      title: suggested.title,
      description: 'Suggested by SaveMyDay AI Assistant.',
      deadline: suggested.deadline || new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
      effort: suggested.effort || 'medium',
      category: suggested.category || 'work',
      notes: 'Logged directly from chat recommendations.',
    });
    setAddedTasks(prev => ({ ...prev, [index]: true }));
  };

  const handleActivateSprintFromChat = (suggestedPlan: any) => {
    // Find nearest task or create a mock task to anchor the sprints
    let targetId = tasks[0]?.id;
    if (!targetId) {
      const created = addTask({
        title: suggestedPlan.title || 'AI Crisis Rescue Sprints',
        description: 'Sprint-by-sprint planning guide generated by AI rescue.',
        deadline: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
        effort: 'deep',
        category: 'work',
        notes: '',
      });
      targetId = created.id;
    }

    // Set panic mode on this task
    setPanicTaskId(targetId);
    setIsPanicMode(true);
    setIsChatOpen(false); // Close drawer to show active Panic screen!
  };

  return (
    <div
      id="chat-drawer"
      className={`fixed top-0 right-0 h-screen w-full sm:w-[380px] bg-[#111118] border-l border-[#2A2A3E] z-40 transition-transform duration-300 transform flex flex-col justify-between ${
        isChatOpen ? 'translate-x-0 shadow-[0_0_50px_rgba(10,132,255,0.15)]' : 'translate-x-full'
      } ${isGenerating ? 'ring-1 ring-accent-blue/30 shadow-[0_0_80px_rgba(10,132,255,0.25)]' : ''}`}
    >
      {/* Header */}
      <div className="h-16 border-b border-[#2A2A3E] px-4 flex items-center justify-between bg-[#14141F]">
        <div className="flex items-center space-x-3">
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=150&h=150&q=80" 
              alt="Sarah Avatar" 
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full object-cover border-2 border-accent-green shadow-[0_0_12px_rgba(48,209,88,0.5)] transform hover:scale-110 transition duration-300"
            />
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-accent-green rounded-full border-2 border-[#14141F] flex items-center justify-center">
              <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-display font-black text-sm tracking-wide uppercase text-accent-red drop-shadow-[0_0_8px_rgba(255,59,92,0.45)]">Sarah</span>
            <span className="text-[10px] text-accent-green font-mono tracking-widest font-semibold uppercase flex items-center space-x-1">
              <span className="w-1 h-1 bg-accent-green rounded-full animate-ping" />
              <span>Tactical AI Live</span>
            </span>
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <button 
            onClick={clearChat}
            title="Clear Chat History"
            className="text-text-secondary hover:text-white p-1 rounded hover:bg-[#1A1A26] transition"
          >
            <RefreshCw size={16} />
          </button>
          <button 
            onClick={() => setIsChatOpen(false)}
            className="text-text-secondary hover:text-white p-1 rounded hover:bg-[#1A1A26] transition"
          >
            <X size={20} />
          </button>
        </div>
      </div>

      {/* Message History */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {chatHistory.map((msg, index) => {
          const isUser = msg.role === 'user';
          return (
            <div key={index} className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
              {/* Mode Badge Display */}
              {!isUser && msg.mode && (
                <span className="text-[10px] font-mono font-bold text-accent-blue bg-accent-blue/10 px-1.5 py-0.5 rounded mb-1 border border-accent-blue/20">
                  ⚡ {msg.mode}
                </span>
              )}

              <div 
                className={`max-w-[85%] rounded-lg p-3 text-sm leading-relaxed ${
                  isUser 
                    ? 'bg-accent-blue text-white rounded-tr-none' 
                    : 'bg-[#1A1A26] border border-[#2A2A3E] text-text-primary rounded-tl-none'
                }`}
              >
                {/* Message text */}
                <div className="whitespace-pre-wrap">{msg.content}</div>

                {/* Suggested Task Interactive Card */}
                {!isUser && msg.suggestedTask && (
                  <div className="mt-3 p-3 bg-[#111118] border border-accent-blue/30 rounded-lg text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] text-accent-blue uppercase font-bold">🎯 AI Suggested Task</span>
                      <span className="bg-accent-blue/20 text-accent-blue text-[10px] px-1.5 rounded uppercase font-bold">
                        {msg.suggestedTask.effort}
                      </span>
                    </div>
                    <div className="font-bold text-white text-sm">{msg.suggestedTask.title}</div>
                    <div className="text-text-secondary flex items-center space-x-1">
                      <Calendar size={12} />
                      <span>Due: {new Date(msg.suggestedTask.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    
                    <div className="pt-1 flex space-x-2">
                      {addedTasks[index] ? (
                        <span className="w-full text-center py-1.5 bg-accent-green/10 border border-accent-green/30 text-accent-green rounded font-semibold">
                          Added to Tasks ✓
                        </span>
                      ) : (
                        <>
                          <button
                            onClick={() => handleAddTaskFromChat(msg.suggestedTask, index)}
                            className="flex-1 py-1.5 bg-accent-blue hover:bg-accent-blue/80 text-white font-semibold rounded transition flex items-center justify-center space-x-1"
                          >
                            <Plus size={12} />
                            <span>Add Task</span>
                          </button>
                          <button
                            onClick={() => setAddedTasks(prev => ({ ...prev, [index]: false }))}
                            className="px-3 py-1.5 bg-[#1A1A26] border border-[#2A2A3E] text-text-secondary hover:text-white rounded transition"
                          >
                            Skip
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                )}

                {/* Suggested Sprint Plan Card */}
                {!isUser && msg.suggestedSprintPlan && (
                  <div className="mt-3 p-3 bg-[#111118] border border-accent-red/30 rounded-lg text-xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] text-accent-red uppercase font-bold">🚨 Emergency Sprints</span>
                      <span className="text-text-secondary font-mono">
                        {msg.suggestedSprintPlan.sprints.reduce((acc, s) => acc + s.duration, 0)} mins total
                      </span>
                    </div>
                    <div className="font-bold text-white text-sm">{msg.suggestedSprintPlan.title}</div>
                    
                    <div className="space-y-1 my-2">
                      {msg.suggestedSprintPlan.sprints.map((s, idx) => (
                        <div key={s.id} className="flex items-start space-x-2 p-1.5 bg-[#1A1A26] rounded">
                          <span className="bg-[#2A2A3E] text-white text-[9px] px-1 rounded font-mono mt-0.5">
                            {s.duration}m
                          </span>
                          <span className="text-text-primary text-[11px]">{s.text}</span>
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={() => handleActivateSprintFromChat(msg.suggestedSprintPlan)}
                      className="w-full py-1.5 bg-accent-red hover:bg-accent-red/80 text-white font-semibold rounded transition flex items-center justify-center space-x-1"
                    >
                      <Flame size={12} className="animate-pulse" />
                      <span>Activate Panic Sprints 🚨</span>
                    </button>
                  </div>
                )}
              </div>
              <span className="text-[9px] text-text-muted mt-1 px-1 font-mono">
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          );
        })}

        {/* Loading / Generating */}
        {isGenerating && (
          <div className="flex items-start space-x-1.5">
            <div className="bg-[#1A1A26] border border-[#2A2A3E] rounded-lg rounded-tl-none p-3 max-w-[85%] text-sm">
              <div className="flex space-x-1.5 items-center py-1">
                <div className="w-2 h-2 bg-accent-blue rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <div className="w-2 h-2 bg-accent-blue rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <div className="w-2 h-2 bg-accent-blue rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                <span className="text-xs text-text-secondary ml-1 font-mono">Sarah is analyzing...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* Input Form & Quick Prompt Chips */}
      <div className="p-3 border-t border-[#2A2A3E] bg-[#14141F] space-y-3">
        {/* Live Audio Visualizer Wave */}
        {isLiveVoice && (
          <div className="flex items-center justify-center space-x-1.5 py-2 bg-accent-green/5 border border-accent-green/20 rounded-lg">
            <span className="text-[10px] font-mono text-accent-green uppercase font-semibold tracking-wider animate-pulse mr-2 flex items-center">
              <span className="w-1.5 h-1.5 rounded-full bg-accent-green inline-block animate-ping mr-2" />
              <span>{voiceStatus === 'connecting' ? 'Establishing link...' : 'Conversational Stream Active'}</span>
            </span>
            <div className="flex items-center space-x-1 h-3">
              <span className="w-0.5 h-2 bg-accent-green rounded animate-pulse" />
              <span className="w-0.5 h-3 bg-accent-green rounded animate-pulse" />
              <span className="w-0.5 h-1.5 bg-accent-green rounded animate-pulse" />
              <span className="w-0.5 h-3.5 bg-accent-green rounded animate-pulse" />
              <span className="w-0.5 h-2 bg-accent-green rounded animate-pulse" />
            </div>
          </div>
        )}

        {/* Quick prompt chips (only visible when not generating & voice not active) */}
        {!isGenerating && !isLiveVoice && (
          <div className="flex space-x-1.5 overflow-x-auto pb-1 no-scrollbar">
            <button
              onClick={() => handleChipClick("What should I do right now?")}
              className="bg-[#1A1A26] hover:bg-[#2A2A3E] text-text-secondary hover:text-white border border-[#2A2A3E] text-xs px-2.5 py-1 rounded-full whitespace-nowrap transition cursor-pointer"
            >
              🚀 What's next?
            </button>
            <button
              onClick={() => handleChipClick("I am procrastinating on my task.")}
              className="bg-[#1A1A26] hover:bg-[#2A2A3E] text-text-secondary hover:text-white border border-[#2A2A3E] text-xs px-2.5 py-1 rounded-full whitespace-nowrap transition cursor-pointer"
            >
              🔗 Procrastinating
            </button>
            <button
              onClick={() => handleChipClick("Please analyze and prioritize my tasks, and suggest a Top 3 or Top 5 list with detailed rationales.")}
              className="bg-accent-blue/15 hover:bg-accent-blue/25 text-accent-blue hover:text-white border border-accent-blue/30 text-xs px-2.5 py-1 rounded-full whitespace-nowrap transition cursor-pointer font-semibold"
            >
              📊 Prioritize Tasks
            </button>
            <button
              onClick={() => handleChipClick("Optimize my schedule.")}
              className="bg-[#1A1A26] hover:bg-[#2A2A3E] text-text-secondary hover:text-white border border-[#2A2A3E] text-xs px-2.5 py-1 rounded-full whitespace-nowrap transition cursor-pointer"
            >
              🗓️ Optimize Schedule
            </button>
          </div>
        )}

        {/* Main form */}
        <form onSubmit={handleSend} className="flex items-center space-x-2">
          {/* Voice Input */}
          <button
            type="button"
            onClick={toggleListening}
            className={`p-2.5 rounded-lg border transition ${
              isLiveVoice 
                ? 'bg-accent-green border-accent-green text-white animate-pulse shadow-[0_0_15px_rgba(48,209,88,0.3)]' 
                : 'bg-[#1A1A26] border-[#2A2A3E] text-text-secondary hover:text-white hover:bg-[#2A2A3E]'
            }`}
            title={isLiveVoice ? "Stop Live Voice Chat" : "Start Live Voice Chat"}
          >
            {isLiveVoice ? <MicOff size={18} /> : <Mic size={18} />}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              isLiveVoice 
                ? (voiceStatus === 'connecting' ? "Connecting link..." : "🎙️ Voice Active... Speak now!") 
                : "Message Sarah..."
            }
            disabled={isGenerating || isLiveVoice}
            className="flex-1 bg-[#1A1A26] border border-[#2A2A3E] rounded-lg px-3 py-2 text-sm text-white placeholder-text-muted focus:outline-none focus:border-accent-blue focus:ring-1 focus:ring-accent-blue disabled:opacity-80"
          />

          <button
            type="submit"
            disabled={!input.trim() || isGenerating || isLiveVoice}
            className="p-2.5 bg-accent-blue hover:bg-accent-blue/80 text-white rounded-lg disabled:opacity-50 disabled:hover:bg-accent-blue transition cursor-pointer"
          >
            <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
}
