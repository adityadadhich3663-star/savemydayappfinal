import React from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { LayoutDashboard, Flame, CalendarRange, CheckSquare, BarChart3, ChevronLeft, ChevronRight, MessageSquareText, Settings } from 'lucide-react';
import Logo from './Logo';

export default function Sidebar({ collapsed, setCollapsed }: { collapsed: boolean; setCollapsed: (val: boolean) => void }) {
  const { activePage, setActivePage, isPanicMode, tasks, getQuickStats, setIsChatOpen, isChatOpen } = useLMLS();
  const stats = getQuickStats();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'panic', label: 'Panic Mode', icon: Flame, badge: isPanicMode ? '🚨' : undefined },
    { id: 'planner', label: 'Planner', icon: CalendarRange },
    { id: 'habits', label: 'Habit Tracker', icon: CheckSquare },
    { id: 'insights', label: 'Insights', icon: BarChart3 },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  // Auto-detect current urgency status
  const getUrgencyStatus = () => {
    if (isPanicMode) return { label: 'PANIC', color: 'bg-accent-red text-white animate-pulse' };
    
    const now = new Date();
    const incomplete = tasks.filter(t => t.status !== 'done');
    const urgentTask = incomplete.some(t => {
      const hoursLeft = (new Date(t.deadline).getTime() - now.getTime()) / (1000 * 60 * 60);
      return hoursLeft > 0 && hoursLeft < 4;
    });

    if (urgentTask) return { label: 'HEADS UP', color: 'bg-accent-amber text-black font-semibold' };
    return { label: 'ON TRACK', color: 'bg-accent-green text-black font-semibold' };
  };

  const status = getUrgencyStatus();

  return (
    <aside 
      id="sidebar"
      className={`fixed top-0 left-0 h-screen bg-[#111118] border-r border-[#2A2A3E] z-30 transition-all duration-300 flex flex-col justify-between ${
        collapsed ? 'w-[72px]' : 'w-[240px]'
      }`}
    >
      <div>
        {/* Logo strip */}
        <div className="h-16 flex items-center justify-between px-4 border-b border-[#2A2A3E]">
          {!collapsed ? (
            <Logo size={28} withText={true} textSize="text-lg" />
          ) : (
            <Logo size={28} withText={false} className="mx-auto" />
          )}
          
          <button 
            onClick={() => setCollapsed(!collapsed)}
            className="text-text-secondary hover:text-white p-1 rounded hover:bg-[#1A1A26] transition"
          >
            {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>
        </div>

        {/* Urgency Status Badge */}
        <div className="p-4 border-b border-[#2A2A3E]">
          {!collapsed ? (
            <div className="bg-[#1A1A26] rounded p-3 text-center">
              <div className="text-[10px] text-text-secondary uppercase font-mono tracking-widest mb-1">AI System Status</div>
              <span className={`inline-block text-xs px-2 py-0.5 rounded font-bold tracking-wider ${status.color}`}>
                ● {status.label}
              </span>
            </div>
          ) : (
            <div className="text-center">
              <span className="inline-block text-xs px-1 py-0.5 rounded font-black bg-[#1A1A26] border border-[#2A2A3E]">
                ●
              </span>
            </div>
          )}
        </div>

        {/* Navigation Menu */}
        <nav className="p-3 space-y-1">
          {menuItems.map(item => {
            const Icon = item.icon;
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-nav-${item.id}`}
                onClick={() => setActivePage(item.id)}
                className={`w-full flex items-center p-3 rounded-lg text-left transition group relative ${
                  isActive 
                    ? 'bg-accent-blue/15 text-accent-blue font-semibold border-l-2 border-accent-blue' 
                    : 'text-text-secondary hover:bg-[#1A1A26] hover:text-white'
                }`}
              >
                <Icon size={20} className={`${isActive ? 'text-accent-blue' : 'text-text-secondary group-hover:text-white'}`} />
                {!collapsed && (
                  <span className="ml-3 font-sans text-sm tracking-wide">{item.label}</span>
                )}
                {item.badge && !collapsed && (
                  <span className="ml-auto animate-bounce text-xs">{item.badge}</span>
                )}
                
                {/* Tooltip for collapsed view */}
                {collapsed && (
                  <div className="absolute left-full ml-4 bg-[#1A1A26] border border-[#2A2A3E] text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-50">
                    {item.label} {item.badge && `(${item.badge})`}
                  </div>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Sidebar Footer AI assistant summon */}
      <div className="p-3 border-t border-[#2A2A3E]">
        <button
          id="sidebar-chat-toggle"
          onClick={() => setIsChatOpen(!isChatOpen)}
          className={`w-full flex items-center p-3 rounded-lg text-left transition ${
            isChatOpen ? 'bg-accent-blue/20 text-accent-blue' : 'text-text-secondary hover:bg-[#1A1A26]'
          }`}
        >
          <MessageSquareText size={20} className="text-accent-blue animate-pulse" />
          {!collapsed && (
            <span className="ml-3 font-sans text-sm font-semibold tracking-wide text-accent-blue">AI Rescue Chat</span>
          )}
        </button>
      </div>
    </aside>
  );
}
