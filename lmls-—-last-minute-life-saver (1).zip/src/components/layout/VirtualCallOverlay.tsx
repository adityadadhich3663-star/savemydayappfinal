import React, { useEffect, useState, useRef } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import { Phone, PhoneOff, Volume2, ShieldAlert, Sparkles, AlertTriangle } from 'lucide-react';

export default function VirtualCallOverlay() {
  const { virtualCall, answerVirtualCall, endVirtualCall } = useLMLS();
  const [callDuration, setCallDuration] = useState(0);
  const durationIntervalRef = useRef<any>(null);

  // Handle call timer when active
  useEffect(() => {
    if (virtualCall.isOpen && virtualCall.status === 'active') {
      setCallDuration(0);
      durationIntervalRef.current = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    } else {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
        durationIntervalRef.current = null;
      }
      setCallDuration(0);
    }

    return () => {
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    };
  }, [virtualCall.isOpen, virtualCall.status]);

  if (!virtualCall.isOpen) return null;

  // Format call duration (MM:SS)
  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remaining = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remaining.toString().padStart(2, '0')}`;
  };

  // Extract a clean script block for display
  const getDisplayMessage = () => {
    let text = virtualCall.message;
    if (text.includes('Deliver this')) {
      const match = text.match(/Deliver this (?:urgent focus reminder|urgent focus alert|exact direct voice reminder) to [^:]+:\s*"([^"]+)"/i);
      if (match && match[1]) {
        text = match[1];
      }
    } else if (text.includes('Speak this')) {
      const match = text.match(/Speak this exact (?:short reminder|direct voice reminder) to [^:]+:\s*"([^"]+)"/i);
      if (match && match[1]) {
        text = match[1];
      }
    } else if (text.includes('Deliver a test message')) {
      const match = text.match(/Deliver a test message to [^:]+:\s*"([^"]+)"/i);
      if (match && match[1]) {
        text = match[1];
      }
    }
    return text.replace(/^["'\s]+|["'\s]+$/g, '');
  };

  const displayMessage = getDisplayMessage();

  return (
    <div className="fixed inset-0 bg-[#07070a]/90 backdrop-blur-xl z-50 flex items-center justify-center p-4">
      {/* Decorative ambient aura rings */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-accent-red/5 rounded-full filter blur-3xl animate-pulse" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] bg-accent-green/5 rounded-full filter blur-3xl" />

      {/* Main device card */}
      <div className="relative w-full max-w-sm bg-gradient-to-b from-[#161622] to-[#0c0c12] border border-white/10 rounded-[32px] shadow-[0_24px_64px_rgba(0,0,0,0.8)] overflow-hidden flex flex-col items-center p-8 text-center">
        {/* Connection Mode Indicator (Simulated vs Real Outbound call) */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center space-x-1.5 px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[10px] font-mono tracking-widest text-[#8e8e9f] uppercase">
          <span className="w-1.5 h-1.5 bg-yellow-400 rounded-full animate-ping" />
          <span>Virtual Companion Link</span>
        </div>

        {/* Karl/Caller Identity Section */}
        <div className="mt-10 flex flex-col items-center">
          {/* Pulsing Avatar */}
          <div className="relative mb-6">
            <div className={`absolute inset-0 rounded-full bg-accent-green/10 filter blur-md transition-all duration-500 ${
              virtualCall.status === 'ringing' ? 'animate-ping' : 'scale-110'
            }`} />
            
            <div className={`relative w-24 h-24 rounded-full flex items-center justify-center border-2 transition-all duration-500 bg-[#0f0f18] ${
              virtualCall.status === 'ringing' 
                ? 'border-accent-red animate-bounce' 
                : virtualCall.status === 'active' 
                  ? 'border-accent-green shadow-[0_0_25px_rgba(48,209,88,0.4)] scale-105' 
                  : 'border-white/10'
            }`}>
              <div className="absolute inset-2 rounded-full border border-white/5 bg-gradient-to-tr from-[#151525] to-[#25253a] flex items-center justify-center">
                <ShieldAlert className={`w-10 h-10 transition-colors duration-500 ${
                  virtualCall.status === 'ringing' 
                    ? 'text-accent-red' 
                    : virtualCall.status === 'active' 
                      ? 'text-accent-green animate-pulse' 
                      : 'text-gray-400'
                }`} />
              </div>
            </div>
          </div>

          <h3 className="text-xl font-sans font-semibold text-white tracking-tight">
            {virtualCall.callerName}
          </h3>
          <p className="mt-1 text-sm font-mono text-gray-400">
            {virtualCall.phoneNumber}
          </p>
          <p className="mt-2 text-xs font-semibold px-2.5 py-0.5 rounded bg-white/5 border border-white/10 text-accent-green uppercase tracking-wider">
            {virtualCall.status === 'ringing' ? 'Incoming Call...' : virtualCall.status === 'active' ? 'Call Active' : 'Connecting...'}
          </p>
        </div>

        {/* Call Centerpiece Screen */}
        <div className="w-full flex-1 my-8 flex flex-col justify-center min-h-[140px]">
          {virtualCall.status === 'ringing' ? (
            <div className="space-y-3 animate-pulse">
              <p className="text-sm text-[#8e8e9f]">
                Karl is calling to keep you accountable.
              </p>
              <div className="flex justify-center space-x-1.5 py-2">
                <span className="w-2.5 h-2.5 rounded-full bg-accent-red animate-bounce delay-100" />
                <span className="w-2.5 h-2.5 rounded-full bg-accent-red animate-bounce delay-200" />
                <span className="w-2.5 h-2.5 rounded-full bg-accent-red animate-bounce delay-300" />
              </div>
            </div>
          ) : virtualCall.status === 'active' ? (
            <div className="space-y-4">
              {/* Call Timer */}
              <div className="text-2xl font-mono text-white tracking-widest font-bold">
                {formatDuration(callDuration)}
              </div>

              {/* Talking Equalizer Waveform animation */}
              <div className="flex justify-center items-end space-x-1 h-6 py-1">
                {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((bar) => {
                  const randomDuration = 0.5 + Math.random() * 0.8;
                  const randomHeight = 20 + Math.random() * 80;
                  return (
                    <div 
                      key={bar}
                      className="w-1 bg-accent-green rounded-full transition-all"
                      style={{
                        height: `${randomHeight}%`,
                        animation: `pulse-height ${randomDuration}s ease-in-out infinite alternate`
                      }}
                    />
                  );
                })}
              </div>

              {/* Scrolling Live Script Display */}
              <div className="mt-3 p-4 bg-[#0a0a0f] border border-white/5 rounded-xl max-h-[120px] overflow-y-auto custom-scrollbar text-left">
                <div className="flex items-start space-x-2">
                  <Volume2 className="text-accent-green w-4 h-4 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-gray-300 leading-relaxed font-sans font-medium">
                    {displayMessage}
                  </p>
                </div>
              </div>
            </div>
          ) : null}
        </div>

        {/* Action Controls Footer */}
        <div className="w-full flex justify-center items-center space-x-8 mt-auto pb-4">
          {virtualCall.status === 'ringing' ? (
            <>
              {/* Decline Button */}
              <button
                onClick={endVirtualCall}
                className="w-16 h-16 rounded-full bg-accent-red hover:bg-accent-red/90 flex items-center justify-center text-white transition-all transform hover:scale-110 active:scale-95 shadow-[0_8px_20px_rgba(255,59,48,0.3)] cursor-pointer"
                title="Decline"
              >
                <PhoneOff className="w-7 h-7" />
              </button>

              {/* Answer Button */}
              <button
                onClick={answerVirtualCall}
                className="w-16 h-16 rounded-full bg-accent-green hover:bg-accent-green/90 flex items-center justify-center text-white transition-all transform hover:scale-110 active:scale-95 shadow-[0_8px_20px_rgba(48,209,88,0.3)] cursor-pointer relative group"
                title="Answer"
              >
                <div className="absolute inset-0 bg-accent-green rounded-full animate-ping opacity-25 group-hover:opacity-40" />
                <Phone className="w-7 h-7 relative z-10" />
              </button>
            </>
          ) : (
            /* Hang Up Button (For active call) */
            <button
              onClick={endVirtualCall}
              className="w-20 h-16 rounded-full bg-accent-red hover:bg-accent-red/90 flex items-center justify-center text-white transition-all transform hover:scale-110 active:scale-95 shadow-[0_8px_25px_rgba(255,59,48,0.4)] cursor-pointer"
              title="Hang Up"
            >
              <PhoneOff className="w-7 h-7" />
            </button>
          )}
        </div>

        {/* Note/Information Banner */}
        <div className="mt-6 flex items-center justify-center space-x-1.5 text-[10px] text-yellow-500/80 font-medium">
          <AlertTriangle size={12} />
          <span>Your browser's text-to-speech speaker is active</span>
        </div>
      </div>

      {/* Inject custom visualizer style for pulse-height */}
      <style>{`
        @keyframes pulse-height {
          0% { height: 10%; }
          100% { height: 100%; }
        }
      `}</style>
    </div>
  );
}
