import React, { useState, useEffect } from 'react';
import { useLMLS } from '../../context/LMLSContext';
import Sidebar from './Sidebar';
import AIChatDrawer from './AIChatDrawer';
import VirtualCallOverlay from './VirtualCallOverlay';
import OnboardingWizard from '../onboarding/OnboardingWizard';
import { Sparkles, Flame, MessageSquare, Bell } from 'lucide-react';
import { playNotificationSound } from '../../utils/sound';

export default function AppShell({ children }: { children: React.ReactNode }) {
  const { 
    userProfile, 
    tasks, 
    habits, 
    isPanicMode, 
    setIsPanicMode, 
    setPanicTaskId, 
    isChatOpen, 
    setIsChatOpen,
    activePage,
    setActivePage,
    updateTask,
    triggerVirtualCall
  } = useLMLS();

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState('default');

  // Request browser notification permission
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setNotificationPermission(Notification.permission);
      if (Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
          setNotificationPermission(permission);
        });
      }
    }
  }, []);

  const getRemainingTimeText = (deadlineStr: string) => {
    try {
      const diffMs = new Date(deadlineStr).getTime() - Date.now();
      if (diffMs <= 0) return "your deadline is already here or has passed!";
      const diffMins = Math.round(diffMs / 60000);
      if (diffMins < 60) {
        return `${diffMins} minutes`;
      }
      const hours = Math.floor(diffMins / 60);
      const remainingMins = diffMins % 60;
      if (remainingMins === 0) {
        return `${hours} hour${hours > 1 ? 's' : ''}`;
      }
      return `${hours} hour${hours > 1 ? 's' : ''} and ${remainingMins} minute${remainingMins > 1 ? 's' : ''}`;
    } catch (e) {
      return "shortly";
    }
  };

  // Helper to trigger Bland.ai voice calls
  const triggerBlandCallForTask = async (task: any, isPanicCall: boolean = false) => {
    const phone = userProfile?.phoneNumber || "+15674025498";
    
    // Calculate precise time remaining relative to the absolute deadline
    let timeRemaining = "";
    try {
      const diffMs = new Date(task.deadline).getTime() - Date.now();
      const diffMins = Math.max(0, Math.round(diffMs / 60000));
      if (diffMins <= 16 && diffMins >= 14) {
        timeRemaining = "exactly 15 minutes left";
      } else if (diffMins <= 31 && diffMins >= 29) {
        timeRemaining = "exactly 30 minutes left";
      } else if (diffMins <= 62 && diffMins >= 58) {
        timeRemaining = "exactly 1 hour left";
      } else if (diffMins < 60) {
        timeRemaining = `${diffMins} minutes left`;
      } else {
        const hours = Math.floor(diffMins / 60);
        const remainingMins = diffMins % 60;
        if (remainingMins === 0) {
          timeRemaining = `exactly ${hours} hour${hours > 1 ? 's' : ''} left`;
        } else {
          timeRemaining = `exactly ${hours} hour${hours > 1 ? 's' : ''} and ${remainingMins} minute${remainingMins > 1 ? 's' : ''} left`;
        }
      }
    } catch (e) {
      timeRemaining = getRemainingTimeText(task.deadline || new Date().toISOString());
    }
    
    let systemInstructionPrompt = "";
    if (isPanicCall) {
      systemInstructionPrompt = `You are Karl from SaveMyDay. Speak this exact short reminder to ${userProfile?.name || 'Saver'}: "Warning: Your task '${task.title}' is due in 1 hour! This is panic mode. Drop distractions, start your focus sprint timer, and let's conquer this! If you do not start right now, I will call you again in 5 minutes." Then immediately say "Goodbye!" and hang up the call. DO NOT say anything else. DO NOT ask any questions or wait for a response. End the call immediately.`;
    } else {
      systemInstructionPrompt = `You are Karl from SaveMyDay. Speak this exact direct voice reminder to ${userProfile?.name || 'Saver'}: "Reminder: It is time to work on your task, '${task.title}'. You have ${timeRemaining} remaining to meet your deadline! Stay motivated, stay focused, drop all excuses, start the timer, and let's get to work right now! If you do not start the timer and work, I will call you again in 5 minutes." Then immediately say "Goodbye!" and hang up the call immediately. DO NOT say anything else. DO NOT ask any questions or wait for a response. End the call immediately.`;
    }

    try {
      console.log(`[Scheduled Call Reminder] Triggering call to ${phone} for task "${task.title}" (isPanicCall: ${isPanicCall})`);
      const res = await fetch('/api/bland/call', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          phone_number: phone,
          voice: userProfile?.voiceSelection || 'a24c43d3-f448-4fea-a498-a9287f7cabf3',
          task: systemInstructionPrompt
        })
      });
      const data = await res.json();
      console.log("[Scheduled Call Response]", data);
      if (data.is_simulated_fallback) {
        triggerVirtualCall(systemInstructionPrompt);
      }
    } catch (err) {
      console.error("Error triggering scheduled call, falling back to simulated:", err);
      triggerVirtualCall(systemInstructionPrompt);
    }
  };

  // Polling notification engine (runs every 60 seconds)
  useEffect(() => {
    const checkDeadlinesAndFireNotifications = () => {
      const now = new Date();

      // -- 1. Check Scheduled Voice Call Reminders (Works independent of browser notification permission) --
      tasks.forEach(task => {
        if (task.status === 'done' || task.status === 'missed') return;

        if (task.callReminderTime && !task.callReminderSent) {
          const reminderTime = new Date(task.callReminderTime);
          if (now.getTime() >= reminderTime.getTime()) {
            console.log(`[AppShell] Scheduled call reminder reached for "${task.title}". Triggering Bland.ai!`);
            
            // Calculate next retry call time in 5 minutes
            const nextReminderTime = new Date(now.getTime() + 5 * 60000).toISOString();
            
            // Reschedule the task to call again in 5 minutes unless completed
            updateTask(task.id, { 
              callReminderTime: nextReminderTime,
              callReminderSent: false 
            });

            triggerBlandCallForTask(task, false);
          }
        }
      });

      // -- 2. Check Browser Notifications (if browser environment exists) --
      if (typeof window === 'undefined' || !('Notification' in window)) {
        return;
      }

      const sentNotifications = JSON.parse(localStorage.getItem('lmls_sent_notifications') || '{}');
      const updatedSent = { ...sentNotifications };
      let anyUpdate = false;

      // Check Tasks
      tasks.forEach(task => {
        if (task.status === 'done') return;

        const deadline = new Date(task.deadline);
        const diffMs = deadline.getTime() - now.getTime();
        const diffHours = diffMs / (1000 * 60 * 60);

        // Rule: Overdue/missed
        if (diffHours <= 0 && task.status !== 'missed') {
          const key = `${task.id}-missed`;
          if (!sentNotifications[key]) {
            if (Notification.permission === 'granted') {
              new Notification('🚨 Deadline Missed!', {
                body: `❗ "${task.title}" is overdue. Let's salvage this together with a post-mortem autopsy!`,
                icon: '/favicon.ico'
              });
            }
            updatedSent[key] = true;
            anyUpdate = true;
          }
        }
        // Rule: 1 hour before (triggers Panic Mode auto-entry!)
        else if (diffHours > 0 && diffHours <= 1) {
          const key = `${task.id}-1h`;
          if (!sentNotifications[key]) {
            if (Notification.permission === 'granted') {
              new Notification('🚨 PANIC MODE IMMINENT', {
                body: `⚠️ "${task.title}" is due in less than 1 hour! Entering tactical sprint mode!`,
                icon: '/favicon.ico'
              });
            }
            updatedSent[key] = true;
            anyUpdate = true;
            
            // Auto-trigger Panic Mode
            setPanicTaskId(task.id);
            setIsPanicMode(true);
            setActivePage('panic');

            // Trigger the warning voice call automatically!
            triggerBlandCallForTask(task, true);
          }
        }
        // Rule: 4 hours before
        else if (diffHours > 1 && diffHours <= 4) {
          const key = `${task.id}-4h`;
          if (!sentNotifications[key]) {
            if (Notification.permission === 'granted') {
              new Notification('⚡ Urgency Alert', {
                body: `⏳ "${task.title}" is due in 4 hours. Better start focusing!`,
                icon: '/favicon.ico'
              });
            }
            updatedSent[key] = true;
            anyUpdate = true;
          }
        }
        // Rule: 24 hours before
        else if (diffHours > 23 && diffHours <= 24) {
          const key = `${task.id}-24h`;
          if (!sentNotifications[key]) {
            if (Notification.permission === 'granted') {
              new Notification('📅 Upcoming Deadline', {
                body: `📅 "${task.title}" is due tomorrow. Want to plan your sprint approach?`,
                icon: '/favicon.ico'
              });
            }
            updatedSent[key] = true;
            anyUpdate = true;
          }
        }
      });

      // Check Habits around 9 PM
      const currentHour = now.getHours();
      if (currentHour >= 21) {
        const todayStr = now.toISOString().split('T')[0];
        habits.forEach(habit => {
          const completedToday = habit.completions.includes(todayStr);
          if (!completedToday) {
            const key = `habit-${habit.id}-${todayStr}`;
            if (!updatedSent[key]) {
              if (Notification.permission === 'granted') {
                new Notification('🔗 Maintain Your Streak!', {
                  body: `🔥 Don't break your "${habit.name}" streak! Your 5-minute minimum viable version: "${habit.minimumViable}" counts!`,
                  icon: '/favicon.ico'
                });
              }
              updatedSent[key] = true;
              anyUpdate = true;
            }
          }
        });
      }

      if (anyUpdate) {
        localStorage.setItem('lmls_sent_notifications', JSON.stringify(updatedSent));
        const soundName = localStorage.getItem('lmls_notification_sound') || 'chime';
        playNotificationSound(soundName);
      }
    };

    // Run on mount
    checkDeadlinesAndFireNotifications();

    // Poll every 60 seconds
    const interval = setInterval(checkDeadlinesAndFireNotifications, 60000);
    return () => clearInterval(interval);
  }, [tasks, habits, setIsPanicMode, setPanicTaskId, setActivePage, updateTask, userProfile]);

  // If onboarding is not completed, show onboarding wizard
  if (userProfile && !userProfile.onboardingComplete) {
    return <OnboardingWizard />;
  }
  if (!userProfile) {
    // Show loading skeleton or wizard
    return <OnboardingWizard />;
  }

  return (
    <div className="min-h-screen bg-bg-primary text-text-primary flex">
      {/* Sidebar Navigation */}
      <Sidebar collapsed={sidebarCollapsed} setCollapsed={setSidebarCollapsed} />

      {/* Main Container */}
      <div 
        className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${
          sidebarCollapsed ? 'pl-[72px]' : 'pl-[240px]'
        }`}
      >
        {/* Floating AI Aura Toggle Button */}
        <button
          onClick={() => setIsChatOpen(!isChatOpen)}
          className="fixed bottom-6 right-6 w-14 h-14 bg-accent-green hover:bg-accent-green/90 rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(48,209,88,0.45)] hover:shadow-[0_0_40px_rgba(48,209,88,0.65)] border border-white/20 transition-all transform hover:scale-115 active:scale-95 z-30 cursor-pointer group"
        >
          <div className="absolute inset-0 bg-accent-green rounded-full animate-ping opacity-35 group-hover:opacity-55" />
          <div className="relative z-10 flex items-center justify-center">
            <MessageSquare className="text-white w-6 h-6 drop-shadow-[0_0_8px_rgba(255,255,255,0.4)]" />
            <span className="absolute -top-1 -right-1.5 w-3 h-3 bg-[#111118] border-2 border-accent-green rounded-full flex items-center justify-center">
              <span className="w-1 h-1 bg-accent-green rounded-full animate-pulse" />
            </span>
          </div>
        </button>

        {/* Dynamic header / badge of active Panic Mode */}
        {isPanicMode && (
          <div className="bg-accent-red/10 border-b border-accent-red/30 py-2 px-4 text-center text-xs text-accent-red font-mono font-bold tracking-wider flex items-center justify-center space-x-2 animate-pulse">
            <Flame size={14} />
            <span>🚨 SYSTEM ALERT: PANIC MODE IN EFFECT — ACTIVE TACTICAL RESCUE SPRINT OPERATING 🚨</span>
          </div>
        )}

        {/* Content Wrapper */}
        <main className="flex-1 p-4 md:p-8 relative">
          {children}
        </main>
      </div>

      {/* AI Slide-in Chat Drawer */}
      <AIChatDrawer />

      {/* Virtual Simulated Call Screen overlay */}
      <VirtualCallOverlay />
    </div>
  );
}
