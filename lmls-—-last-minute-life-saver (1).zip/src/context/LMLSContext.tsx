import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, Task, Habit, Autopsy, ChatMessage, Subtask, WidgetPref, VirtualCallState } from '../types';
import confetti from 'canvas-confetti';
import { playSimulatedRingtone, stopSimulatedRingtone } from '../utils/sound';
import { 
  auth, 
  db, 
  initAuth, 
  googleSignIn, 
  logout as firebaseLogout, 
  handleFirestoreError, 
  OperationType 
} from '../firebase';
import { 
  doc, 
  getDoc, 
  setDoc, 
  deleteDoc, 
  collection, 
  getDocs 
} from 'firebase/firestore';

interface LMLSContextType {
  userProfile: UserProfile | null;
  tasks: Task[];
  habits: Habit[];
  autopsies: Autopsy[];
  chatHistory: ChatMessage[];
  activePage: string;
  isPanicMode: boolean;
  panicTaskId: string | null;
  isFocusLock: boolean;
  aiInsight: string;
  isAiInsightLoading: boolean;
  isChatOpen: boolean;
  
  // State Setters & Navigation
  setActivePage: (page: string) => void;
  setIsPanicMode: (active: boolean) => void;
  setPanicTaskId: (id: string | null) => void;
  setIsFocusLock: (active: boolean) => void;
  setIsChatOpen: (open: boolean) => void;
  setOnboarding: (profile: UserProfile, firstTask?: { title: string; deadline: string }) => void;
  saveProfile: (newProfile: UserProfile) => Promise<void>;

  // Widget Layout Customization
  widgets: WidgetPref[];
  saveWidgets: (updatedWidgets: WidgetPref[]) => void;
  resetWidgets: () => void;
  toggleWidgetVisibility: (id: string) => void;
  moveWidget: (index: number, direction: 'up' | 'down') => void;

  // Task Actions
  addTask: (task: Omit<Task, 'id' | 'createdAt' | 'completedAt' | 'priority' | 'status' | 'subtasks' | 'scheduledFor'>) => Task;
  updateTask: (id: string, updates: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  toggleTaskStatus: (id: string) => void;
  toggleSubtask: (taskId: string, subtaskId: string) => void;
  addSubtask: (taskId: string, title: string) => void;
  deleteSubtask: (taskId: string, subtaskId: string) => void;
  dragTaskPriority: (taskId: string, priority: Task['priority']) => void;

  // Habit Actions
  addHabit: (habit: Omit<Habit, 'id' | 'createdAt' | 'completions'>) => void;
  toggleHabitToday: (id: string, dateStr?: string) => void;
  deleteHabit: (id: string) => void;

  // AI Actions
  sendChatMessage: (content: string, mode?: string | null) => Promise<void>;
  clearChat: () => void;
  fetchAiInsight: () => Promise<void>;
  generateAiSubtasks: (taskId: string) => Promise<void>;
  optimizeSchedule: () => Promise<void>;
  runDeadlineAutopsy: (taskId: string) => Promise<void>;
  generateCascadeImpact: (taskId: string) => Promise<string[]>;

  // Metrics
  getQuickStats: () => { dueToday: number; completedThisWeek: number; currentStreak: number; panicSaves: number };

  // Firebase Auth & Google Workspace Integrations
  firebaseUser: any;
  googleAccessToken: string | null;
  isSyncing: boolean;
  loginWithGoogle: () => Promise<void>;
  signOut: () => Promise<void>;
  syncWithGoogleCalendar: (task: Task) => Promise<void>;
  syncWithGoogleTasks: (task: Task) => Promise<void>;
  fetchGoogleDriveFiles: () => Promise<any[]>;
  uploadToGoogleDrive: (name: string, content: string) => Promise<any>;
  sendGmailRescueDigest: () => Promise<void>;
  createGmailDraftExtension: (task: Task) => Promise<void>;
  
  // Virtual Call Integration Fallbacks
  virtualCall: VirtualCallState;
  triggerVirtualCall: (message: string, callerName?: string, phoneNumber?: string) => void;
  answerVirtualCall: () => void;
  endVirtualCall: () => void;
}

const LMLSContext = createContext<LMLSContextType | undefined>(undefined);

export function LMLSProvider({ children }: { children: React.ReactNode }) {
  // Page Routing & Drawer States
  const [activePage, setActivePage] = useState<string>('dashboard');
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  const [isPanicMode, setIsPanicMode] = useState<boolean>(false);
  const [panicTaskId, setPanicTaskId] = useState<string | null>(null);
  const [isFocusLock, setIsFocusLock] = useState<boolean>(false);
  
  // Domain States
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [autopsies, setAutopsies] = useState<Autopsy[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [aiInsight, setAiInsight] = useState<string>('Loading strategic insight from AI...');
  const [isAiInsightLoading, setIsAiInsightLoading] = useState<boolean>(false);

  // Virtual Call State
  const [virtualCall, setVirtualCall] = useState<VirtualCallState>({
    isOpen: false,
    status: 'ended',
    callerName: 'Karl (SaveMyDay Companion)',
    phoneNumber: '+1 (567) 402-5498',
    message: ''
  });

  // Firebase & Google Workspace state extensions
  const [firebaseUser, setFirebaseUser] = useState<any>(null);
  const [googleAccessToken, setGoogleAccessToken] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Widget Customization States & Helpers
  const DEFAULT_WIDGETS: WidgetPref[] = [
    { id: 'stats', name: 'Quick Stats', visible: true },
    { id: 'deadlines', name: 'Deadline Countdown Cards', visible: true },
    { id: 'focus', name: "Today's Focus Block", visible: true },
    { id: 'matrix', name: 'Priority Matrix', visible: true },
  ];

  const [widgets, setWidgets] = useState<WidgetPref[]>(() => {
    const saved = localStorage.getItem('lmls_dashboard_widgets');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const merged = DEFAULT_WIDGETS.map(dw => {
            const loaded = parsed.find((p: any) => p.id === dw.id);
            return loaded ? { ...dw, ...loaded } : dw;
          });
          const ordered = parsed
            .filter((p: any) => DEFAULT_WIDGETS.some(dw => dw.id === p.id))
            .map((p: any) => merged.find(m => m.id === p.id)!);
          const missing = merged.filter(m => !ordered.some(o => o.id === m.id));
          return [...ordered, ...missing];
        }
      } catch (e) {
        console.error('Failed to parse dashboard widgets, using defaults', e);
      }
    }
    return DEFAULT_WIDGETS;
  });

  const saveWidgets = (updatedWidgets: WidgetPref[]) => {
    setWidgets(updatedWidgets);
    localStorage.setItem('lmls_dashboard_widgets', JSON.stringify(updatedWidgets));
  };

  const toggleWidgetVisibility = (id: string) => {
    const updated = widgets.map(w => w.id === id ? { ...w, visible: !w.visible } : w);
    saveWidgets(updated);
  };

  const moveWidget = (index: number, direction: 'up' | 'down') => {
    const nextIndex = direction === 'up' ? index - 1 : index + 1;
    if (nextIndex < 0 || nextIndex >= widgets.length) return;
    const updated = [...widgets];
    const temp = updated[index];
    updated[index] = updated[nextIndex];
    updated[nextIndex] = temp;
    saveWidgets(updated);
  };

  const resetWidgets = () => {
    saveWidgets(DEFAULT_WIDGETS);
  };


  // Load from LocalStorage
  useEffect(() => {
    try {
      // Load and apply theme
      const savedTheme = localStorage.getItem('lmls_theme');
      if (savedTheme === 'light') {
        document.body.classList.add('light-mode');
      } else {
        document.body.classList.remove('light-mode');
      }

      const profile = localStorage.getItem('lmls_profile');
      if (profile) {
        setUserProfile(JSON.parse(profile));
      }

      const storedTasks = localStorage.getItem('lmls_tasks');
      if (storedTasks) {
        setTasks(JSON.parse(storedTasks));
      } else {
        // Seed initial mock tasks if empty for demo
        const now = new Date();
        const t1: Task = {
          id: 'task-seed-1',
          title: '🚨 Complete Hackathon Slide Deck',
          description: 'Design and polish slides highlighting AI capabilities, monetization strategies, and team member strengths.',
          deadline: new Date(now.getTime() + 1.5 * 60 * 60 * 1000).toISOString(), // 1.5 hours from now
          effort: 'deep',
          category: 'study',
          priority: 'critical',
          status: 'todo',
          subtasks: [
            { id: 'sub-1', title: 'Write outline', done: true },
            { id: 'sub-2', title: 'Add graphics and layout', done: false },
            { id: 'sub-3', title: 'Rehearse pitch script', done: false }
          ],
          createdAt: now.toISOString(),
          completedAt: null,
          notes: 'Make slides visually clean and minimalist.',
          scheduledFor: null,
        };
        const t2: Task = {
          id: 'task-seed-2',
          title: '📝 Finalize Project README.md',
          description: 'Document dependencies, deployment guidelines, and environment configuration.',
          deadline: new Date(now.getTime() + 12 * 60 * 60 * 1000).toISOString(), // 12 hours from now
          effort: 'medium',
          category: 'work',
          priority: 'important',
          status: 'todo',
          subtasks: [
            { id: 'sub-4', title: 'Fill API keys section', done: false },
            { id: 'sub-5', title: 'Write step-by-step setup guides', done: false }
          ],
          createdAt: now.toISOString(),
          completedAt: null,
          notes: 'Keep details clear.',
          scheduledFor: null,
        };
        const seed = [t1, t2];
        setTasks(seed);
        localStorage.setItem('lmls_tasks', JSON.stringify(seed));
      }

      const storedHabits = localStorage.getItem('lmls_habits');
      if (storedHabits) {
        setHabits(JSON.parse(storedHabits));
      } else {
        // Seed initial habits
        const now = new Date();
        const h1: Habit = {
          id: 'habit-seed-1',
          name: 'Read Technical Docs 📚',
          minimumViable: 'Read just 1 page of documentation',
          why: 'To keep building software development skills',
          category: 'Learning',
          frequency: 'daily',
          completions: [],
          createdAt: now.toISOString()
        };
        const h2: Habit = {
          id: 'habit-seed-2',
          name: 'Drink Water 💧',
          minimumViable: 'Drink 1 glass of water',
          why: 'Keep hydrated and focused during long screen sessions',
          category: 'Health',
          frequency: 'daily',
          completions: [],
          createdAt: now.toISOString()
        };
        const seedH = [h1, h2];
        setHabits(seedH);
        localStorage.setItem('lmls_habits', JSON.stringify(seedH));
      }

      const storedAutopsies = localStorage.getItem('lmls_autopsies');
      if (storedAutopsies) {
        setAutopsies(JSON.parse(storedAutopsies));
      }

      const storedChat = localStorage.getItem('lmls_chat');
      if (storedChat) {
        setChatHistory(JSON.parse(storedChat));
      } else {
        const welcomeMsg: ChatMessage = {
          role: 'assistant',
          content: "Hello! I am Sarah, your elite productivity companion. I monitor your upcoming deadlines and will actively intervene to save you from procrastinating. What task is causing you stress right now?",
          timestamp: new Date().toISOString(),
          mode: 'ARCHITECT MODE'
        };
        setChatHistory([welcomeMsg]);
        localStorage.setItem('lmls_chat', JSON.stringify([welcomeMsg]));
      }
    } catch (e) {
      console.error('Error loading data from localStorage', e);
    }

    // Init Firebase Auth State
    const unsubscribe = initAuth(
      async (user, token) => {
        setFirebaseUser(user);
        setGoogleAccessToken(token);
        await syncDataFromFirestore(user.uid);
      },
      () => {
        setFirebaseUser(null);
        setGoogleAccessToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const syncDataFromFirestore = async (uid: string) => {
    setIsSyncing(true);
    try {
      const idToken = await auth.currentUser?.getIdToken();
      if (!idToken) {
        throw new Error("No Firebase ID token found");
      }

      const headers = {
        'Authorization': `Bearer ${idToken}`,
        'Content-Type': 'application/json'
      };

      // 1. Profile
      let profileFetched = false;
      try {
        const profileRes = await fetch('/api/user/profile', { headers });
        if (profileRes.ok) {
          const pgProfile = await profileRes.json() as UserProfile;
          setUserProfile(pgProfile);
          localStorage.setItem('lmls_profile', JSON.stringify(pgProfile));
          profileFetched = true;
        } else if (profileRes.status === 404) {
          // Send local profile to Postgres if it exists
          const localProfile = localStorage.getItem('lmls_profile');
          if (localProfile) {
            const parsed = JSON.parse(localProfile);
            await fetch('/api/user/profile', {
              method: 'POST',
              headers,
              body: JSON.stringify(parsed)
            });
          }
        }
      } catch (err) {
        console.warn('PostgreSQL User Profile fetch failed, falling back to Firestore/local:', err);
      }

      if (!profileFetched) {
        const profileRef = doc(db, 'users', uid);
        const profileSnap = await getDoc(profileRef);
        if (profileSnap.exists()) {
          const cloudProfile = profileSnap.data() as UserProfile;
          setUserProfile(cloudProfile);
          localStorage.setItem('lmls_profile', JSON.stringify(cloudProfile));
        } else {
          // Seed Firestore with local profile if we have one
          const localProfile = localStorage.getItem('lmls_profile');
          if (localProfile) {
            const parsed = JSON.parse(localProfile);
            if (parsed) {
              await setDoc(profileRef, parsed);
            }
          }
        }
      }

      // 2. Tasks
      let tasksFetched = false;
      try {
        const tasksRes = await fetch('/api/tasks', { headers });
        if (tasksRes.ok) {
          const pgTasks = await tasksRes.json() as Task[];
          const sanitizedTasks = pgTasks.map(t => ({
            ...t,
            subtasks: typeof t.subtasks === 'string' ? JSON.parse(t.subtasks) : (t.subtasks || [])
          }));
          setTasks(sanitizedTasks);
          localStorage.setItem('lmls_tasks', JSON.stringify(sanitizedTasks));
          tasksFetched = true;
        }
      } catch (err) {
        console.warn('PostgreSQL Tasks fetch failed:', err);
      }

      if (!tasksFetched) {
        const tasksRef = collection(db, 'users', uid, 'tasks');
        const tasksSnap = await getDocs(tasksRef);
        const cloudTasks: Task[] = [];
        tasksSnap.forEach(d => {
          cloudTasks.push({ id: d.id, ...d.data() } as Task);
        });

        if (cloudTasks.length > 0) {
          setTasks(cloudTasks);
          localStorage.setItem('lmls_tasks', JSON.stringify(cloudTasks));
          try {
            await fetch('/api/tasks/sync', {
              method: 'POST',
              headers,
              body: JSON.stringify({ tasks: cloudTasks })
            });
          } catch (e) {
            console.error('Failed to seed PostgreSQL with cloud tasks:', e);
          }
        } else {
          // Seed Firestore with local tasks
          const localTasks = localStorage.getItem('lmls_tasks');
          if (localTasks) {
            const parsed = JSON.parse(localTasks) as Task[];
            for (const t of parsed) {
              await setDoc(doc(db, 'users', uid, 'tasks', t.id), {
                title: t.title,
                description: t.description || '',
                deadline: t.deadline,
                effort: t.effort,
                category: t.category,
                priority: t.priority,
                status: t.status,
                subtasks: t.subtasks || [],
                createdAt: t.createdAt,
                completedAt: t.completedAt || null,
                notes: t.notes || '',
                scheduledFor: t.scheduledFor || null
              });
            }
          }
        }
      }

      // 3. Habits
      let habitsFetched = false;
      try {
        const habitsRes = await fetch('/api/habits', { headers });
        if (habitsRes.ok) {
          const pgHabits = await habitsRes.json() as Habit[];
          const sanitizedHabits = pgHabits.map(h => ({
            ...h,
            frequency: typeof h.frequency === 'string' ? JSON.parse(h.frequency) : (h.frequency || 'daily'),
            completions: typeof h.completions === 'string' ? JSON.parse(h.completions) : (h.completions || [])
          }));
          setHabits(sanitizedHabits);
          localStorage.setItem('lmls_habits', JSON.stringify(sanitizedHabits));
          habitsFetched = true;
        }
      } catch (err) {
        console.warn('PostgreSQL Habits fetch failed:', err);
      }

      if (!habitsFetched) {
        const habitsRef = collection(db, 'users', uid, 'habits');
        const habitsSnap = await getDocs(habitsRef);
        const cloudHabits: Habit[] = [];
        habitsSnap.forEach(d => {
          cloudHabits.push({ id: d.id, ...d.data() } as Habit);
        });

        if (cloudHabits.length > 0) {
          setHabits(cloudHabits);
          localStorage.setItem('lmls_habits', JSON.stringify(cloudHabits));
          for (const h of cloudHabits) {
            try {
              await fetch('/api/habits', {
                method: 'POST',
                headers,
                body: JSON.stringify(h)
              });
            } catch (e) {
              console.error('Failed to seed PostgreSQL habit:', e);
            }
          }
        } else {
          // Seed Firestore with local habits
          const localHabits = localStorage.getItem('lmls_habits');
          if (localHabits) {
            const parsed = JSON.parse(localHabits) as Habit[];
            for (const h of parsed) {
              await setDoc(doc(db, 'users', uid, 'habits', h.id), {
                name: h.name,
                minimumViable: h.minimumViable,
                why: h.why,
                category: h.category,
                frequency: h.frequency,
                completions: h.completions || [],
                createdAt: h.createdAt
              });
            }
          }
        }
      }

      // 4. Autopsies
      let autopsiesFetched = false;
      try {
        const autopsiesRes = await fetch('/api/autopsies', { headers });
        if (autopsiesRes.ok) {
          const pgAutopsies = await autopsiesRes.json() as Autopsy[];
          setAutopsies(pgAutopsies);
          localStorage.setItem('lmls_autopsies', JSON.stringify(pgAutopsies));
          autopsiesFetched = true;
        }
      } catch (err) {
        console.warn('PostgreSQL Autopsies fetch failed:', err);
      }

      if (!autopsiesFetched) {
        const autopsiesRef = collection(db, 'users', uid, 'autopsies');
        const autopsiesSnap = await getDocs(autopsiesRef);
        const cloudAutopsies: Autopsy[] = [];
        autopsiesSnap.forEach(d => {
          cloudAutopsies.push({ id: d.id, ...d.data() } as Autopsy);
        });

        if (cloudAutopsies.length > 0) {
          setAutopsies(cloudAutopsies);
          localStorage.setItem('lmls_autopsies', JSON.stringify(cloudAutopsies));
          for (const a of cloudAutopsies) {
            try {
              await fetch('/api/autopsies', {
                method: 'POST',
                headers,
                body: JSON.stringify(a)
              });
            } catch (e) {
              console.error('Failed to seed PostgreSQL autopsy:', e);
            }
          }
        } else {
          // Seed Firestore with local autopsies
          const localAutopsies = localStorage.getItem('lmls_autopsies');
          if (localAutopsies) {
            const parsed = JSON.parse(localAutopsies) as Autopsy[];
            for (const a of parsed) {
              await setDoc(doc(db, 'users', uid, 'autopsies', a.id), {
                taskId: a.taskId,
                taskTitle: a.taskTitle,
                missedAt: a.missedAt,
                patternLabel: a.patternLabel,
                aiAnalysis: a.aiAnalysis,
                countermeasure: a.countermeasure
              });
            }
          }
        }
      }

      // 5. Chat History
      const chatRef = collection(db, 'users', uid, 'chatHistory');
      const chatSnap = await getDocs(chatRef);
      const cloudChat: ChatMessage[] = [];
      chatSnap.forEach(d => {
        cloudChat.push(d.data() as ChatMessage);
      });
      cloudChat.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

      if (cloudChat.length > 0) {
        setChatHistory(cloudChat);
        localStorage.setItem('lmls_chat', JSON.stringify(cloudChat));
      } else {
        // Seed Firestore with local chat
        const localChat = localStorage.getItem('lmls_chat');
        if (localChat) {
          const parsed = JSON.parse(localChat) as ChatMessage[];
          for (let i = 0; i < parsed.length; i++) {
            const m = parsed[i];
            const msgId = `chat-msg-${i}-${Date.now()}`;
            await setDoc(doc(db, 'users', uid, 'chatHistory', msgId), {
              role: m.role,
              content: m.content,
              timestamp: m.timestamp,
              mode: m.mode || null,
              suggestedTask: m.suggestedTask || null,
              suggestedSprintPlan: m.suggestedSprintPlan || null
            });
          }
        }
      }
    } catch (err) {
      console.error('Failed to sync from PostgreSQL/Firestore:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  // Sync state changes to LocalStorage and Firestore
  const saveProfile = async (newProfile: UserProfile) => {
    setUserProfile(newProfile);
    localStorage.setItem('lmls_profile', JSON.stringify(newProfile));
    if (firebaseUser) {
      try {
        await setDoc(doc(db, 'users', firebaseUser.uid), newProfile);
        const idToken = await auth.currentUser?.getIdToken();
        if (idToken) {
          await fetch('/api/user/profile', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${idToken}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(newProfile)
          });
        }
      } catch (e) {
        handleFirestoreError(e, OperationType.UPDATE, `users/${firebaseUser.uid}`);
      }
    }
  };

  const saveTasks = async (newTasks: Task[]) => {
    setTasks(newTasks);
    localStorage.setItem('lmls_tasks', JSON.stringify(newTasks));
    if (firebaseUser) {
      try {
        const idToken = await auth.currentUser?.getIdToken();
        if (idToken) {
          await fetch('/api/tasks/sync', {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${idToken}`,
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ tasks: newTasks })
          });
        }
      } catch (e) {
        console.error('Failed to sync tasks to PostgreSQL:', e);
      }
    }
  };

  const saveHabits = async (newHabits: Habit[]) => {
    setHabits(newHabits);
    localStorage.setItem('lmls_habits', JSON.stringify(newHabits));
    if (firebaseUser) {
      try {
        const idToken = await auth.currentUser?.getIdToken();
        if (idToken) {
          for (const h of newHabits) {
            await fetch('/api/habits', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${idToken}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(h)
            });
          }
        }
      } catch (e) {
        console.error('Failed to sync habits to PostgreSQL:', e);
      }
    }
  };

  const saveAutopsies = async (newAutopsies: Autopsy[]) => {
    setAutopsies(newAutopsies);
    localStorage.setItem('lmls_autopsies', JSON.stringify(newAutopsies));
    if (firebaseUser) {
      try {
        const idToken = await auth.currentUser?.getIdToken();
        if (idToken) {
          for (const a of newAutopsies) {
            await fetch('/api/autopsies', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${idToken}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify(a)
            });
          }
        }
      } catch (e) {
        console.error('Failed to sync autopsies to PostgreSQL:', e);
      }
    }
  };

  const saveChatHistory = async (newChat: ChatMessage[]) => {
    setChatHistory(newChat);
    localStorage.setItem('lmls_chat', JSON.stringify(newChat));
    if (firebaseUser && newChat.length > 0) {
      try {
        const lastMsg = newChat[newChat.length - 1];
        const msgId = `chat-msg-${newChat.length - 1}-${Date.now()}`;
        await setDoc(doc(db, 'users', firebaseUser.uid, 'chatHistory', msgId), {
          role: lastMsg.role,
          content: lastMsg.content,
          timestamp: lastMsg.timestamp,
          mode: lastMsg.mode || null,
          suggestedTask: lastMsg.suggestedTask || null,
          suggestedSprintPlan: lastMsg.suggestedSprintPlan || null
        });
      } catch (e) {
        handleFirestoreError(e, OperationType.CREATE, `users/${firebaseUser.uid}/chatHistory`);
      }
    }
  };

  // Google Workspace API actions
  const loginWithGoogle = async () => {
    const res = await googleSignIn();
    if (res) {
      setFirebaseUser(res.user);
      setGoogleAccessToken(res.accessToken);
      await syncDataFromFirestore(res.user.uid);
    }
  };

  const signOut = async () => {
    await firebaseLogout();
    setFirebaseUser(null);
    setGoogleAccessToken(null);
  };

  const syncWithGoogleCalendar = async (task: Task) => {
    if (!googleAccessToken) throw new Error("Please connect your Google Account first");
    const url = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';
    const startDateTime = new Date(task.deadline);
    const body = {
      summary: `🚨 SaveMyDay RESCUE: ${task.title}`,
      description: `Task description: ${task.description || 'No description'}\nPriority: ${task.priority}\nEffort: ${task.effort}\nNotes: ${task.notes || 'None'}`,
      start: {
        dateTime: new Date(startDateTime.getTime() - 60 * 60 * 1000).toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
      },
      end: {
        dateTime: startDateTime.toISOString(),
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'
      },
      colorId: '11' // Bold Red
    };

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${googleAccessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body)
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Failed to sync with Google Calendar');
    }
  };

  const syncWithGoogleTasks = async (task: Task) => {
    if (!googleAccessToken) throw new Error("Please connect your Google Account first");
    
    // Retrieve Task Lists
    const listUrl = 'https://www.googleapis.com/tasks/v1/users/@me/lists';
    const listRes = await fetch(listUrl, {
      headers: { 'Authorization': `Bearer ${googleAccessToken}` }
    });
    if (!listRes.ok) throw new Error('Failed to retrieve task lists');
    const listsData = await listRes.json();
    let listId = '';
    const targetList = listsData.items?.find((l: any) => l.title === 'SaveMyDay Rescue Tasks');
    if (targetList) {
      listId = targetList.id;
    } else {
      // Create new list
      const createRes = await fetch(listUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${googleAccessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title: 'SaveMyDay Rescue Tasks' })
      });
      if (!createRes.ok) throw new Error('Failed to create SaveMyDay Task List');
      const createdList = await createRes.json();
      listId = createdList.id;
    }

    // Insert Task
    const insertUrl = `https://www.googleapis.com/tasks/v1/lists/${listId}/tasks`;
    const taskBody = {
      title: `🚨 ${task.title}`,
      notes: `${task.description || ''}\n\nEffort: ${task.effort}\nPriority: ${task.priority}\nStatus: ${task.status}`,
      due: new Date(task.deadline).toISOString(),
      status: task.status === 'done' ? 'completed' : 'needsAction'
    };

    const insertRes = await fetch(insertUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${googleAccessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(taskBody)
    });

    if (!insertRes.ok) {
      const err = await insertRes.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Failed to insert task in Google Tasks');
    }
  };

  const fetchGoogleDriveFiles = async () => {
    if (!googleAccessToken) return [];
    const url = 'https://www.googleapis.com/drive/v3/files?q=trashed%3Dfalse&pageSize=20&fields=files(id,name,mimeType,webViewLink,iconLink)';
    const res = await fetch(url, {
      headers: { 'Authorization': `Bearer ${googleAccessToken}` }
    });
    if (!res.ok) throw new Error('Failed to fetch Google Drive files');
    const data = await res.json();
    return data.files || [];
  };

  const uploadToGoogleDrive = async (name: string, content: string) => {
    if (!googleAccessToken) throw new Error("Please connect your Google Account first");
    const metadata = {
      name: name,
      mimeType: 'text/plain'
    };
    const fileData = new Blob([content], { type: 'text/plain' });
    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', fileData);

    const url = 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart';
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${googleAccessToken}`
      },
      body: form
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Failed to upload file to Google Drive');
    }
    return res.json();
  };

  const sendGmailRescueDigest = async () => {
    if (!googleAccessToken) throw new Error("Please connect your Google Account first");
    if (!firebaseUser?.email) throw new Error("No registered user email found to send rescue digest to");

    const upcoming = tasks.filter(t => t.status !== 'done');
    const checklistHtml = upcoming.map(t => `
      <li style="margin-bottom: 12px; padding: 10px; border-left: 4px solid ${t.priority === 'critical' ? '#FF3B30' : t.priority === 'important' ? '#FF9500' : '#007AFF'}; background: #F2F2F7; border-radius: 0 6px 6px 0; list-style-type: none;">
        <strong style="font-size: 14px; color: #1C1C1E;">${t.title}</strong><br/>
        <span style="font-size: 11px; font-family: monospace; color: #8E8E93;">
          DEADLINE: ${new Date(t.deadline).toLocaleString()} | PRIORITY: ${t.priority.toUpperCase()} | EFFORT: ${t.effort.toUpperCase()}
        </span>
        ${t.description ? `<p style="margin: 4px 0 0 0; font-size: 12px; color: #3A3A3C;">${t.description}</p>` : ''}
      </li>
    `).join('');

    const bodyHtml = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #E5E5EA; border-radius: 12px; background: #FFFFFF;">
        <div style="text-align: center; margin-bottom: 24px;">
          <h1 style="color: #FF3B30; margin: 0; font-size: 24px; font-weight: 800; letter-spacing: -0.5px;">🚨 SaveMyDay RESCUE SQUAD</h1>
          <p style="color: #8E8E93; margin: 4px 0 0 0; font-size: 12px; text-transform: uppercase; font-weight: 600; letter-spacing: 1px;">Your Active High-Stakes Deadlines</p>
        </div>
        <p style="font-size: 14px; color: #1C1C1E; line-height: 1.5;">
          Hello ${userProfile?.name || 'User'},<br/><br/>
          This is an automated <strong>SaveMyDay</strong> rescue briefing. Below is the list of your active high-stakes deadlines requiring immediate attention:
        </p>
        <ul style="padding: 0; margin: 20px 0;">
          ${checklistHtml || '<li style="text-align: center; color: #30D158; list-style-type: none; padding: 20px;">🎉 All clean! No pending deadlines.</li>'}
        </ul>
        <p style="font-size: 13px; color: #8E8E93; line-height: 1.4; border-top: 1px solid #E5E5EA; padding-top: 16px; margin-top: 24px;">
          Keep pushing. When your deadlines get within 2 hours, SaveMyDay will automatically prompt PANIC MODE to guide you sprint-by-sprint.
        </p>
      </div>
    `;

    const makeEmail = (to: string, subject: string, body: string) => {
      const str = [
        `To: ${to}`,
        'Content-Type: text/html; charset=utf-8',
        'MIME-Version: 1.0',
        `Subject: =?utf-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
        '',
        body
      ].join('\r\n');
      return btoa(unescape(encodeURIComponent(str)))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');
    };

    const rawMsg = makeEmail(firebaseUser.email, "🚨 SaveMyDay Rescue Briefing: Your Approaching Deadlines", bodyHtml);

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${googleAccessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ raw: rawMsg })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Failed to send Rescue Email');
    }
  };

  const createGmailDraftExtension = async (task: Task) => {
    if (!googleAccessToken) throw new Error("Please connect your Google Account first");

    let draftText = `Dear Recipient,

I hope you are well.

I am writing to request a short extension for the task "${task.title}". Due to unexpected scheduling constraints, I want to ensure the final deliverable meets high quality standards. Would it be possible to adjust the target date?

Thank you for your understanding.

Best regards,
${userProfile?.name || 'User'}`;

    try {
      const idToken = await auth.currentUser?.getIdToken();
      if (idToken) {
        const geminiRes = await fetch('/api/chat', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${idToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            message: `Generate a polite, highly professional email requesting a deadline extension for a task titled "${task.title}" with description "${task.description || ''}". Address it placeholder style, keep it clear, elegant, and ready to send. Return only the email body text.`
          })
        });
        if (geminiRes.ok) {
          const geminiData = await geminiRes.json();
          if (geminiData.content) {
            draftText = geminiData.content;
          }
        }
      }
    } catch (e) {
      console.warn('Failed to generate intelligent draft, falling back to default:', e);
    }

    const draftHtml = draftText.replace(/\n/g, '<br/>');

    const makeEmail = (to: string, subject: string, body: string) => {
      const str = [
        `To: ${to}`,
        'Content-Type: text/html; charset=utf-8',
        'MIME-Version: 1.0',
        `Subject: =?utf-8?B?${btoa(unescape(encodeURIComponent(subject)))}?=`,
        '',
        body
      ].join('\r\n');
      return btoa(unescape(encodeURIComponent(str)))
        .replace(/\+/g, '-')
        .replace(/\//g, '_')
        .replace(/=+$/, '');
    };

    const rawMsg = makeEmail('recipient@example.com', `Request for Extension: ${task.title}`, draftHtml);

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/drafts', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${googleAccessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: { raw: rawMsg }
      })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error?.message || 'Failed to create Gmail Draft');
    }
  };

  const triggerVirtualCall = (message: string, callerName?: string, phoneNumber?: string) => {
    // End any current active call
    try {
      stopSimulatedRingtone();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch (e) {}

    setVirtualCall({
      isOpen: true,
      status: 'ringing',
      callerName: callerName || 'Karl (SaveMyDay Companion)',
      phoneNumber: phoneNumber || '+1 (567) 402-5498',
      message: message
    });

    // Play ringtone
    try {
      playSimulatedRingtone();
    } catch (e) {
      console.warn('Ringtone play failed:', e);
    }
  };

  const answerVirtualCall = () => {
    stopSimulatedRingtone();
    setVirtualCall(prev => ({ ...prev, status: 'active' }));

    // Use Web Speech Synthesis to read out the prompt!
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();

        let textToSpeak = virtualCall.message;
        
        // Parse out instruction meta tags if Karl prompt has them
        if (textToSpeak.includes('Deliver this')) {
          const match = textToSpeak.match(/Deliver this (?:urgent focus reminder|urgent focus alert|exact direct voice reminder) to [^:]+:\s*"([^"]+)"/i);
          if (match && match[1]) {
            textToSpeak = match[1];
          }
        } else if (textToSpeak.includes('Speak this')) {
          const match = textToSpeak.match(/Speak this exact (?:short reminder|direct voice reminder) to [^:]+:\s*"([^"]+)"/i);
          if (match && match[1]) {
            textToSpeak = match[1];
          }
        } else if (textToSpeak.includes('Deliver a test message')) {
          const match = textToSpeak.match(/Deliver a test message to [^:]+:\s*"([^"]+)"/i);
          if (match && match[1]) {
            textToSpeak = match[1];
          }
        }
        
        textToSpeak = textToSpeak.replace(/^["'\s]+|["'\s]+$/g, '');

        const utterance = new SpeechSynthesisUtterance(textToSpeak);
        
        const voices = window.speechSynthesis.getVoices();
        const preferredVoice = voices.find(v => 
          v.name.toLowerCase().includes('google us english') || 
          v.name.toLowerCase().includes('male') || 
          v.name.toLowerCase().includes('microsoft david') ||
          v.lang.startsWith('en-US')
        );
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }
        
        utterance.rate = 1.05;
        utterance.pitch = 0.95;

        utterance.onend = () => {
          setTimeout(() => {
            endVirtualCall();
          }, 2000);
        };

        window.speechSynthesis.speak(utterance);
      } else {
        // Automatically close after 10s if no speech synthesis
        setTimeout(() => {
          endVirtualCall();
        }, 10000);
      }
    } catch (e) {
      console.warn('Speech synthesis failed:', e);
      setTimeout(() => {
        endVirtualCall();
      }, 8000);
    }
  };

  const endVirtualCall = () => {
    stopSimulatedRingtone();
    try {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    } catch (e) {}

    setVirtualCall(prev => {
      if (!prev.isOpen) return prev;
      return { ...prev, status: 'ended', isOpen: false };
    });
  };


  // Helper: Build context string for API requests
  const getContextString = () => {
    const now = new Date();
    const tasksArr = Array.isArray(tasks) ? tasks.filter(Boolean) : [];
    const overdue = tasksArr.filter(t => t && t.deadline && new Date(t.deadline) < now && t.status !== 'done');
    const upcoming24h = tasksArr.filter(t => {
      if (!t || !t.deadline) return false;
      const diff = new Date(t.deadline).getTime() - now.getTime();
      return diff > 0 && diff < 86400000 && t.status !== 'done';
    });
    const pending = tasksArr.filter(t => t && t.status !== 'done');
    const completed = tasksArr.filter(t => t && t.status === 'done');

    return `
[USER PROFILE]
Name: ${userProfile?.name || 'User'}
Peak Energy Period: ${userProfile?.peakEnergyTime || 'morning'}
Panic Saves: ${userProfile?.panicSaveCount || 0}

[DEADLINES]
Overdue Tasks (${overdue.length}):
${overdue.map(t => `- "${t?.title || 'Untitled'}" (Due: ${t?.deadline || 'No deadline'}, Category: ${t?.category || 'general'}, Effort: ${t?.effort || 'medium'}, Priority: ${t?.priority || 'flexible'})`).join('\n')}

Due in Next 24 Hours (${upcoming24h.length}):
${upcoming24h.map(t => `- "${t?.title || 'Untitled'}" (Due: ${t?.deadline || 'No deadline'}, Category: ${t?.category || 'general'}, Effort: ${t?.effort || 'medium'}, Priority: ${t?.priority || 'flexible'})`).join('\n')}

[ALL PENDING TASKS]
${pending.map(t => `- "${t?.title || 'Untitled'}" (Due: ${t?.deadline || 'No deadline'}, Category: ${t?.category || 'general'}, Effort: ${t?.effort || 'medium'}, Priority: ${t?.priority || 'flexible'}, Status: ${t?.status || 'todo'})`).join('\n')}

[COMPLETED TASKS (RECENT)]
${completed.slice(0, 5).map(t => `- "${t?.title || 'Untitled'}" (Completed: ${t?.completedAt || 'N/A'}, Category: ${t?.category || 'general'})`).join('\n')}

Total Pending Tasks: ${pending.length}
Total Active Habits: ${Array.isArray(habits) ? habits.length : 0}
`;
  };

  // Onboarding wizard completion
  const setOnboarding = (profile: UserProfile, firstTask?: { title: string; deadline: string }) => {
    saveProfile(profile);
    if (firstTask && firstTask.title) {
      addTask({
        title: firstTask.title,
        description: 'Primary high-stakes task logged during onboarding.',
        deadline: firstTask.deadline,
        effort: 'deep',
        category: 'work',
        notes: '',
      });
    }
    
    // Add custom welcome greeting in chat history
    const introMsg: ChatMessage = {
      role: 'assistant',
      content: `Welcome, ${profile.name}! I'm Sarah, your personal AI companion. I've logged your high-priority target deadline. When tasks get closer than 2 hours to deadline, I will auto-engage PANIC MODE 🚨 to guide you sprint-by-sprint. Let me know if you want me to plan out subtasks or optimize your schedule.`,
      timestamp: new Date().toISOString(),
      mode: 'ARCHITECT MODE'
    };
    saveChatHistory([introMsg]);
    fetchAiInsight();
  };

  // Task Actions
  const addTask = (fields: Omit<Task, 'id' | 'createdAt' | 'completedAt' | 'priority' | 'status' | 'subtasks' | 'scheduledFor'>) => {
    const now = new Date();
    const diffHours = (new Date(fields.deadline).getTime() - now.getTime()) / (1000 * 60 * 60);
    
    let priority: Task['priority'] = 'flexible';
    if (diffHours < 4) priority = 'critical';
    else if (diffHours < 24) priority = 'important';
    
    const newTask: Task = {
      ...fields,
      id: `task-${Date.now()}`,
      priority,
      status: 'todo',
      subtasks: [],
      createdAt: now.toISOString(),
      completedAt: null,
      scheduledFor: null,
      callReminderSent: fields.callReminderSent ?? false,
    };

    saveTasks([newTask, ...tasks]);
    fetchAiInsight();
    return newTask;
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    const updated = tasks.map(t => {
      if (t.id === id) {
        const result = { ...t, ...updates };
        // Recalculate priority automatically if deadline changed and priority wasn't overridden
        if (updates.deadline) {
          const now = new Date();
          const diffHours = (new Date(updates.deadline).getTime() - now.getTime()) / (1000 * 60 * 60);
          if (!updates.priority) {
            if (diffHours < 4) result.priority = 'critical';
            else if (diffHours < 24) result.priority = 'important';
            else result.priority = 'flexible';
          }
        }
        return result;
      }
      return t;
    });
    saveTasks(updated);
  };

  const deleteTask = async (id: string) => {
    saveTasks(tasks.filter(t => t.id !== id));
    if (firebaseUser) {
      try {
        const idToken = await auth.currentUser?.getIdToken();
        if (idToken) {
          await fetch(`/api/tasks/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${idToken}` }
          });
        }
      } catch (err) {
        console.error('Failed to delete task from PostgreSQL:', err);
      }
    }
  };

  const toggleTaskStatus = (id: string) => {
    const updated = tasks.map(t => {
      if (t.id === id) {
        const isNowDone = t.status !== 'done';
        if (isNowDone) {
          confetti({
            particleCount: 150,
            spread: 80,
            origin: { y: 0.6 },
            colors: ['#FF3B5C', '#FF9500', '#30D158', '#0A84FF', '#BF5AF2']
          });

          // Check if this task completion rescues from Panic Mode
          if (isPanicMode && panicTaskId === id) {
            setIsPanicMode(false);
            setPanicTaskId(null);
            setIsFocusLock(false);
            // Log Panic Save
            if (userProfile) {
              saveProfile({
                ...userProfile,
                panicSaveCount: userProfile.panicSaveCount + 1,
              });
            }
          }

          return {
            ...t,
            status: 'done' as const,
            completedAt: new Date().toISOString(),
          };
        } else {
          return {
            ...t,
            status: 'todo' as const,
            completedAt: null,
          };
        }
      }
      return t;
    });
    saveTasks(updated);
  };

  const toggleSubtask = (taskId: string, subtaskId: string) => {
    const updated = tasks.map(t => {
      if (t.id === taskId) {
        const updatedSubs = t.subtasks.map(s => 
          s.id === subtaskId ? { ...s, done: !s.done } : s
        );
        return { ...t, subtasks: updatedSubs };
      }
      return t;
    });
    saveTasks(updated);
  };

  const addSubtask = (taskId: string, title: string) => {
    const updated = tasks.map(t => {
      if (t.id === taskId) {
        const newSub: Subtask = {
          id: `sub-${Date.now()}`,
          title,
          done: false
        };
        return { ...t, subtasks: [...t.subtasks, newSub] };
      }
      return t;
    });
    saveTasks(updated);
  };

  const deleteSubtask = (taskId: string, subtaskId: string) => {
    const updated = tasks.map(t => {
      if (t.id === taskId) {
        return { ...t, subtasks: t.subtasks.filter(s => s.id !== subtaskId) };
      }
      return t;
    });
    saveTasks(updated);
  };

  const dragTaskPriority = (taskId: string, priority: Task['priority']) => {
    const updated = tasks.map(t => 
      t.id === taskId ? { ...t, priority } : t
    );
    saveTasks(updated);
  };

  // Habit Actions
  const addHabit = (habitFields: Omit<Habit, 'id' | 'createdAt' | 'completions'>) => {
    const newHabit: Habit = {
      ...habitFields,
      id: `habit-${Date.now()}`,
      createdAt: new Date().toISOString(),
      completions: []
    };
    saveHabits([newHabit, ...habits]);
  };

  const toggleHabitToday = (id: string, dateStr?: string) => {
    const today = dateStr || new Date().toISOString().split('T')[0];
    const updated = habits.map(h => {
      if (h.id === id) {
        const isCompleted = h.completions.includes(today);
        let completions = [...h.completions];
        if (isCompleted) {
          completions = completions.filter(d => d !== today);
        } else {
          completions.push(today);
          // Play micro confetti burst
          confetti({
            particleCount: 50,
            spread: 40,
            origin: { y: 0.8 },
            colors: ['#30D158', '#0A84FF']
          });
        }
        return { ...h, completions };
      }
      return h;
    });
    saveHabits(updated);
  };

  const deleteHabit = async (id: string) => {
    saveHabits(habits.filter(h => h.id !== id));
    if (firebaseUser) {
      try {
        const idToken = await auth.currentUser?.getIdToken();
        if (idToken) {
          await fetch(`/api/habits/${id}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${idToken}` }
          });
        }
      } catch (err) {
        console.error('Failed to delete habit from PostgreSQL:', err);
      }
    }
  };

  // Helper to extract JSON block inside [TAG: { ... }] structures robustly
  const extractJsonBlock = (text: string, tag: string) => {
    const marker = `[${tag}:`;
    const index = text.toUpperCase().indexOf(marker);
    if (index === -1) return null;

    const jsonStart = text.indexOf("{", index);
    if (jsonStart === -1) return null;

    let braceCount = 0;
    let jsonEnd = -1;
    for (let i = jsonStart; i < text.length; i++) {
      const char = text[i];
      if (char === "{") braceCount++;
      else if (char === "}") {
        braceCount--;
        if (braceCount === 0) {
          jsonEnd = i + 1;
          break;
        }
      }
    }

    if (jsonEnd === -1) return null;

    const jsonStr = text.substring(jsonStart, jsonEnd);
    const blockEnd = text.indexOf("]", jsonEnd);
    const replaceEnd = blockEnd !== -1 ? blockEnd + 1 : jsonEnd;
    const cleanedText = text.substring(0, index) + text.substring(replaceEnd);

    try {
      const json = JSON.parse(jsonStr);
      return { json, cleanedText };
    } catch (e) {
      console.error(`Failed to parse ${tag} JSON`, e);
      return null;
    }
  };

  // Chat Helpers: Parse mode indicators and suggest cards
  const parseAiResponse = (text: string): ChatMessage => {
    let mode: string | null = null;
    const modeMatch = text.match(/\[MODE:\s*([^\]]+)\]/i);
    if (modeMatch) {
      mode = modeMatch[1].trim();
    }

    // Clean tag lines out of final display text
    let displayContent = text.replace(/\[MODE:\s*([^\]]+)\]\s*\n?/gi, '').trim();

    // Look for Suggest Task block
    let suggestedTask: ChatMessage['suggestedTask'] | undefined;
    const taskResult = extractJsonBlock(displayContent, 'SUGGEST_TASK');
    if (taskResult) {
      suggestedTask = taskResult.json;
      displayContent = taskResult.cleanedText.trim();
    }

    // Look for Sprint Plan block
    let suggestedSprintPlan: ChatMessage['suggestedSprintPlan'] | undefined;
    const sprintResult = extractJsonBlock(displayContent, 'SPRINT_PLAN');
    if (sprintResult) {
      suggestedSprintPlan = sprintResult.json;
      displayContent = sprintResult.cleanedText.trim();
    }

    return {
      role: 'assistant',
      content: displayContent,
      timestamp: new Date().toISOString(),
      mode,
      suggestedTask,
      suggestedSprintPlan
    };
  };

  // Send message to Express LLM Chat Proxy
  const sendChatMessage = async (content: string, mode?: string | null) => {
    const userMsg: ChatMessage = {
      role: 'user',
      content,
      timestamp: new Date().toISOString(),
      mode: null
    };

    const newHistory = [...chatHistory, userMsg];
    saveChatHistory(newHistory);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map(m => ({ role: m.role, content: m.content })),
          context: getContextString(),
          mode: mode || null
        }),
      });

      if (!response.ok) throw new Error("Server error");
      const data = await response.json();
      
      let text = data.text;
      if (data.groundingChunks && data.groundingChunks.length > 0) {
        const links = data.groundingChunks
          .map((chunk: any) => {
            const title = chunk.web?.title || chunk.web?.uri || 'Source';
            const uri = chunk.web?.uri;
            return uri ? `- [${title}](${uri})` : null;
          })
          .filter(Boolean);
        if (links.length > 0) {
          text += `\n\n**Search Sources:**\n${links.join('\n')}`;
        }
      }

      const assistantMsg = parseAiResponse(text);
      saveChatHistory([...newHistory, assistantMsg]);
    } catch (error) {
      console.warn("LLM Chat request failed", error);
      const errMessage: ChatMessage = {
        role: 'assistant',
        content: "Oops! My primary satellite telemetry is failing, but let's not panic. I'm right here. Keep focus on the task, or let me know if you want me to retry optimization.",
        timestamp: new Date().toISOString(),
        mode: 'PANIC MODE'
      };
      saveChatHistory([...newHistory, errMessage]);
    }
  };

  const clearChat = () => {
    const welcomeMsg: ChatMessage = {
      role: 'assistant',
      content: "Chat cleared! How can I rescue your productivity today?",
      timestamp: new Date().toISOString(),
      mode: 'ARCHITECT MODE'
    };
    saveChatHistory([welcomeMsg]);
  };

  // Get general contextual AI Insight
  const fetchAiInsight = async () => {
    setIsAiInsightLoading(true);
    try {
      const response = await fetch('/api/insight', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ context: getContextString() }),
      });
      if (response.ok) {
        const data = await response.json();
        setAiInsight(data.insight);
      }
    } catch (error) {
      console.warn("AI Insight fetch failed", error);
      setAiInsight("Procrastination is energy debt. Pay a small installment now by writing an outline.");
    } finally {
      setIsAiInsightLoading(false);
    }
  };

  // AI Subtasks Generator
  const generateAiSubtasks = async (taskId: string) => {
    const target = tasks.find(t => t.id === taskId);
    if (!target) return;

    try {
      const response = await fetch('/api/subtasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskTitle: target.title,
          taskDesc: target.description,
          category: target.category,
          effort: target.effort,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.subtasks) {
          const updated = tasks.map(t => 
            t.id === taskId ? { ...t, subtasks: [...t.subtasks, ...data.subtasks] } : t
          );
          saveTasks(updated);
        }
      }
    } catch (e) {
      console.warn("Subtasks generation failed", e);
    }
  };

  // AI Schedule Optimizer
  const optimizeSchedule = async () => {
    const pending = tasks.filter(t => t.status !== 'done');
    if (pending.length === 0) return;

    try {
      const response = await fetch('/api/optimize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tasks: pending,
          peakEnergyTime: userProfile?.peakEnergyTime || 'morning',
        }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data.schedule && Array.isArray(data.schedule)) {
          const updated = tasks.map(t => {
            const sched = data.schedule.find((s: any) => s.id === t.id);
            if (sched) {
              return { ...t, scheduledFor: sched.scheduledFor };
            }
            return t;
          });
          saveTasks(updated);
          
          // Send feedback message to user in chat drawer
          const optMsg: ChatMessage = {
            role: 'assistant',
            content: `🗓️ **AI Week Optimization Complete**:\n\n${data.feedback}\n\nI have auto-scheduled your pending tasks to optimal slots on your calendar. Check them out in the **Planner**!`,
            timestamp: new Date().toISOString(),
            mode: 'ARCHITECT MODE'
          };
          saveChatHistory([...chatHistory, optMsg]);
          setIsChatOpen(true);
        }
      }
    } catch (e) {
      console.warn("Optimization request failed", e);
    }
  };

  // Run Deadline Autopsy
  const runDeadlineAutopsy = async (taskId: string) => {
    const target = tasks.find(t => t.id === taskId);
    if (!target) return;

    try {
      const response = await fetch('/api/autopsy', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskTitle: target.title,
          missedAt: target.deadline,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const newAutopsy: Autopsy = {
          id: `autopsy-${Date.now()}`,
          taskId,
          taskTitle: target.title,
          missedAt: target.deadline,
          patternLabel: data.patternLabel,
          aiAnalysis: data.aiAnalysis,
          countermeasure: data.countermeasure,
        };
        saveAutopsies([newAutopsy, ...autopsies]);
        // Update task status to missed
        updateTask(taskId, { status: 'missed' });
      }
    } catch (e) {
      console.warn("Autopsy run failed", e);
    }
  };

  // Generate Cascade Impact
  const generateCascadeImpact = async (taskId: string): Promise<string[]> => {
    const target = tasks.find(t => t.id === taskId);
    if (!target) return [];

    try {
      const response = await fetch('/api/cascade', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          taskTitle: target.title,
          deadline: target.deadline,
          category: target.category,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        return data.chain || [];
      }
    } catch (e) {
      console.warn("Cascade extraction failed", e);
    }
    return [
      `Missing deadline for "${target.title}" increases friction`,
      "Triggers cascading stress for other scheduled targets",
      "Saves turn into critical panic rescues later",
      "Increases risk of burnout next week"
    ];
  };

  // Metric calculation helpers
  const getQuickStats = () => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    // Tasks due today: incomplete tasks whose deadline is calendar day today
    const dueToday = tasks.filter(t => {
      if (t.status === 'done') return false;
      const dDateStr = new Date(t.deadline).toISOString().split('T')[0];
      return dDateStr === todayStr;
    }).length;

    // Completed this week: tasks completed in last 7 days
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const completedThisWeek = tasks.filter(t => 
      t.status === 'done' && t.completedAt && new Date(t.completedAt) >= oneWeekAgo
    ).length;

    // Current Habit streak: count consecutive completed days across all habits
    let currentStreak = 0;
    if (habits.length > 0) {
      const streaks = habits.map(h => {
        let streak = 0;
        let checkDate = new Date();
        while (true) {
          const dateStr = checkDate.toISOString().split('T')[0];
          if (h.completions.includes(dateStr)) {
            streak++;
            checkDate.setDate(checkDate.getDate() - 1);
          } else {
            // Also accept check date is today and not yet completed if yesterday was completed
            if (streak === 0) {
              const yesterday = new Date();
              yesterday.setDate(yesterday.getDate() - 1);
              const yesStr = yesterday.toISOString().split('T')[0];
              if (h.completions.includes(yesStr)) {
                // Streak is active from yesterday
                checkDate.setDate(checkDate.getDate() - 1);
                continue;
              }
            }
            break;
          }
        }
        return streak;
      });
      currentStreak = Math.max(...streaks, 0);
    }

    const panicSaves = userProfile?.panicSaveCount || 0;

    return { dueToday, completedThisWeek, currentStreak, panicSaves };
  };

  return (
    <LMLSContext.Provider value={{
      userProfile,
      tasks,
      habits,
      autopsies,
      chatHistory,
      activePage,
      isPanicMode,
      panicTaskId,
      isFocusLock,
      aiInsight,
      isAiInsightLoading,
      isChatOpen,
      setActivePage,
      setIsPanicMode,
      setPanicTaskId,
      setIsFocusLock,
      setIsChatOpen,
      setOnboarding,
      saveProfile,
      widgets,
      saveWidgets,
      resetWidgets,
      toggleWidgetVisibility,
      moveWidget,
      addTask,
      updateTask,
      deleteTask,
      toggleTaskStatus,
      toggleSubtask,
      addSubtask,
      deleteSubtask,
      dragTaskPriority,
      addHabit,
      toggleHabitToday,
      deleteHabit,
      sendChatMessage,
      clearChat,
      fetchAiInsight,
      generateAiSubtasks,
      optimizeSchedule,
      runDeadlineAutopsy,
      generateCascadeImpact,
      getQuickStats,
      firebaseUser,
      googleAccessToken,
      isSyncing,
      loginWithGoogle,
      signOut,
      syncWithGoogleCalendar,
      syncWithGoogleTasks,
      fetchGoogleDriveFiles,
      uploadToGoogleDrive,
      sendGmailRescueDigest,
      createGmailDraftExtension,
      virtualCall,
      triggerVirtualCall,
      answerVirtualCall,
      endVirtualCall
    }}>
      {children}
    </LMLSContext.Provider>
  );
}

export function useLMLS() {
  const context = useContext(LMLSContext);
  if (!context) throw new Error("useLMLS must be used within LMLSProvider");
  return context;
}
