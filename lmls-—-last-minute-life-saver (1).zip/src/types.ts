export interface UserProfile {
  name: string;
  peakEnergyTime: 'morning' | 'afternoon' | 'night';
  onboardingComplete: boolean;
  panicSaveCount: number;
  joinedAt: string;
  phoneNumber?: string;
  voiceSelection?: string;
}

export interface Subtask {
  id: string;
  title: string;
  done: boolean;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  deadline: string; // ISO 8601 String
  effort: 'quick' | 'medium' | 'deep';
  category: 'work' | 'study' | 'personal' | 'health' | 'finance';
  priority: 'critical' | 'important' | 'flexible' | 'park';
  status: 'todo' | 'in-progress' | 'done' | 'missed';
  subtasks: Subtask[];
  createdAt: string;
  completedAt: string | null;
  notes: string;
  scheduledFor: string | null;
  callReminderTime?: string | null;
  callReminderMinutesBefore?: number | null;
  callReminderSent?: boolean;
}

export interface Habit {
  id: string;
  name: string;
  minimumViable: string;
  why: string;
  category: string;
  frequency: 'daily' | 'weekdays' | number[]; // Array of weekdays 0-6 (Sunday is 0)
  completions: string[]; // List of YYYY-MM-DD date strings
  createdAt: string;
}

export interface Autopsy {
  id: string;
  taskId: string;
  taskTitle: string;
  missedAt: string;
  patternLabel: string;
  aiAnalysis: string;
  countermeasure: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  mode: string | null;
  suggestedTask?: {
    title: string;
    deadline: string;
    effort: 'quick' | 'medium' | 'deep';
    category: 'work' | 'study' | 'personal' | 'health' | 'finance';
  };
  suggestedSprintPlan?: {
    title: string;
    sprints: Array<{ id: string; duration: number; text: string }>;
  };
}

export interface WidgetPref {
  id: string;
  name: string;
  visible: boolean;
}

export interface VirtualCallState {
  isOpen: boolean;
  status: 'ringing' | 'active' | 'ended';
  callerName: string;
  phoneNumber: string;
  message: string;
}
