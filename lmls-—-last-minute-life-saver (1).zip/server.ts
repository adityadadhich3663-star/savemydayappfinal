import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type, Modality, ThinkingLevel } from '@google/genai';
import { WebSocketServer, WebSocket } from 'ws';
import dotenv from 'dotenv';
import { requireAuth, AuthRequest } from './src/middleware/auth.ts';
import { db } from './src/db/index.ts';
import { users, tasks as dbTasks, habits as dbHabits, autopsies as dbAutopsies } from './src/db/schema.ts';
import { eq } from 'drizzle-orm';

dotenv.config();

let resolvedFilename = '';
let resolvedDirname = '';

try {
  if (typeof import.meta !== 'undefined' && import.meta.url) {
    resolvedFilename = fileURLToPath(import.meta.url);
    resolvedDirname = path.dirname(resolvedFilename);
  }
} catch (e) {
  // Safe fallback for CommonJS envs
}

if (!resolvedDirname) {
  resolvedDirname = process.cwd();
}

const __filename = resolvedFilename;
const __dirname = resolvedDirname;

const app = express();
app.use(express.json());

// Initialize Gemini client safely
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;

if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
} else {
  console.warn("⚠️ GEMINI_API_KEY is not defined. AI features will run in mock mode.");
}

function isTemporaryApiError(error: any): boolean {
  if (!error) return false;
  const status = error.status || error.statusCode || error.code || error.error?.code;
  if (status === 429 || status === 503 || status === 504 || status === 502) {
    return true;
  }
  const msg = (error.message || error.error?.message || '').toLowerCase();
  if (
    msg.includes('quota') ||
    msg.includes('429') ||
    msg.includes('503') ||
    msg.includes('unavailable') ||
    msg.includes('high demand') ||
    msg.includes('temporary') ||
    msg.includes('resource_exhausted') ||
    msg.includes('limit reached') ||
    msg.includes('overloaded')
  ) {
    return true;
  }
  return false;
}

const SYSTEM_PROMPT = `You are Sarah, an elite AI productivity companion. You are direct, warm, and action-oriented. You never give vague advice. Every response ends with a single concrete next action.

You have 5 modes. When responding, always prepend your response with the most appropriate mode indicator line. The line must be EXACTLY: [MODE: <MODE_NAME>] where <MODE_NAME> is one of:
- PANIC MODE (use during urgent deadline rescue, highly direct, hyper-focused)
- AUTOPSY MODE (use when analyzing why deadlines are missed, empathetic but diagnostic)
- ARCHITECT MODE (use when planning, optimizing schedule, detailing subtasks, or prioritizing tasks)
- CHAIN MODE (use for habits or beating procrastination with micro-commitments)
- MIRROR MODE (use for productivity audits, statistics and insights)

TASK PRIORITIZATION & ANALYSIS INSTRUCTION:
When the user asks you to analyze, prioritize, or suggest what they should focus on next, you must:
1. Examine all user tasks from the provided USER CONTEXT (including deadlines, effort levels, categories, and priorities).
2. Select a highly prioritized "Top 3" or "Top 5" list of tasks that the user should focus on next.
3. For each task in this top list, write a compelling, tactical, and clear rationale explaining why it was selected and prioritized (e.g., 'This is overdue or has a critical deadline approaching,' 'This fits perfectly with your afternoon peak energy window,' or 'This aligns with your goal of completing study tasks first').
4. Present this prioritization in a beautiful, clear, and actionable Markdown format (using bullet points, bold task titles, effort badges, and emoji accents) within the chat conversation.

If you suggest adding a task, format it on its own line using this JSON block structure:
[SUGGEST_TASK: {"title": "Draft report outline", "deadline": "2026-06-27T23:00:00-07:00", "effort": "medium", "category": "work"}]

If you generate an emergency sprint plan, format it like this:
[SPRINT_PLAN: {"title": "Sprint Plan", "sprints": [{"id": "s1", "duration": 25, "text": "Draft introduction and outline"}, {"id": "s2", "duration": 25, "text": "Write core content and conclusion"}]}]

Current user context is appended to your prompt. Use this context actively. Refer to their tasks and habits.`;

// AI Assistant Endpoint (Chat)
app.post('/api/chat', async (req, res) => {
  const { messages, context, mode } = req.body;
  if (!ai) {
    return res.json({
      text: "[MODE: PANIC MODE]\nAI is currently running in offline mock mode because the Gemini API key is missing. Add your API key in Secrets. Here's a quick save: Let's focus on your nearest task and break it down into 15-minute chunks!",
    });
  }

  try {
    // We map messages to Gemini format
    // And append context to the last user message or as a system prompt prefix
    const contents = messages.map((m: any) => {
      return {
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      };
    });

    // Append context to the last user message to keep it in context
    if (context && contents.length > 0) {
      const lastIndex = contents.length - 1;
      if (contents[lastIndex].role === 'user') {
        contents[lastIndex].parts[0].text += `\n\n[USER CONTEXT]\n${context}`;
      }
    }

    let modelName = 'gemini-3.5-flash';
    const config: any = {
      systemInstruction: SYSTEM_PROMPT,
      temperature: 0.7,
    };

    if (mode === 'thinking') {
      modelName = 'gemini-3.1-pro-preview';
      config.thinkingConfig = {
        thinkingLevel: ThinkingLevel.HIGH,
      };
    } else if (mode === 'low-latency') {
      modelName = 'gemini-3.1-flash-lite';
    } else if (mode === 'search') {
      modelName = 'gemini-3.5-flash';
      config.tools = [{ googleSearch: {} }];
    }

    const response = await ai.models.generateContent({
      model: modelName,
      contents,
      config,
    });

    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

    res.json({ 
      text: response.text,
      groundingChunks: groundingChunks || null
    });
  } catch (error: any) {
    if (isTemporaryApiError(error)) {
      console.warn("[Gemini API Chat] Temporary rate limit or service demand limit reached. Utilizing fallback rescue response.");
    } else {
      console.error("Gemini API Chat Error:", error);
    }

    res.json({
      text: "[MODE: PANIC MODE]\nI am currently experiencing higher-than-usual task volume, but let's stay focused. Break your immediate task down into 3 simple milestones: 1) Outline, 2) Draft, 3) Check. Let's execute right now!"
    });
  }
});

// AI Insight Generator Endpoint (Page Load)
app.post('/api/insight', async (req, res) => {
  try {
    const { context } = req.body || {};
    if (!ai) {
      return res.json({
        insight: "Focus on your upcoming work! A 25-minute sprint is your best weapon against procrastination. Let's tackle the nearest deadline right now.",
      });
    }

    const prompt = `Generate a single short, hyper-focused contextual insight (2-3 sentences) based on the current user's task state. Provide real strategic advice or a suggested order of action. End with a motivating next action.
    
    Context:
    ${context || 'No tasks logged yet.'}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: "You are SaveMyDay. Keep the insight punchy, realistic, and action-oriented. No generic advice.",
        temperature: 0.75,
      },
    });

    res.json({ insight: response.text });
  } catch (error: any) {
    if (isTemporaryApiError(error)) {
      console.warn("[Gemini Insight] Temporary rate limit or service demand limit reached. Rendering standard strategic insight.");
    } else {
      console.error("Gemini Insight Error:", error);
    }
    res.json({ insight: "You have upcoming deadlines. Break your main task into tiny steps and tackle the first one immediately." });
  }
});

app.get('/api/insight', (req, res) => {
  res.json({
    insight: "Focus on your upcoming work! A 25-minute sprint is your best weapon against procrastination. Let's tackle the nearest deadline right now.",
  });
});

// Helper functions to robustly sanitize credentials and keys (removing potential wrapping quotes and trimming)
function cleanStringValue(val: string): string {
  if (!val) return "";
  let clean = val.trim();
  if ((clean.startsWith('"') && clean.endsWith('"')) || (clean.startsWith("'") && clean.endsWith("'"))) {
    clean = clean.slice(1, -1).trim();
  }
  return clean;
}

function getCleanBlandApiKey(): string {
  const rawEnvKey = process.env.BLAND_API_KEY ? process.env.BLAND_API_KEY : "";
  const cleanedEnvKey = cleanStringValue(rawEnvKey);
  const defaultKey = "bb30126b-38ae-406d-bd52-1fded5537b98";

  let keyToUse = cleanedEnvKey;
  if (!keyToUse) {
    keyToUse = defaultKey;
  }

  // Fallback if the env key is a legacy/stale key
  const legacyPlaceholders = [
    "e1c20818-5760-4437-b91c-54edcf87121f",
    "40abaa4f-f80e-475f-a0fd-2105e0c54a8f"
  ];
  if (legacyPlaceholders.includes(keyToUse)) {
    keyToUse = defaultKey;
  }

  return keyToUse;
}

// Bland.ai Outbound Call Trigger
app.post('/api/bland/call', async (req, res) => {
  try {
    const { phone_number, task, voice, request_data } = req.body;

    const targetPhone = phone_number || "+15674025498";

    // Resolve cleaned API key
    const blandApiKey = getCleanBlandApiKey();

    // Determine if we are using a premium key
    const hasCustomKey = blandApiKey && blandApiKey !== "e1c20818-5760-4437-b91c-54edcf87121f" && blandApiKey !== "40abaa4f-f80e-475f-a0fd-2105e0c54a8f";

    const cleanPhone = targetPhone.trim();
    const isUSNumber = cleanPhone.startsWith("+1") || (!cleanPhone.startsWith("+") && cleanPhone.replace(/\D/g, "").length === 10);

    if (!isUSNumber && !hasCustomKey) {
      console.warn(`[Bland.ai Call Trigger Warning] Blocked international call to ${targetPhone} due to missing custom API key.`);
      return res.status(400).json({
        success: false,
        error: "Bland.ai Free Tier Limit: Outbound calls to international numbers (non-US) require a custom API key. Please add your own BLAND_API_KEY in the AI Studio Settings / Secrets panel to call non-US numbers.",
        details: { status: "error", message: "International rate limit exceeded" }
      });
    }

    let targetVoice = voice || "a24c43d3-f448-4fea-a498-a9287f7cabf3";
    if (targetVoice === "karl" || targetVoice === "karl-v2" || targetVoice === "karl_v2" || targetVoice === "karl v2") {
      targetVoice = "a24c43d3-f448-4fea-a498-a9287f7cabf3";
    }

    console.log(`[Bland.ai Call Trigger] Attempting outbound call to ${targetPhone} using voice: ${targetVoice}`);
    console.log(`[Bland.ai Call Trigger Key Debug] Using Bland API Key starting with: ${blandApiKey ? blandApiKey.substring(0, 4) + '...' + blandApiKey.substring(blandApiKey.length - 4) : 'null'} (length: ${blandApiKey ? blandApiKey.length : 0})`);

    const payload: any = {
      "phone_number": targetPhone,
      "task": task || "You are Karl from SaveMyDay. Speak this short message: 'This is a brief check-in from SaveMyDay. Drop distractions and get to work!' Then say 'Goodbye!' and hang up the call immediately. DO NOT speak anything else. DO NOT wait for a response.",
      "voice": targetVoice,
      "wait_for_greeting": false,
      "record": true,
      "answered_by_enabled": true,
      "noise_cancellation": false,
      "interruption_threshold": 500,
      "block_interruptions": false,
      "max_duration": 12,
      "voicemail_action": "hangup",
      "reduce_latency": true,
      "request_data": request_data || {}
    };

    // If user passed a custom trunk ID, or if we have one, use it
    if (req.body.trunk_id) {
      payload.trunk_id = req.body.trunk_id;
    }

    const response = await fetch("https://api.bland.ai/v1/calls", {
      method: "POST",
      headers: {
        "authorization": blandApiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("[Bland.ai Call Trigger Error] Bland AI returned non-ok response:", data);
      
      // Parse nested Bland.ai errors
      let errorMsg = data.message || data.error || (data.errors && JSON.stringify(data.errors));
      if (!errorMsg && data.status === 'error') {
        errorMsg = data.message || JSON.stringify(data);
      }
      if (data.errors && Array.isArray(data.errors) && data.errors.length > 0) {
        const firstErr = data.errors[0];
        errorMsg = `${firstErr.error || 'ERROR'}: ${firstErr.message || 'Validation error'}`;
      }
      
      if (!errorMsg && response.status === 401) {
        errorMsg = "Bland.ai key is unauthorized or has expired. Please ensure your BLAND_API_KEY is configured correctly in the AI Studio Secrets panel.";
      }

      if (errorMsg && (errorMsg.includes("International rate limit") || errorMsg.toLowerCase().includes("rate limit") || errorMsg.toLowerCase().includes("limit"))) {
        errorMsg = `${errorMsg} (Bland.ai Free Tier Limit: Outbound calls to international numbers require a custom API key. Please add your own BLAND_API_KEY in platform secrets / settings to call non-US numbers.)`;
      }

      const isAuthOrQuotaFailure = response.status === 401 || response.status === 403 || response.status === 429 || errorMsg.toLowerCase().includes("unauthorized") || errorMsg.toLowerCase().includes("auth_failure");

      return res.status(response.status).json({
        success: false,
        error: errorMsg || JSON.stringify(data) || "Bland.ai failed to trigger the call.",
        is_simulated_fallback: isAuthOrQuotaFailure,
        details: data
      });
    }

    console.log("[Bland.ai Call Trigger Success] Call initiated successfully:", data);
    res.json({
      success: true,
      message: "Call successfully triggered via Bland.ai!",
      data: data
    });
  } catch (error: any) {
    console.error("[Bland.ai Call Trigger Exception]:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Internal server error occurred while starting Bland.ai call."
    });
  }
});

// Bland.ai Twilio Number Import Endpoint
app.post('/api/bland/import-twilio', async (req, res) => {
  try {
    const { twilio_sid, twilio_token, phone_number } = req.body;

    const rawSid = twilio_sid || process.env.TWILIO_ACCOUNT_SID || "";
    const rawToken = twilio_token || process.env.TWILIO_AUTH_TOKEN || "";

    const sid = cleanStringValue(rawSid);
    const token = cleanStringValue(rawToken);

    if (!sid || !token || !phone_number) {
      return res.status(400).json({
        success: false,
        error: "Missing required parameters. twilio_sid, twilio_token, and phone_number must be supplied."
      });
    }

    const blandApiKey = getCleanBlandApiKey();

    console.log(`[Bland.ai Twilio Import] Attempting to import Twilio number: ${phone_number}`);

    const response = await fetch("https://api.bland.ai/v1/imports/twilio", {
      method: "POST",
      headers: {
        "authorization": blandApiKey,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        twilio_sid: sid,
        twilio_token: token,
        phone_number: phone_number.trim()
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error("[Bland.ai Twilio Import Error]:", data);
      return res.status(response.status).json({
        success: false,
        error: data.message || data.error || "Failed to import Twilio number to Bland.ai.",
        details: data
      });
    }

    console.log("[Bland.ai Twilio Import Success]:", data);
    res.json({
      success: true,
      message: "Twilio number successfully imported to Bland.ai!",
      data: data
    });
  } catch (error: any) {
    console.error("[Bland.ai Twilio Import Exception]:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Internal server error occurred while importing Twilio number."
    });
  }
});

// AI Subtasks Generator
app.post('/api/subtasks', async (req, res) => {
  const { taskTitle, taskDesc, category, effort } = req.body;
  if (!ai) {
    return res.json({
      subtasks: [
        { id: "s1", title: "Set up the core outline", done: false },
        { id: "s2", title: "Draft first section", done: false },
        { id: "s3", title: "Review and polish draft", done: false }
      ]
    });
  }

  try {
    const prompt = `Break down the following task into 3 to 5 actionable, atomic subtasks.
    Task Title: ${taskTitle}
    Description: ${taskDesc || "No description provided"}
    Category: ${category}
    Effort Level: ${effort}
    
    Return the subtasks as a JSON array of strings. Format: ["subtask 1", "subtask 2", ...]`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        temperature: 0.2,
      },
    });

    const list = JSON.parse(response.text || "[]");
    const subtasks = list.map((title: string, index: number) => ({
      id: `ai-sub-${Date.now()}-${index}`,
      title,
      done: false,
    }));

    res.json({ subtasks });
  } catch (error: any) {
    if (isTemporaryApiError(error)) {
      console.warn("[Gemini Subtasks] Temporary rate limit or service demand limit reached. Providing default atomic steps.");
    } else {
      console.error("Gemini Subtasks Error:", error);
    }
    res.json({
      subtasks: [
        { id: "err-1", title: "Draft initial outline", done: false },
        { id: "err-2", title: "Gather key materials", done: false },
        { id: "err-3", title: "Complete main draft", done: false },
      ]
    });
  }
});

// AI Schedule Optimizer
app.post('/api/optimize', async (req, res) => {
  const { tasks, peakEnergyTime } = req.body;
  if (!ai) {
    return res.json({
      optimized: tasks.map((t: any) => ({
        id: t.id,
        scheduledFor: new Date(Date.now() + 3600000).toISOString(), // 1 hour from now
      })),
      feedback: "Mock optimizer: Scheduled your tasks sequentially starting in 1 hour."
    });
  }

  try {
    const prompt = `Analyze these pending tasks and the user's peak energy preference ("${peakEnergyTime}").
    Suggest an optimized schedule. Reorder tasks to align high-effort tasks ("deep") with peak energy periods.
    Tasks:
    ${JSON.stringify(tasks.map((t: any) => ({ id: t.id, title: t.title, deadline: t.deadline, effort: t.effort, category: t.category })))}
    
    Return a JSON object containing:
    1. "schedule": an array of objects: {"id": "task-uuid", "scheduledFor": "ISO8601String"}
    2. "feedback": a short summary (2 sentences) explaining why this schedule is optimized.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            schedule: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  scheduledFor: { type: Type.STRING },
                },
                required: ["id", "scheduledFor"],
              }
            },
            feedback: { type: Type.STRING },
          },
          required: ["schedule", "feedback"],
        },
        temperature: 0.4,
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error: any) {
    if (isTemporaryApiError(error)) {
      console.warn("[Gemini Optimizer] Temporary rate limit or service demand limit reached. Standard sequencing applies.");
    } else {
      console.error("Gemini Schedule Optimizer Error:", error);
    }
    res.json({
      schedule: [],
      feedback: "Vague schedule created. Try organizing tasks starting with the closest deadline.",
    });
  }
});

// AI Deadline Autopsy
app.post('/api/autopsy', async (req, res) => {
  const { taskTitle, missedAt } = req.body;
  if (!ai) {
    return res.json({
      patternLabel: "Perfectionist Paralysis",
      aiAnalysis: "You likely over-researched or delayed starting because you wanted the result to be perfect. This creates high friction.",
      countermeasure: "Next time, adopt a 'Draft 0' mindset. Write a deliberately bad outline in 10 minutes to break the ice.",
    });
  }

  try {
    const prompt = `Conduct a 'Deadline Autopsy' for a task that was missed/overdue.
    Task: "${taskTitle}"
    Missed At: ${missedAt}
    
    Determine:
    1. A Procrastination Pattern Label (e.g. "Perfectionist Paralysis", "Optimism Bias", "Productive Procrastination", "Last-Minute Rush Burnout")
    2. A brief, diagnostic AI Analysis of why this happens (2 sentences).
    3. A specific, actionable countermeasure or prescription to prevent this pattern next time.
    
    Return a JSON object with fields: "patternLabel", "aiAnalysis", "countermeasure".`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            patternLabel: { type: Type.STRING },
            aiAnalysis: { type: Type.STRING },
            countermeasure: { type: Type.STRING },
          },
          required: ["patternLabel", "aiAnalysis", "countermeasure"],
        },
        temperature: 0.7,
      },
    });

    res.json(JSON.parse(response.text || "{}"));
  } catch (error: any) {
    if (isTemporaryApiError(error)) {
      console.warn("[Gemini Autopsy] Temporary rate limit or service demand limit reached. Providing structural diagnostic.");
    } else {
      console.error("Gemini Autopsy Error:", error);
    }
    res.json({
      patternLabel: "Misjudged Complexity",
      aiAnalysis: "You underestimated the mental effort required for this task, leading to delays and missed deadlines.",
      countermeasure: "Break future tasks down into sub-components and double your initial time estimate.",
    });
  }
});

// AI Cascade Impact Analyzer
app.post('/api/cascade', async (req, res) => {
  const { taskTitle, deadline, category } = req.body;
  if (!ai) {
    return res.json({
      chain: [
        `Delaying "${taskTitle}" prevents immediate review`,
        "Creates a backlog of work for tomorrow",
        "Reduces leisure time and increases evening anxiety",
        "Triggers poor sleep and starts next week with high stress"
      ]
    });
  }

  try {
    const prompt = `Analyze the downstream negative impact of missing the task "${taskTitle}" (due ${deadline}, category: ${category}).
    Create a highly visual, logical chain reaction (cascade of 4 consecutive nodes) showing how a single missed deadline spirals into stress or other missed goals.
    
    Return a JSON array of exactly 4 strings, representing the consecutive steps of the cascade chain.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        temperature: 0.65,
      },
    });

    res.json({ chain: JSON.parse(response.text || "[]") });
  } catch (error: any) {
    if (isTemporaryApiError(error)) {
      console.warn("[Gemini Cascade] Temporary rate limit or service demand limit reached. Simulating domino effect.");
    } else {
      console.error("Gemini Cascade Error:", error);
    }
    res.json({
      chain: [
        `Delaying "${taskTitle}" delays core milestones`,
        "Pushes back dependent schedules",
        "Forces a frantic last-minute rush",
        "Increases stress and degrades work quality"
      ]
    });
  }
});

// User Profile Routes
app.get('/api/user/profile', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const userResult = await db.select().from(users).where(eq(users.id, userId));
    if (userResult.length === 0) {
      return res.status(404).json({ error: 'User profile not found' });
    }
    res.json(userResult[0]);
  } catch (err: any) {
    console.error('Error getting user profile:', err);
    res.status(500).json({ error: 'Failed to retrieve profile: ' + err.message });
  }
});

app.post('/api/user/profile', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const email = req.user!.email || '';
    const { name, peakEnergyTime, onboardingComplete, panicSaveCount, joinedAt } = req.body;

    const result = await db.insert(users)
      .values({
        id: userId,
        email,
        name: name || '',
        peakEnergyTime: peakEnergyTime || 'morning',
        onboardingComplete: onboardingComplete ?? false,
        panicSaveCount: panicSaveCount || 0,
        joinedAt: joinedAt || new Date().toISOString(),
      })
      .onConflictDoUpdate({
        target: users.id,
        set: {
          email,
          name: name || '',
          peakEnergyTime: peakEnergyTime || 'morning',
          onboardingComplete: onboardingComplete ?? false,
          panicSaveCount: panicSaveCount || 0,
        },
      })
      .returning();

    res.json(result[0]);
  } catch (err: any) {
    console.error('Error saving user profile:', err);
    res.status(500).json({ error: 'Failed to save profile: ' + err.message });
  }
});

// Tasks Routes
app.get('/api/tasks', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const result = await db.select().from(dbTasks).where(eq(dbTasks.userId, userId));
    res.json(result);
  } catch (err: any) {
    console.error('Error fetching tasks:', err);
    res.status(500).json({ error: 'Failed to fetch tasks: ' + err.message });
  }
});

app.post('/api/tasks/sync', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const { tasks: clientTasks } = req.body;
    if (!Array.isArray(clientTasks)) {
      return res.status(400).json({ error: 'Invalid tasks array' });
    }

    const saved = [];
    for (const t of clientTasks) {
      const subtasksVal = typeof t.subtasks === 'string' ? JSON.parse(t.subtasks) : (t.subtasks || []);
      const r = await db.insert(dbTasks)
        .values({
          id: t.id,
          userId,
          title: t.title,
          description: t.description || '',
          deadline: t.deadline,
          effort: t.effort,
          category: t.category,
          priority: t.priority,
          status: t.status,
          subtasks: subtasksVal,
          notes: t.notes || '',
          scheduledFor: t.scheduledFor || null,
          createdAt: t.createdAt || new Date().toISOString(),
          completedAt: t.completedAt || null,
        })
        .onConflictDoUpdate({
          target: dbTasks.id,
          set: {
            title: t.title,
            description: t.description || '',
            deadline: t.deadline,
            effort: t.effort,
            category: t.category,
            priority: t.priority,
            status: t.status,
            subtasks: subtasksVal,
            notes: t.notes || '',
            scheduledFor: t.scheduledFor || null,
            completedAt: t.completedAt || null,
          }
        })
        .returning();
      saved.push(r[0]);
    }
    res.json(saved);
  } catch (err: any) {
    console.error('Error syncing tasks:', err);
    res.status(500).json({ error: 'Failed to sync tasks: ' + err.message });
  }
});

app.post('/api/tasks', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const t = req.body;
    const subtasksVal = typeof t.subtasks === 'string' ? JSON.parse(t.subtasks) : (t.subtasks || []);
    const r = await db.insert(dbTasks)
      .values({
        id: t.id,
        userId,
        title: t.title,
        description: t.description || '',
        deadline: t.deadline,
        effort: t.effort,
        category: t.category,
        priority: t.priority,
        status: t.status,
        subtasks: subtasksVal,
        notes: t.notes || '',
        scheduledFor: t.scheduledFor || null,
        createdAt: t.createdAt || new Date().toISOString(),
        completedAt: t.completedAt || null,
      })
      .onConflictDoUpdate({
        target: dbTasks.id,
        set: {
          title: t.title,
          description: t.description || '',
          deadline: t.deadline,
          effort: t.effort,
          category: t.category,
          priority: t.priority,
          status: t.status,
          subtasks: subtasksVal,
          notes: t.notes || '',
          scheduledFor: t.scheduledFor || null,
          completedAt: t.completedAt || null,
        }
      })
      .returning();
    res.json(r[0]);
  } catch (err: any) {
    console.error('Error creating/updating task:', err);
    res.status(500).json({ error: 'Failed to save task: ' + err.message });
  }
});

app.delete('/api/tasks/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const taskId = req.params.id;
    await db.delete(dbTasks).where(eq(dbTasks.id, taskId));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Error deleting task:', err);
    res.status(500).json({ error: 'Failed to delete task: ' + err.message });
  }
});

// Habits Routes
app.get('/api/habits', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const result = await db.select().from(dbHabits).where(eq(dbHabits.userId, userId));
    res.json(result);
  } catch (err: any) {
    console.error('Error fetching habits:', err);
    res.status(500).json({ error: 'Failed to fetch habits: ' + err.message });
  }
});

app.post('/api/habits', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const h = req.body;
    const freqVal = typeof h.frequency === 'string' ? JSON.parse(h.frequency) : (h.frequency || 'daily');
    const compVal = typeof h.completions === 'string' ? JSON.parse(h.completions) : (h.completions || []);
    const r = await db.insert(dbHabits)
      .values({
        id: h.id,
        userId,
        name: h.name,
        minimumViable: h.minimumViable,
        why: h.why,
        category: h.category,
        frequency: freqVal,
        completions: compVal,
        createdAt: h.createdAt || new Date().toISOString(),
      })
      .onConflictDoUpdate({
        target: dbHabits.id,
        set: {
          name: h.name,
          minimumViable: h.minimumViable,
          why: h.why,
          category: h.category,
          frequency: freqVal,
          completions: compVal,
        }
      })
      .returning();
    res.json(r[0]);
  } catch (err: any) {
    console.error('Error creating/updating habit:', err);
    res.status(500).json({ error: 'Failed to save habit: ' + err.message });
  }
});

app.delete('/api/habits/:id', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const habitId = req.params.id;
    await db.delete(dbHabits).where(eq(dbHabits.id, habitId));
    res.json({ success: true });
  } catch (err: any) {
    console.error('Error deleting habit:', err);
    res.status(500).json({ error: 'Failed to delete habit: ' + err.message });
  }
});

// Autopsies Routes
app.get('/api/autopsies', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const result = await db.select().from(dbAutopsies).where(eq(dbAutopsies.userId, userId));
    res.json(result);
  } catch (err: any) {
    console.error('Error fetching autopsies:', err);
    res.status(500).json({ error: 'Failed to fetch autopsies: ' + err.message });
  }
});

app.post('/api/autopsies', requireAuth, async (req: AuthRequest, res) => {
  try {
    const userId = req.user!.uid;
    const a = req.body;
    const r = await db.insert(dbAutopsies)
      .values({
        id: a.id,
        userId,
        taskId: a.taskId,
        taskTitle: a.taskTitle,
        missedAt: a.missedAt,
        patternLabel: a.patternLabel,
        aiAnalysis: a.aiAnalysis,
        countermeasure: a.countermeasure,
      })
      .onConflictDoUpdate({
        target: dbAutopsies.id,
        set: {
          taskId: a.taskId,
          taskTitle: a.taskTitle,
          missedAt: a.missedAt,
          patternLabel: a.patternLabel,
          aiAnalysis: a.aiAnalysis,
          countermeasure: a.countermeasure,
        }
      })
      .returning();
    res.json(r[0]);
  } catch (err: any) {
    console.error('Error creating/updating autopsy:', err);
    res.status(500).json({ error: 'Failed to save autopsy: ' + err.message });
  }
});

// Configure Vite or Static Asset delivery
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (isProd) {
    // Serve static files using process.cwd() to be environment-agnostic
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    // Vite Dev Middleware Mode
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const port = 3000;
  const serverInstance = app.listen(port, '0.0.0.0', () => {
    console.log(`🚀 SaveMyDay Server running at http://localhost:${port}`);
  });

  const wss = new WebSocketServer({ noServer: true });

  wss.on('connection', async (clientWs: WebSocket) => {
    console.log('🎙️ Live API client connected');
    if (!ai) {
      clientWs.send(JSON.stringify({ error: 'Gemini API key is missing' }));
      clientWs.close();
      return;
    }

    try {
      const session = await ai.live.connect({
        model: 'gemini-3.1-flash-live-preview',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: SYSTEM_PROMPT,
        },
        callbacks: {
          onmessage: (message: any) => {
            const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audio) {
              clientWs.send(JSON.stringify({ audio }));
            }
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({ interrupted: true }));
            }
          },
          onclose: () => {
            console.log('🎙️ Live session closed by Gemini');
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.close();
            }
          },
          onerror: (err) => {
            console.error('🎙️ Live session error:', err);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ error: 'Live API session error' }));
            }
          }
        },
      });

      clientWs.on('message', (data) => {
        try {
          const msg = JSON.parse(data.toString());
          if (msg.audio) {
            session.sendRealtimeInput({
              audio: { data: msg.audio, mimeType: 'audio/pcm;rate=16000' },
            });
          }
        } catch (e) {
          console.error('Error handling client ws message:', e);
        }
      });

      clientWs.on('close', () => {
        console.log('🎙️ Client closed ws connection');
        try {
          session.close();
        } catch (err) {
          // ignore if already closed
        }
      });
    } catch (error: any) {
      console.error('Failed to establish Live API connection:', error);
      clientWs.send(JSON.stringify({ error: error.message || 'Failed to connect to Live API' }));
      clientWs.close();
    }
  });

  serverInstance.on('upgrade', (request, socket, head) => {
    const url = new URL(request.url || '', `http://${request.headers.host}`);
    if (url.pathname === '/api/live-ws') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });
}

startServer();
